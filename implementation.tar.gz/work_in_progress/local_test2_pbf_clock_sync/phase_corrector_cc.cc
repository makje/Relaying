#include "phase_corrector_cc.h"
#include <vector>
#include <gr_io_signature.h>
#include <iostream>
using std::cout;
using std::endl;

phase_corrector_cc_sptr make_phase_corrector_cc(const std::vector<gr_complex> &mod_header, int packet_length, int data_per_pilot){
	return phase_corrector_cc_sptr(new phase_corrector_cc(mod_header,packet_length,data_per_pilot));
}

phase_corrector_cc::phase_corrector_cc(const std::vector<gr_complex> &mod_header,
										int packet_length,
										int data_per_pilot):
										gr_block("phase_corrector_cc",
												gr_make_io_signature (1, 1, sizeof(gr_complex)),
												gr_make_io_signature (1, 1, sizeof(gr_complex))
												),
												d_symbol_counter(0),
												d_data_counter(0),
												d_packet_length(packet_length),
												d_data_per_pilot(data_per_pilot){
	d_modulated_header = mod_header;
	d_header_length = mod_header.size();
	d_pilot = gr_complex(-0.7071,0.7071); //FIXME
	data_vec = std::vector<gr_complex>(d_data_per_pilot,gr_complex(0.0,0.0));
}

int phase_corrector_cc::general_work(int noutput_items,
									gr_vector_int &ninput_items,
									gr_vector_const_void_star &input_items,
									gr_vector_void_star &output_items)
{
	#ifdef PHASE_CORRECTOR_CC_DEBUG
		cout << "Phase Corrector work" << endl;
	#endif
	const gr_complex *in = (const gr_complex *) input_items[0]; //signal from header_correlator_cc
	gr_complex *out = (gr_complex *) output_items[0];

	int ni = ninput_items[0];
	int in_counter = 0;
	int oo = 0;
	gr_complex h_hat(0.0,0.0);
	
	for(int i=0;i<ni;i++){
		if(d_symbol_counter<d_header_length){
			//header
		}
		else{
			//data
			if(d_symbol_counter>d_header_length && (d_symbol_counter+1)%(d_data_per_pilot+1)==0){
				//pilot
				h_hat = in[i]/d_pilot;
				#ifdef PHASE_CORRECTOR_CC_DEBUG
					cout << "Pilot from: in[" << i << "] symbol_counter: " << d_symbol_counter << endl
				#endif
				for(int i=0;i<d_data_per_pilot;i++){
					out[oo+i] = data_vec[i]/h_hat;
				}
				oo+=d_data_per_pilot;
			}
			else{
				//regular data.
				data_vec[d_data_counter] = in[i];
				#ifdef PHASE_CORRECTOR_CC_DEBUG
					cout << "Data from in[" << i << "] placed in data_vec[" << d_data_counter << "]" << endl;
				#endif
				d_data_counter = (d_data_counter+1)%(d_data_per_pilot-1); //bound it to [0:d_data_per_pilot-1].
			}
		}
		d_symbol_counter = (d_symbol_counter+1)%(d_packet_length-1); //bound it to [0 d_packet_length-1]
	}
	#ifdef PHASE_CORRECTOR_CC_DEBUG
		cout << "\tni: " << ni << endl << "\too: " << oo << endl;
	#endif
	consume_each(ni); //consume all inputs, that is, free the in- buffer of them.
	return oo; //report that we have created out_counter elements.
}
