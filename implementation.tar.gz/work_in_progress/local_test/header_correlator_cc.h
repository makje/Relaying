#ifndef INCLUDED_HEADER_CORRELATOR_CC_H
#define INCLUDED_HEADER_CORRELATOR_CC_H

#include <gr_block.h>
#include <vector>

class header_correlator_cc;
typedef boost::shared_ptr<header_correlator_cc> header_correlator_cc_sptr;

header_correlator_cc_sptr make_header_correlator_cc(const std::vector<gr_complex> &mod_header, int samples_per_symbol);

class header_correlator_cc : public gr_block{


	int 						d_sps;
	int							d_len;
	gr_complex					d_pn;
	std::vector<gr_complex>		d_modulated_header;
	int							d_bit_counter;
	bool						d_is_synced;

	friend header_correlator_cc_sptr make_header_correlator_cc(const std::vector<gr_complex> &mod_header, int samples_per_symbol);
	header_correlator_cc(const std::vector<gr_complex> &mod_header, int samples_per_symbol);

	public:
		virtual int general_work(int noutput_items,
								gr_vector_int &ninput_items,
								gr_vector_const_void_star &input_items,
								gr_vector_void_star &output_items);
		~header_correlator_cc();
};

#endif /* INCLUDED_GR_PN_CORRELATOR_CC_H */
