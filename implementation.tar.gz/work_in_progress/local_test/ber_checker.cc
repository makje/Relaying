#include "ber_checker.h"
#include <gr_io_signature.h>
#include <iostream>

using std::cout;
using std::endl;

ber_checker_sptr make_ber_checker(int degree, int mask, int seed, float alpha){
  return ber_checker_sptr (new ber_checker(degree, mask, seed, alpha));
}

ber_checker::ber_checker(int degree, int mask, int seed, float alpha)
  : gr_sync_block("ber_checker",
					gr_make_io_signature(1, 1, sizeof(unsigned char)),
					gr_make_io_signature(0, 0, 0)
				 ), d_ber(0.0), d_alpha(alpha){
	d_glfsr = new gri_glfsr(mask, seed);
	d_glfsr->glfsr_mask(degree);
}

ber_checker::~ber_checker(){
	delete d_glfsr;
}

int ber_checker::work(int noutput_items,
					gr_vector_const_void_star &input_items,
					gr_vector_void_star &output_items){
	#ifdef BER_DEBUG
		cout << "BER work" << endl;
	#endif
	char *inbuf = (char *) input_items[0];
	int  nwritten = 0;
	float sum = 0;
	while (nwritten < noutput_items){
		if(inbuf[nwritten++]!=d_glfsr->next_bit()){
			sum=sum+1.0;
		}
	}
	//d_ber = (sum/noutput_items)*(d_alpha) +  d_ber*(1-d_alpha);
	d_ber = sum;
	#ifdef BER_DEBUG
		cout << "\tnwritten: " << nwritten << endl << "\tno: " << no << endl << "\tBER: " << d_ber << endl;
	#endif
	return nwritten;
}
