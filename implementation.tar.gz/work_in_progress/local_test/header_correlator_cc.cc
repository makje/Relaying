/* -*- c++ -*- */
/* Code is based on gpl:ed code from gnuRadio.
 */

#include "header_correlator_cc.h"
#include <gr_io_signature.h>
#include <vector>
#include <iostream>

using std::cout;
using std::vector;
using std::endl;

header_correlator_cc_sptr make_header_correlator_cc(const std::vector<gr_complex> &mod_header,
													int samples_per_symbol){
  return header_correlator_cc_sptr (new header_correlator_cc(mod_header, samples_per_symbol));
}

header_correlator_cc::header_correlator_cc(const std::vector<gr_complex> &mod_header,
										   int samples_per_symbol):gr_block("header_correlator_cc",
											gr_make_io_signature (1, 1, sizeof(gr_complex)),
											gr_make_io_signature (2, 3, sizeof(gr_complex))), d_sps(samples_per_symbol){
	d_modulated_header = mod_header;
	d_len = mod_header.size();
  	d_pn = d_modulated_header[0];
	d_bit_counter = 0;
	d_is_synced = false;
}

header_correlator_cc::~header_correlator_cc(){
}


int header_correlator_cc::general_work(int noutput_items,
										gr_vector_int &ninput_items,
										gr_vector_const_void_star &input_items,
										gr_vector_void_star &output_items){
	#ifdef HEADER_CORRELATOR_DEBUG
		cout << "Header correlator work" << endl;
	#endif
	const gr_complex *in = (const gr_complex *) input_items[0];
	gr_complex *out = (gr_complex *) output_items[0];
	gr_complex *hs = (gr_complex *) output_items[1];
	gr_complex *sum_sig = (gr_complex *) output_items[2];

	int ni = ninput_items[0];
	int no = noutput_items;
	int oo = 0;
	float sum = 0.0;
	int ii = 0;
	float threashold = 9940.0;//FIXME STATIC THRESHOLD
	
	bool write_extra = false;
	if( ( output_items.size() != 3 ) && ( output_items.size() != 2 ) ){
		printf("Header_correlator_cc must have either 2 or 3 outputs connected");
		assert(-1);
	}
	if( output_items.size() == 3 ){
		write_extra = true;
	}
	
	/**
		Signal processing follows...
	*/
	
	if(write_extra){ //we have 3 outputs...
		while(!d_is_synced && ii<ni){
			#ifdef HEADER_CORRELATOR_DEBUG
				cout << "\t!d_is_synced %% ii<ni" << endl;
			#endif
			sum = 0.0;
			for(int l=ii;(l<(ii+d_sps*(d_len-1))) && l<noutput_items;l=l+d_sps){
				sum+=abs(in[l]*conj(d_pn));
				d_pn = d_modulated_header[++d_bit_counter%d_len];
			}
			if( sum>=threashold){
				d_is_synced = true;
				out[oo] = in[ii];
				hs[oo] = gr_complex(1.0,0.0);
				sum_sig[oo] = gr_complex(sum,0.0);
				oo++;
			}
			else{
				out[oo] = gr_complex(0.0,0.0);
				hs[oo] = gr_complex(0.0,0.0);
				sum_sig[oo] = gr_complex(sum,0.0);
				oo++;
			}
			ii++;
		}
		while(d_is_synced && ii<ni){
			out[oo] = in[ii++];
			hs[oo] = gr_complex(1.0,0.0);
			sum_sig[oo] = gr_complex(0.0,0.0);
			oo++;
		}
		#ifdef HEADER_CORRELATOR_DEBUG
			cout << "\tii: " << ii << endl << "\tni: " << ni << endl << "\tno: " << no << endl;
		#endif
		consume_each(ii);
		return oo;
	}
	else{ //don't write extra output
		while(!d_is_synced && ii<ni){
			#ifdef HEADER_CORRELATOR_DEBUG
				cout << "\t!d_is_synced %% ii<ni" << endl;
			#endif
			sum = 0.0;
			for(int l=ii;(l<(ii+d_sps*(d_len-1))) && l<noutput_items;l=l+d_sps){
				sum+=abs(in[l]*conj(d_pn));
				d_pn = d_modulated_header[++d_bit_counter%d_len];
			}
			if( sum>=threashold){
				d_is_synced = true;
				out[oo] = in[ii];
				hs[oo] = gr_complex(1.0,0.0);
				oo++;
			}
			else{
				out[oo] = gr_complex(0.0,0.0);
				hs[oo] = gr_complex(0.0,0.0);
				oo++;
			}
			ii++;
		}
		while(d_is_synced && ii<ni){
			out[oo] = in[ii++];
			hs[oo] = gr_complex(1.0,0.0);
			oo++;
		}
		#ifdef HEADER_CORRELATOR_DEBUG
			cout << "\tii: " << ii << endl << "\tni: " << ni << endl << "\tno: " << no << endl;
		#endif
		consume_each(ii);
		return oo;	
	}
}
