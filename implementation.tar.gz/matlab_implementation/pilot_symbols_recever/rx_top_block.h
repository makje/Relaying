//rx_top_block.h
#include <gr_top_block.h>
#include <usrp_source_c.h>
#include <gr_agc2_cc.h>
#include <gr_firdes.h>
#include <gr_fir_filter_ccf.h>
#include <gr_file_sink.h>
class rx_top_block;

typedef boost::shared_ptr<rx_top_block> rx_top_block_sptr;

rx_top_block_sptr make_rx_top_block();

class rx_top_block:public gr_top_block{
	private:
		//Misc parameters
		double d_rf_freq;
		int d_gain;
		long d_rate;
		float d_sps;
		long d_if_rate;
		
		//Parameters for usrp
		int d_rx_board;
		int d_rx_decimation_rate;
		int d_rx_channel;
		int d_rx_mux;

		//RRC- parameters
		float d_rrc_gain;
		float d_rrc_sps;
		float d_rrc_symbol_rate;
		float d_rrc_excess_bw;
		int d_rrc_ntaps;
		int d_rrc_decimation;

		usrp_source_c_sptr								d_rx;
		db_base_sptr 											d_db;
		
		gr_agc2_cc_sptr 									d_agc;
		gr_fir_filter_ccf_sptr						d_rx_rrc;

		void configure_usrp();
	public:
		rx_top_block();
		friend rx_top_block_sptr make_rx_top_block();
		
		~rx_top_block();

};
