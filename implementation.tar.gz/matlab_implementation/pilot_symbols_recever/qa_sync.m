clear all
d = [2,0,1,3,2,3,0,0,3,0,2,1,3,2,1,3,3,2,2,2, ...
     2,3,0,1,1,3,1,2,1,0,1,0,1,2,1,2,3,2,3,1, ...
	 2,2,1,0,2,2,2,0,1,2,3,2,2,2,1,1,2,3,1,2, ...
	 3,3,1,2,1,2,1,3,2,2,3,1,1,1,1,2,3,3,0,3, ...
	 3,1,1,1,2,2,3,1,2,2,2,3,1,3,3,3,3,2,2,1];
ds = modulate(d);
ld = length(d);
rx = zeros(21e3, 1);

rx(1000:1000+ld-1) = ds;
rx(2000:2000+ld-1) = ds.*exp(-j*5);  %5  grader snurr
rx(3000:3000+ld-1) = ds.*exp(-j*10); %10 grader snurr
rx(4000:4000+ld-1) = ds.*exp(-j*15); %15 grader snurr
rx(5000:5000+ld-1) = ds.*exp(-j*20); %20 grader snurr
rx(6000:6000+ld-1) = ds.*exp(-j*25); %25 grader snurr
rx(7000:7000+ld-1) = ds.*exp(-j*30); %30 grader snurr
rx(8000:8000+ld-1) = ds.*exp(-j*35); %35 grader snurr
rx(9000:9000+ld-1) = ds.*exp(-j*40); %40 grader snurr
rx(10000:10000+ld-1) = ds.*exp(-j*45); %45 grader snurr
rx(11000:11000+ld-1) = ds.*exp(-j*50); %50 grader snurr
rx(12000:12000+ld-1) = ds.*exp(-j*55); %55 grader snurr
rx(13000:13000+ld-1) = ds.*exp(-j*60); %60 grader snurr
rx(14000:14000+ld-1) = ds.*exp(-j*65); %65 grader snurr
rx(15000:15000+ld-1) = ds.*exp(-j*70); %70 grader snurr
rx(16000:16000+ld-1) = ds.*exp(-j*75); %75 grader snurr
rx(17000:17000+ld-1) = ds.*exp(-j*80); %80 grader snurr
rx(18000:18000+ld-1) = ds.*exp(-j*85); %85 grader snurr
rx(19000:19000+ld-1) = ds.*exp(-j*90); %90 grader snurr
rx(20000:20000+49) = ds(1:50);

[t_samp corr_vector] = sync(rx', d, 1, 1, length(rx)-length(d));

rx2 = round(3.*rand(size(rx)));
rx2 = modulate(rx2);
rx2(1000:1000+ld-1)=ds;
[t_samp2 corr_vector2] = sync(rx2',d,1,1,length(rx2)-length(d));


rx_s = rx(t_samp+(1:ld));
rx_d = demodulate(rx_s);
err = rx_d - d';
plot(err)