function [c_hat c_h_hat] = correct_phase(c, pilot)
    if 0 %Fungerar dåligt, men det var den första iden jag hade...
        c_hat1 = c;
        for k=5:5:length(c_hat1)
            if angle(c(k))>angle(pilot)
                c_hat1(k-4:k) = c(k-4:k)*exp(-j*angle(c(k))-angle(s));
            else
                c_hat1(k-4:k) = c(k-4:k)*exp(j*angle(c(k))-angle(s));
            end
        end
    end
    if 0 % Basic- utförande... fungerar ganska bra.
        c_hat = zeros(size(c));
        c_h_hat = zeros(size(c));
        for k = 5:5:length(c_hat)
            c_h_hat(k) = c(k)/pilot;
            c_hat(k-4:k) = c(k-4:k)/c_h_hat(k);
        end
    end
    if 0 %lite mer fancy, men det fungerar inte så bra dethär häller...
    c_hat = zeros(size(c));
    c_h_hat = zeros(size(c));
    c_h_hat(1) = exp(j*3*pi/4);
    alpha = 0.1;
    for k = 5:5:length(c_hat)
        c_h_hat(k) = c(k)/pilot;
        if k>5 %iff not first sample
            new_angle = angle(c_h_hat(k))*alpha-mean(c_h_hat(1:5:k))*(1-alpha);
            c_h_hat(k) = abs(c_h_hat(k))*exp(j*new_angle);
        end
        c_hat(k-4:k) = c(k-4:k)/c_h_hat(k);
    end
    end
    if 1
    c_hat = zeros(size(c));
    c_h_hat = zeros(size(c));
    c_h_hat(1) = exp(j*3*pi/4);
    for k = 5:5:length(c_hat)
        c_h_hat(k) = c(k)/pilot;
        if angle(c_h_hat(k))>2*pi
            phi = angle(c_h_hat(k));
            while phi>2*pi
                disp('!');
                phi = phi-2*pi;
            end
            while phi<-2*pi
                disp('?');
                phi = phi+2*pi;
            end
            c_h_hat(k) = abs(c_h_hat(k))*exp(j*phi);
        end
        c_hat(k-4:k) = c(k-4:k)/c_h_hat(k);
    end
    end
    %c_hat = c_hat/mean(abs(c_hat)); %Kan man kanske göra om man vill...
end