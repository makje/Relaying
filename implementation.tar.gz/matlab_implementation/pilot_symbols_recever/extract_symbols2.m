function [buffer_symbols n_symbols_extracted lsp e] = extract_symbols2(buffer,t_samp,sps,extract_symbols_counter, err)
    if 0
    th = 200;
    buffer_symbols = [];
    if t_samp<2
        t_samp = 2;
    end
    while t_samp<length(buffer)
        buffer_symbols = [buffer_symbols buffer(t_samp)];
        sym = [buffer(t_samp-1) buffer(t_samp+1)];
        err = abs(sym(1))-abs(sym(2));
        if abs(err)<th
            t_samp = t_samp+sps;
        else
            if sign(err)<0
                t_samp = t_samp+sps-1;
            else
                t_samp = t_samp+sps+1;
            end
        end
        extract_symbols_counter = extract_symbols_counter+1;
    end
    lsp = t_samp-length(buffer);
    n_symbols_extracted = extract_symbols_counter;
    end
    if 0
        if(t_samp<2)
            t_samp = 2;
        end
    buffer_symbols1 = buffer(t_samp-1:sps:end);
    buffer_symbols2 = buffer(t_samp:sps:end);
    buffer_symbols3 = buffer(t_samp+1:sps:end);
    std_buffer_symbols = [std(abs(buffer_symbols1)) std(abs(buffer_symbols2)) std(abs(buffer_symbols3))];
    [a b] = min(std_buffer_symbols);
    if b==1
        buffer_symbols = buffer_symbols1;
    else
        if b==2
            buffer_symbols = buffer_symbols2;
        else
            buffer_symbols = buffer_symbols3;
        end
    end
    
    lsp = t_samp+(t_samp-t_samp+length(buffer_symbols)*sps)-length(buffer);
    n_symbols_extracted = extract_symbols_counter+length(buffer_symbols);        
    end
    if 1
        if t_samp<2
            t_samp = 2;
            disp('!');
        end
        n_symbols_extracted = extract_symbols_counter;
        buffer_symbols = [];
        e = [];
        alpha = 0.999;
        th = 0.1;
        while t_samp<length(buffer)-1 && n_symbols_extracted<100
            buffer_symbols = [buffer_symbols buffer(t_samp)]; %#ok<AGROW>
            sym = [buffer(t_samp-1) buffer(t_samp) buffer(t_samp+1)];
            e = [e err*alpha+(1-alpha)*(abs(sym(3))-abs(sym(1)))]; %#ok<AGROW>
            if abs(e(end))<th
                t_samp = t_samp+sps;
            else
                if e(end)>0
                    t_samp = t_samp+sps;
                else
                    t_samp = t_samp+sps;
                end
            end
            n_symbols_extracted = n_symbols_extracted+1;
            %lsp = t_samp+(t_samp-t_samp+length(buffer_symbols)*sps)-length(buffer);
            
        end
        while t_samp<length(buffer)-1 && n_symbols_extracted<4100
            buffer_symbols = [buffer_symbols buffer(t_samp)];
            sym = [buffer(t_samp-1) buffer(t_samp) buffer(t_samp+1)];
            e = [e err*alpha+(1-alpha)*(abs(sym(3))-abs(sym(1)))];
            if abs(e(end))<th
                t_samp = t_samp+sps;
            else
                if e(end)>0
                    t_samp = t_samp+sps;
                else
                    t_samp = t_samp+sps;
                end
            end
            n_symbols_extracted = n_symbols_extracted+1;
        end
        lsp = t_samp-length(buffer);
    end
end