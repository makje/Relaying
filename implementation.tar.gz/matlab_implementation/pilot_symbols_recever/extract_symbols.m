function y = extract_symbols(rx,t_samp,sps, have_signal, counter, header)
    if have_signal == 1
        if 0
            %fungerar, men inte om man har icke konstant sps...
            buffer_size = length(rx);
            symbols = rx(t_samp:sps:end); %%symbols from first packet.
            lsp = sps-(buffer_size-(t_samp+(length(symbols)-1)*sps));
            ctr = 0;
            y = struct('buffer_symbols', symbols, ...
                       'lsp', lsp, ...
                       'ctr', ctr);
        else
            if t_samp<2
                t_samp = 2;
                disp('!');
            end
            buffer_size = length(rx);
            symbols_et = rx(t_samp-1:sps:end);
            symbols_ot = rx(t_samp:sps:end); %%symbols from first packet.
            symbols_lt = rx(t_samp+1:sps:end);
            early = sum(abs(symbols_et))/length(symbols_et);
            late  = sum(abs(symbols_lt))/length(symbols_lt);
            th = 100;
            if abs(early-late)<th
                symbols = symbols_ot;
                lsp = sps-(buffer_size-(t_samp+(length(symbols)-1)*sps));
            else
                if early-late < 0
                    symbols = symbols_et;
                    lsp = sps-(buffer_size-(t_samp+(length(symbols)-1)*sps))+1;
                else
                    symbols = symbols_lt;
                    lsp = sps-(buffer_size-(t_samp+(length(symbols)-1)*sps))-1;
                end
            end
            %lsp = sps-(buffer_size-(t_samp+(length(symbols)-1)*sps));
            ctr = 0;
            y = struct('buffer_symbols', symbols, ...
                       'lsp', lsp, ...
                       'ctr', ctr);
            
        end
    else %%if have signal == 0
        symbols = -1;
        lsp = 0;
        ctr = 0;
        y = struct('buffer_symbols', symbols, ...
                       'lsp', lsp, ...
                       'ctr', ctr);
    end
end