//rx_main.cpp
#include "rx_top_block.h"

#include <signal.h>
#include <string.h>
#include <iostream>
#include <cstdio>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <boost/thread.hpp>

rx_top_block_sptr rx_top_block;
static volatile bool signaled = false;

static void 
sig_handler(int sig){
  signaled = true;
}

void print_message_function(){
	//volatile int pkt_counter = 0;
	while(!signaled){
	
	}
}

int main(int argc, char **argv){
	printf("Initilizing default values\n");
	//Default values.
	printf("Making top- block\n");
	rx_top_block = make_rx_top_block();
	
	printf("Install signal handler for SIGINT\n");
	struct sigaction action;
  	memset(&action, 0, sizeof(action));
	
  	action.sa_handler = sig_handler;
	sigemptyset(&action.sa_mask);
  	action.sa_flags = 0;
	
  	if(sigaction(SIGINT, &action, 0)<0){
		printf("Unable to install signal- handler!\n");
		return -1;
	}

	printf("Install signal handler for SIGALRM\n");
	struct sigaction alarm_action;
  	memset(&alarm_action, 0, sizeof(alarm_action));
	
  	alarm_action.sa_handler = sig_handler;
	sigemptyset(&alarm_action.sa_mask);
  	alarm_action.sa_flags = 0;
	
  	if(sigaction(SIGALRM, &alarm_action, 0)<0){
		printf("Unable to install signal- handler!\n");
		return -1;
	}

	rx_top_block->start();
	alarm(3);
	boost::thread message_thread(&print_message_function);
	message_thread.join(); //wait for the message- thread to compleate, ie Ctrl+C.
	
	rx_top_block->stop();
	
	return 0;
}
