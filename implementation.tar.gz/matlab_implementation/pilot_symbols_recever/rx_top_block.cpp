//rx_top_block.cpp
#include "rx_top_block.h"
#include <gruel/realtime.h>

#define SAVE_TO_DISK

const float PI_ = 3.141592653589793;

using namespace std;

rx_top_block_sptr make_rx_top_block(){
	return gnuradio::get_initial_sptr(new rx_top_block());
}

rx_top_block::rx_top_block():gr_top_block("rx_top_block"){
	if(gruel::RT_OK == gruel::enable_realtime_scheduling()){
		printf("Enabled realtime scheduling\n");
	}
	else{
		printf("Failed to enable realtime scheduling\n");
	}

	d_rf_freq = 3e6;
	d_gain = 10;
	d_rate = 0.5e6;
	d_rx_decimation_rate = 16;
	d_rrc_excess_bw = 0.5;

	d_rx_channel = 1;
	d_rrc_gain = 1.0;
	d_rrc_symbol_rate = 1.0;
	d_rrc_decimation = 1;

	printf("Create usrp source\n");
	d_rx = usrp_make_source_c();

	
	d_if_rate = d_rx->adc_rate()/d_rx_decimation_rate;
	d_sps = d_if_rate/d_rate;
	printf("if_rate: %ld\n",d_if_rate);
	printf("Decimation: %d\n",d_rx_decimation_rate);
	printf("d_sps: %lf\n",d_sps);
	d_rx_decimation_rate = d_rx->adc_rate()/d_if_rate;

	printf("Creating MF\n");
	printf("Matched- filter gain:\t\t%f\n",d_rrc_gain);
	printf("Matched- filter sps:\t\t%f\n",d_sps);
	printf("Matched- filter symbol rate:\t%f\n",d_rrc_symbol_rate);
	printf("Matched- filter excess bw:\t%f\n",d_rrc_excess_bw);
	printf("Matched- filter nr taps:\t%d\n",int(11*d_sps));

	std::vector<float> rrc_taps = gr_firdes::root_raised_cosine(d_rrc_gain,
								d_sps,
								d_rrc_symbol_rate,
								d_rrc_excess_bw,
								int(11*d_sps));
	d_rx_rrc = gr_make_fir_filter_ccf(d_rrc_decimation,rrc_taps);
		
	printf("Configure USRP\n");
	configure_usrp();

	/*
	printf("Creating signal constellation decoder cb\n");
	float t= sqrt(2)/2; //Normalize energy.
	
	gr_complex c[] = { 
		gr_complex(-t, t), gr_complex(t, t),
		gr_complex(-t,-t), gr_complex(t,-t)
	};
	std::vector<gr_complex> d_constellation(c,c+sizeof(c)/sizeof(gr_complex));
	char b[] = { 
		0x00, 0x01,
		0x02, 0x03
	}; //testat att det är såhär det moduleras med ovanstående konstellation.
kU
	std::vector<unsigned char> bit_values(b,b+sizeof(b)/sizeof(char));
	d_constellation_decoder = gr_make_constellation_decoder_cb(d_constellation, bit_values);
	*/
	d_agc = gr_make_agc2_cc (1e-5, 1e-5, 1.0, 1.0, 1.0);
	gr_file_sink_sptr dump = gr_make_file_sink(sizeof(gr_complex),"dump.dat");
	
	connect(d_rx,0,d_rx_rrc,0);
	//connect(d_rx,0,d_agc,0);
	//connect(d_agc,0,d_rx_rrc,0);
	connect(d_rx_rrc,0,dump,0);
	

}

void rx_top_block::configure_usrp(){
	d_rx->set_decim_rate(d_rx_decimation_rate);
	usrp_subdev_spec usds = d_rx->pick_rx_subdevice();
	d_rx->set_mux(d_rx->determine_rx_mux_value(usds));
	d_db = d_rx->selected_subdev(usds);
	d_db->set_enable(true);
	d_db->set_gain(10);
	d_rx->set_nchannels(1);
	
	usrp_tune_result result;
	d_rx->tune(d_db->which(), d_db, d_rf_freq, &result);
	printf("Tune result:\n");
	printf("Baseband freq:\t\t%lf\n",result.baseband_freq);
	printf("DXC freq:\t\t%lf\n",result.dxc_freq);
	printf("Resudal freq:\t\t%lf\n",result.residual_freq);
	printf("Spectrum inverted:\t");
	result.inverted?printf("Yes\n"):printf("No\n");
	return;
}

rx_top_block::~rx_top_block(){
	d_rx->write_io(0,-129,224);
	d_rx->write_io(0,-129,128);
}
