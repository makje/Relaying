%function [t_samp, corr_vector] = sync(mf, b_train, Q, t_start, t_end, have_signal)
function y = sync(x)

have_signal = x.have_signal;
synced = x.state_change;

if have_signal==1 && synced == 0
    mf = x.buffer;
    b_train = x.header;
    Q = x.sps;
    t_start = x.t_start;
    t_end = x.t_end;
    
    %% Clamp t_end
    %if t_end>length(mf)-(length(b_train)-1)*Q
    %    t_end=length(mf)-(length(b_train)-1)*Q;
    %end
    
    lc = length(b_train);
    c = modulate(b_train);

    tmp2 = -1*ones(size(mf));
    
    for t_s = t_start:t_end
        r = mf(t_s:Q:t_s+Q*(lc-1));
        %tmp2(t_s) = abs( r*conj(c)' );
        tmp2(t_s) = abs(r*c');
    end
    %keyboard
    %corr_vector = tmp2;
    [dummy t_samp] = max(tmp2);
    synced = 1;
else %%We dont have a signal... do as little as possible...
    %corr_vector = 0;
    tmp2 = 0;
    t_samp = 0;
    synced = 0;
end
    y = struct('t_samp', t_samp, ...
               'corr_vector', tmp2, ...
               'synced', synced);
end