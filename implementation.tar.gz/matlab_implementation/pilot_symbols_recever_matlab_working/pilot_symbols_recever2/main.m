%% Debug- script for qpsk- transmission with muxed pilots. RX- side
%% This script adds received symbols to the wrong packets. Try
%  correlate the packet- symbols with the modulated header and you will see
%  it clearly. Trying to fix this in main2.m
tic
clear all
home
close all
path(path,'/home/mattias/Projects/gnuradio/gnuradio-core/src/utils')
%% Read in data.
%!sudo ./rx_packer

rx_oneline = read_complex_binary('dump.dat');

%% Arrange variables
buffer_size = 4096;
n_buffers = round(length(rx_oneline)/buffer_size);
sps = 8; %Samples per symbol. Upsampling factor.
%fs = 8e6; %Sampling frequency
rrc_length = 11*sps; %Length of rx rrc- filter. Filtering done in c++
header = [2,0,1,3,2,3,0,0,3,0,2,1,3,2,1,3,3,2,2,2, ...
		  2,3,0,1,1,3,1,2,1,0,1,0,1,2,1,2,3,2,3,1, ...
		  2,2,1,0,2,2,2,0,1,2,3,2,2,2,1,1,2,3,1,2, ...
		  3,3,1,2,1,2,1,3,2,2,3,1,1,1,1,2,3,3,0,3, ...
		  3,1,1,1,2,2,3,1,2,2,2,3,1,3,3,3,3,2,2,1];
n_header_symbols = length(header);
n_data_symbols = 3000;
pilot_ratio = 1/4; %Four data, one pilot.

%Arrange the received data into buffers. More like gnuRadio's way 
rx = zeros(n_buffers,buffer_size);
for buffer=1:n_buffers-1
    rx(buffer,:) = rx_oneline((buffer-1)*buffer_size+1:(buffer)*buffer_size);
end

%Placeholder for symbols
symbols = -1*ones(n_buffers,buffer_size/sps); %placeholder for symbols

%Placeholder for packets, one packet per row, will probably not need as
%many rows as assigned...
packets_length_symbols = n_data_symbols+n_data_symbols*pilot_ratio+n_header_symbols;

packets = zeros(n_buffers,packets_length_symbols); %Uncorrected packets
cpackets= zeros(n_buffers,packets_length_symbols); %Corrected packets

header_h_hat = zeros(n_buffers,n_header_symbols); %Storage for correction in header
c_h_hat = zeros(n_buffers,n_data_symbols*(1+pilot_ratio)); %%Storage for corrections of data.

%These should probably be internal class-variables, but since this is
%Matlab...
lsp = 0; %last sample processed... Symbol- extracter
last_mean = 1000; %init to something large... Power squelsher
state = 'SEARCHING'; %init state. Power squelsher
synced = 0; % is the synchronizer synced or not? 1/0 init as not... Synchronizer
consumed = 1; % for packet assemler
pack_nr = 1; % packet assembler
pack_nr_change = 0; %if there is a new packet from the packet assembler 1/0.
counter = 0;
synced_pack_nr = 0;
extract_symbol_counter = 0;
early_late_error = 0;
early_late_error_vector = [];
mean_header_angle = 0;
%% Send read data through the receiver chain, one buffer at a time.
for k= 1:n_buffers;
    buffer = rx(k,:);
%% Power squelch
    db_threshold = 15; %db
    squelsh_struct = struct('buffer', buffer, ...
                            'db_th',  db_threshold,...
                            'last_mean', last_mean, ...
                            'state', state);
    ret_val = squelsh(squelsh_struct);
    
    last_mean = abs(ret_val.last_mean); %should be internal in squelsh...
    %% This can't be removed, needed for next turn in the loop, and it's
    %% the output of the squelsh- block.
    buffer = ret_val.buffer;
    state = ret_val.state;

    if strcmp(state,'HAVE_SIGNAL')
        have_signal = 1;
    else
        have_signal = 0;
    end
    if have_signal == 1
%% Synchronize
       %if synced_pack_nr ~= pack_nr
           %synced = 0;
       %end
       sync_struct = struct('buffer', buffer, ...
                            'header', header, ...
                            'sps',    sps, ...
                            't_start',1, ...
                            't_end' , length(buffer)-(length(header)-1)*sps, ...
                            'have_signal', have_signal, ...
                            'state_change', synced);
       sync_ret_struct = sync(sync_struct);

       t_samp_sync = sync_ret_struct.t_samp;
       sync_state_change = sync_ret_struct.synced;

%% Correct the phase.
       
%% Extract symbols
       if (lsp == 0)
           %t_samp = t_samp_sync+11*sps;
           t_samp = t_samp_sync;
       end
       
       extract_ret_struct = extract_symbols(buffer,t_samp,sps, have_signal, 0, 0);
       t_samp = extract_ret_struct.lsp;
       lsp = t_samp; %need to avoid resync.
       buffer_symbols = extract_ret_struct.buffer_symbols;
       early_late_error_vector = [early_late_error_vector ; extract_ret_struct.ctr'];
%% Assemble packets
        if consumed==0
            consumed=1
        end
        %If we can fit the symbols into the packet.
        if consumed+length(buffer_symbols) <= packets_length_symbols
            packets(pack_nr,consumed:consumed+length(buffer_symbols)-1) = buffer_symbols;
            consumed = consumed+length(buffer_symbols);
            
            %%Check the case that the symbols were exactly alligned...
            if consumed >= packets_length_symbols
                disp('odd case');
                pack_nr = pack_nr+1;
                pack_nr_change = 1; %%New packet created.
            end
        %%Symbols don't fit the packet. Re syncronize and Split!
        else
            %put the rest of the symbols into the packet
            possible_to_consume = packets_length_symbols-consumed;
            packets(pack_nr,consumed:packets_length_symbols-1)=buffer_symbols(1:possible_to_consume);
            pack_nr = pack_nr+1;
            pack_nr_change = 1; %%New packet created.
            packets(pack_nr,1:length(buffer_symbols)-possible_to_consume) = buffer_symbols(possible_to_consume+1:end);
            consumed = length(buffer_symbols)-possible_to_consume;
        end
    
%% Correct header phase on a packet by packet basis.
        if pack_nr_change == 1
            pack_nr_change = 0; %reset it...

            packets(pack_nr-1,:) = packets(pack_nr-1,:).*exp(-j*mean_header_angle);
            
            %%First correct header phase.
            for l=1:n_header_symbols
                header_h_hat(pack_nr-1,l) = packets(pack_nr-1,l)/modulate(header(l));
                cpackets(pack_nr-1,l) = packets(pack_nr-1,l)/header_h_hat(pack_nr-1,l);
            end

            %Correct data phase.
            pilot = modulate(0);
            for l=n_header_symbols+5:5:packets_length_symbols %%Osäker på denhär första 5:an
                c_h_hat(pack_nr-1,l) = packets(pack_nr-1,l)/pilot;
                cpackets(pack_nr-1,l-4:l) = packets(pack_nr-1,l-4:l)/c_h_hat(pack_nr-1,l);
            end
            
            mean_header_angle = mean(angle(header_h_hat(pack_nr-1,:)));
            %disp(['mean angle header: ' num2str(mean(angle(header_h_hat(pack_nr-1,:))))])
        end %%Packet_nr_change == 1
    end %%Have signal == 1
end %%Loop


%% Add pilots to transmitted data...
rand('twister',4657);
tx_data = ceil(4.*rand(4000,1))-1;
tdwp = zeros(n_data_symbols,1); %Tx Data With Pilots.
counter1 = 1;
counter2 = 4;
counter3 = 1;
counter4 = 4;
while counter4<=n_data_symbols
    tdwp(counter1:counter2) = tx_data(counter3:counter4);
    %disp(['tdwp(' num2str(counter1) ':' num2str(counter2) ') = tx_data(' num2str(counter3) ':' num2str(counter4) ')']);
    tdwp(counter2+1) = 0;
    counter1 = counter1+5;
    counter2 = counter2+5;
    counter3 = counter3+4;
    counter4 = counter4+4;
    
end
%Add header to the data, just to make my life easier
tdwp = [header tdwp'];
%% Difference between received data and transmitted data.
demodulated_packets = zeros(pack_nr-1,packets_length_symbols); %Demodulated packets.
for m=1:pack_nr-1
    demodulated_packets(m,:) = demodulate(cpackets(m,:));
end

ser = zeros(1,pack_nr-1);
for n=1:pack_nr-1
    sum_err = 0;
    for o=1:packets_length_symbols
        if demodulated_packets(n,o) ~= tdwp(o)
            sum_err = sum_err+1;
        end
    end
    ser(n) = sum_err/(length(tdwp));
end


%% Header correlations
header_correlation = zeros(1, pack_nr);
for k=1:pack_nr
    header_correlation(k) = abs(packets(k,1:100)*modulate(header)');
end
toc
figure(); semilogy(ser,'-o'), title('Symbol error rate'), xlabel('packet number');
figure(); plot(header_correlation,'-o'), title('correlation between 100 first symbols and header'), xlabel('packet number'), ylabel('correlation');

packets_oneline = [];
for k=1:pack_nr-1
    packets_oneline = [packets_oneline packets(k,:)];
end
demodulated_packets_oneline = demodulate(packets_oneline);

hk = [];
disp(['Will loop: ' num2str(length(demodulated_packets_oneline)-100) ' turns']);
modulated_header = modulate(header);
for k=1:length(demodulated_packets_oneline)/10
    tic
    hk = [hk abs(packets_oneline(k:k+99)*modulated_header')];
    if mod(k,100000) == 0
        disp(['k: ' num2str(k) '(' num2str(length(demodulated_packets_oneline)-100) ')']);
        toc
    end
end
