function y = squelsh(x)
    have_signal = 0; %just to default it...
    lm = mean(x.buffer);
    p = 10*log10(abs(lm/x.last_mean)); %power maybe it should be 20*...
    switch x.state;
        case 'SEARCHING'
            if p>x.db_th
                have_signal = 1;
                buff = x.buffer;
            else
                have_signal = 0;
                buff = zeros(size(x.buffer));
            end
        case 'HAVE_SIGNAL'
            if p<-x.db_th
                have_signal = 0;
                buff = zeros(size(x.buffer));
            else
                have_signal = 1;
                buff = x.buffer;
            end
    end
    if have_signal == 0
        state = 'SEARCHING';
    else
        state = 'HAVE_SIGNAL';
    end
    y = struct('buffer', buff, ...
               'db_th',  x.db_th,...
               'last_mean', lm, ...
               'state', state);
end