function buffer_out = dd_mpsk_sync(buffer_in)
%   const gr_complex *in = (gr_complex *) input_items[0];
%   gr_complex *out = (gr_complex *) output_items[0];
%   
    buffer_out = zeros(size(buffer_in));
    noutput_items = length(buffer_out);
    ii = 1; 
    oo = 1;
    d_alpha = 0.005;
    d_beta = 0.005;
    d_last_sample = 0;
    d_omega = 8;
    d_gain_omega = 1e-6;
    d_mu = 500e-6;
    d_gain_mu = 5e-6;
    DLLEN = 8;
    d_dl = zeros(2*DLLEN,1);
    d_dl_idx = 1;

    d_freq = 0;
    d_phase = 0;
    d_max_freq = 0.05;
    d_min_freq = -d_max_freq;

    while oo<noutput_items-DLLEN

        buffer_out(oo) = d_dl(d_dl_idx);
        
        error = sign(real(buffer_out(oo)))*imag(buffer_out(oo)) - ...
                sign(imag(buffer_out(oo)))*real(buffer_out(oo));
            
    d_freq = d_freq + d_beta * error;
    d_phase = d_phase + d_alpha * error;
    while d_phase>2*pi
      d_phase = d_phase -2*pi;
    end
    while d_phase<-2*pi
      d_phase = d_phase +2*pi;
    end

    if d_freq > d_max_freq
        d_freq = d_max_freq;
    else
        if d_freq < d_min_freq
            d_freq = d_min_freq;
        end
    end

    sliced_out = sign(real(buffer_out(oo)))+j*sign(imag(buffer_out(oo)));
    sliced_last= sign(real(d_last_sample))+j*sign(imag(d_last_sample));
    
    mm_val = real( d_last_sample*sliced_out - buffer_out(oo) * sliced_last );
    d_last_sample = buffer_out(oo);
    
    d_omega = d_omega + d_gain_omega * mm_val;
    d_mu = d_mu + d_omega + d_gain_mu * mm_val;

    while d_mu>= 1.0 && ii<length(buffer_in)
        d_mu = d_mu - 1;
        nco_out = cos(d_phase) - j*sin(d_phase);
        new_sample = buffer_in(ii) * nco_out;

        d_dl(d_dl_idx) = new_sample;
        d_dl((d_dl_idx+DLLEN)) = new_sample;
        d_dl_idx = mod(d_dl_idx+1,DLLEN)+1;
        d_phase = d_phase + d_freq;
        ii = ii+1;
    end
    oo = oo+1;
    end
end