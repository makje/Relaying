function [awgn reyligh] = theoretical_ber(EbN0_db, divOrder, M)

EbNoLin = 10.^(EbN0_db/10);
awgn = 0.5*erfc(sqrt(2*EbNoLin)/sqrt(2));

mgf_rayleigh_handle = @(s,gamma) 1./(1-s.*gamma);

k = log2(M);
gamma_c = EbNoLin * k / divOrder;  % average SNR per diversity channel
tol = 1e-4 ./ EbNoLin.^4;
tol(tol>1e-4) = 1e-4;
tol(tol<eps) = eps;
reyligh = zeros(size(EbNoLin));
PP = zeros(3,length(EbNoLin));
for j = 1:length(EbNoLin)
    for i=1:3
        f_theta1 = @(theta,M) - (sin((2*i-1)*pi/M))^2./(sin(theta)).^2;
        int_theta1 = @(theta,M,gamma) (mgf_rayleigh_handle(f_theta1(theta,M),gamma)).^divOrder;
        f_theta2 = @(theta,M) - (sin((2*i+1)*pi/M))^2./(sin(theta)).^2;
        int_theta2 = @(theta,M,gamma) (mgf_rayleigh_handle(f_theta2(theta,M),gamma)).^divOrder;
        PP(i,j) = 1/(2*pi) * quad(@(theta)int_theta1(theta,M,gamma_c(j)), 1e-6, pi*(M-(2*i-1))/M, tol(j), []) ...
            - 1/(2*pi) * quad(@(theta)int_theta2(theta,M,gamma_c(j)), 1e-6, pi*(M-(2*i+1))/M, tol(j), []);
    end
    reyligh(j) = 1/2 * ( PP(1,j) +  2*PP(2,j) + PP(3,j) );
end

end