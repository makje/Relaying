function y = qpsk_modulate(x)
    assert(mod(length(x),2)==0,'Error in qpsk_modulate(), length of x must be multiple of two');
% Symbol constellation.
%        |
%    00  |  01
% -------|------->    
%    10  |  11
%        |
y = zeros(1,length(x)/2);
counter = 1;
for k=1:2:length(x)
    im_part = 1;
    re_part = 1;
    if(x(k)==1)
        im_part = -1;
    end
    if(x(k+1)==0)
        re_part = -1;
    end
    y(counter) = (re_part+1j*im_part)/sqrt(2);
    counter = counter+1;
end


end %/function