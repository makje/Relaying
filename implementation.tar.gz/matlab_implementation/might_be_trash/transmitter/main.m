clear all
clc
clf
close all
%% Initialize variables
N = 20000; %number of bits
BITS_PER_SYMBOL = 2; %qpsk... will try to make it scalable...
sample_per_symbol = 16;
path_to_executable = '/home/mattias/Desktop/matlab_single_antenna';
transmitting_executable = 'single_antenna';
parameters = '0 1902500000 40 transmit';
file_name = 'data_to_usrp.dat'; %Name of file to write padded tx data to.

%% Generate pn- sequence.
shift_register = [0,1,0,1,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1];
shift_mask =     [0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
x = struct('d_shift_register', shift_register, ...
           'd_mask', shift_mask, ...
           'input', 1, ...
           'output',0);

scram_bits = zeros(1,N);
%make first turn in the loop manualy...
y = lfsr(x);
scram_bits(1) = y.output;

for k=2:N
    y = lfsr(y);
    scram_bits(k) = y.output;
end

%% Modulate scram_bits to complex symbols
symbols = modulator(scram_bits,BITS_PER_SYMBOL);

%% Upsample and "transmitt"
d_tx_taps_gnuradio = [-20.501858, -25.919361, -29.457640, -30.732800, -29.539513, -25.877220, -19.959919, -12.207938, -3.221556, 6.262206, 15.426723, 23.442678, 29.539513, 33.075565, 33.600861, 30.906799, 25.057825, 16.401432, 5.554426, -6.634668, -19.145220, -30.862339, -40.667419, -47.534477, -50.624451, -49.369518, -43.539551, -33.284161, -19.145220, -2.036933, 16.806978, 35.916683, 53.695339, 68.546570, 79.010902, 83.900581, 82.421440, 74.270775, 59.701595, 39.545208, 15.187336, -11.504016, -38.296844, -62.753754, -82.421440, -95.038429, -98.746193, -92.287239, -75.173477, -47.809345, -11.556050, 31.273153, 77.492554, 123.199257, 163.999527, 195.296341, 212.622711, 212.001602, 190.309433, 145.618408, 77.492554, -12.786051, -122.082115, -245.378891, -375.867401, -505.156158, -623.598267, -720.722473, -785.751038, -808.177734, -778.375610, -688.200745, -531.556763, -304.884155, -7.543851, 357.933350, 785.751038, 1266.917725, 1789.487061, 2338.959961, 2898.835449, 3451.280029, 3977.891113, 4460.507324, 4882.031250, 5227.218262, 5483.389160, 5641.029785, 5694.242676, 5641.029785, 5483.389160, 5227.218262, 4882.031250, 4460.507324, 3977.891113, 3451.280029, 2898.835449, 2338.959961, 1789.487061, 1266.917725, 785.751038, 357.933350, -7.543851, -304.884155, -531.556763, -688.200745, -778.375610, -808.177734, -785.751038, -720.722473, -623.598267, -505.156158, -375.867401, -245.378891, -122.082115, -12.786051, 77.492554, 145.618408, 190.309433, 212.001602, 212.622711, 195.296341, 163.999527, 123.199257, 77.492554, 31.273153, -11.556050, -47.809345, -75.173477, -92.287239, -98.746193, -95.038429, -82.421440, -62.753754, -38.296844, -11.504016, 15.187336, 39.545208, 59.701595, 74.270775, 82.421440, 83.900581, 79.010902, 68.546570, 53.695339, 35.916683, 16.806978, -2.036933, -19.145220, -33.284161, -43.539551, -49.369518, -50.624451, -47.534477, -40.667419, -30.862339, -19.145220, -6.634668, 5.554426, 16.401432, 25.057825, 30.906799, 33.600861, 33.075565, 29.539513, 23.442678, 15.426723, 6.262206, -3.221556, -12.207938, -19.959919, -25.877220, -29.539513, -30.732800, -29.457640, -25.919361, -20.501858];
%För att få samma form på filtret med
%"root_raised_cosine(Samples_per_symbol, rolloff, truncation)" använd
%rrc_taps = 20039*root_raised_cosin(16, 0.5, 5.5);
%Men den fungerar inte så bra med jämna sampel/symbol...
tx = upfirdn(symbols, d_tx_taps_gnuradio, sample_per_symbol);

%% Save transmit data to file
v = write_data_to_file(file_name, tx);
if v==0
    disp('Something went wrong during file- write!');
else
    disp(['Data written to file: ' file_name]);
end

%% Run transmitting software
ret = system(['cp ' file_name ' ' path_to_executable '/' file_name]);
if ret==0
    disp('data file copy to correct location');
else
    disp('error while copying data file...');
end

disp(['sudo ' path_to_executable '/' transmitting_executable ' ' parameters]);
