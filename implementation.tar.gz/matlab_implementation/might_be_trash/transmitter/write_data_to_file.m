function v = write_data_to_file(file_name, data)
padding = zeros(1,80000);
tmp = [padding, data];
to_file = zeros(length(tmp)*2,1);
counter = 1;

for k=1:length(tmp)
    to_file(counter) = real(tmp(k));
    to_file(counter+1) = imag(tmp(k));
    counter = counter+2;
end
clear tmp;

fd = fopen(file_name, 'w');
if (fd < 0)
    v = 0;
else
    v = fwrite (fd, to_file, 'int16');
end
fclose(fd);