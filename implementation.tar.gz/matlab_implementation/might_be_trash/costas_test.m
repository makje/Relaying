%% Costas test script... Show how alpha and beta changes the costas loops
%% response.
clear
close all
clc
Fs = 8e6;
N = 1000;
F1 = 1e6;
F2 = 2e6;
%in1 = [exp(j*2*pi*(F1/Fs)*(1:N)) exp(j*2*pi*(F2/Fs)*(1:N))];
in1 = [ zeros(1,100) (1)*ones(1,N*5)];

%function [optr, foptr] = costas_loop(input, alpha, beta, max_freq)

beta = 0.00025;

max_freq = 1/4; %range = 2* frequency shift...

out_alpha_change = zeros(10,length(in1),3);
counter = 1;
for k=0.001:0.001:0.01
    [out, f_error, e] = costas_loop(in1,k,beta,max_freq);
    out_alpha_change(counter,:,1) = out;
    out_alpha_change(counter,:,2) = f_error;
    out_alpha_change(counter,:,3) = e;
    counter = counter+1;
end


out_beta_change = zeros(10,length(in1),3);
counter = 1;
alpha = 0.005;
for k=0.0001:0.0001:0.001
    [out, f_error, e] = costas_loop(in1,alpha,k,max_freq);
    out_beta_change(counter,:,1) = out;
    out_beta_change(counter,:,2) = f_error;
    out_beta_change(counter,:,3) = e;
    counter = counter+1;
end
alpha= 0.005;
beta = 0.00025;
costas_out = zeros(length(in1),3);
[loop_response, f_error, e] = costas_loop(in1,alpha,beta,max_freq);
out(:,1) = loop_response;
out(:,2) = f_error;
out(:,3) = e;

lag = 10;
for k=lag:length(loop_response)
    subplot(2,2,1);plot(loop_response(k-(lag-1):k),'x'), axis([-1 1 -1 1]), title('loop response');
    subplot(2,2,2);plot(e(k-(lag-1):k),'rx'), title('error');
    subplot(2,2,3);plot(f_error(k-(lag-1):k),'gx'), title('frequency error')
    pause(0.005)
end