clear all
clc
clf
close all

%% Initialize variables
N = 6000; %number of bits
fs = 8e6;
BITS_PER_SYMBOL = 2; %qpsk... will try to make it scalable...
SAMPEL_PER_SYMBOL = 16;
save_data_to_file = 0;
simulate_receiver = 1; %Should the receiver be simulated? 1/0
plot_detailed_figures = 1; %should detailed plots be printed for every snr- point
file_name = 'data_to_usrp.dat'; %Name of file to write padded tx data to.

%costas_alpha = .005;
%costas_beta = .00025;
costas_alpha = 0.006;
costas_beta = 0.00025;
costas_max_freq = 0.5;
mm_mu = 0.5;
mm_gain_mu = 0.001;
mm_omega = SAMPEL_PER_SYMBOL; 
mm_gain_omega = 0.000001;
mm_omega_relative_limit = 0.0001;
d_tx_taps_gnuradio = [-20.501858, -25.919361, -29.457640, -30.732800, -29.539513, -25.877220, -19.959919, -12.207938, -3.221556, 6.262206, 15.426723, 23.442678, 29.539513, 33.075565, 33.600861, 30.906799, 25.057825, 16.401432, 5.554426, -6.634668, -19.145220, -30.862339, -40.667419, -47.534477, -50.624451, -49.369518, -43.539551, -33.284161, -19.145220, -2.036933, 16.806978, 35.916683, 53.695339, 68.546570, 79.010902, 83.900581, 82.421440, 74.270775, 59.701595, 39.545208, 15.187336, -11.504016, -38.296844, -62.753754, -82.421440, -95.038429, -98.746193, -92.287239, -75.173477, -47.809345, -11.556050, 31.273153, 77.492554, 123.199257, 163.999527, 195.296341, 212.622711, 212.001602, 190.309433, 145.618408, 77.492554, -12.786051, -122.082115, -245.378891, -375.867401, -505.156158, -623.598267, -720.722473, -785.751038, -808.177734, -778.375610, -688.200745, -531.556763, -304.884155, -7.543851, 357.933350, 785.751038, 1266.917725, 1789.487061, 2338.959961, 2898.835449, 3451.280029, 3977.891113, 4460.507324, 4882.031250, 5227.218262, 5483.389160, 5641.029785, 5694.242676, 5641.029785, 5483.389160, 5227.218262, 4882.031250, 4460.507324, 3977.891113, 3451.280029, 2898.835449, 2338.959961, 1789.487061, 1266.917725, 785.751038, 357.933350, -7.543851, -304.884155, -531.556763, -688.200745, -778.375610, -808.177734, -785.751038, -720.722473, -623.598267, -505.156158, -375.867401, -245.378891, -122.082115, -12.786051, 77.492554, 145.618408, 190.309433, 212.001602, 212.622711, 195.296341, 163.999527, 123.199257, 77.492554, 31.273153, -11.556050, -47.809345, -75.173477, -92.287239, -98.746193, -95.038429, -82.421440, -62.753754, -38.296844, -11.504016, 15.187336, 39.545208, 59.701595, 74.270775, 82.421440, 83.900581, 79.010902, 68.546570, 53.695339, 35.916683, 16.806978, -2.036933, -19.145220, -33.284161, -43.539551, -49.369518, -50.624451, -47.534477, -40.667419, -30.862339, -19.145220, -6.634668, 5.554426, 16.401432, 25.057825, 30.906799, 33.600861, 33.075565, 29.539513, 23.442678, 15.426723, 6.262206, -3.221556, -12.207938, -19.959919, -25.877220, -29.539513, -30.732800, -29.457640, -25.919361, -20.501858];
channel_filter_taps= [ 0.000932948, 0.0018801, 0.00153291, -0.00118865, -0.00540242, -0.00664081, 4.2447e-18, 0.0128483, 0.0203788, 0.00882501, -0.0222674, -0.0505095, -0.0403626, 0.0301637, 0.145668, 0.254549, 0.299185, 0.254549, 0.145668, 0.0301637, -0.0403626, -0.0505095, -0.0222674, 0.00882501, 0.0203788, 0.0128483, 4.2447e-18, -0.00664081, -0.00540242, -0.00118865, 0.00153291, 0.0018801, 0.000932948];
d_rx_taps =          [ -0.000256273, -0.000323992, -0.00036822, -0.00038416, -0.000369244, -0.000323465, -0.000249499, -0.000152599, -4.02695e-05, 7.82776e-05, 0.000192834, 0.000293033, 0.000369244, 0.000413445, 0.000420011, 0.000386335, 0.000313223, 0.000205018, 6.94303e-05, -8.29334e-05, -0.000239315, -0.000385779, -0.000508343, -0.000594181, -0.000632806, -0.000617119, -0.000544244, -0.000416052, -0.000239315, -2.54617e-05, 0.000210087, 0.000448959, 0.000671192, 0.000856832, 0.000987636, 0.00104876, 0.00103027, 0.000928385, 0.00074627, 0.000494315, 0.000189842, -0.0001438, -0.000478711, -0.000784422, -0.00103027, -0.00118798, -0.00123433, -0.00115359, -0.000939668, -0.000597617, -0.000144451, 0.000390914, 0.000968657, 0.00153999, 0.00204999, 0.0024412, 0.00265778, 0.00265002, 0.00237887, 0.00182023, 0.000968657, -0.000159826, -0.00152603, -0.00306724, -0.00469834, -0.00631445, -0.00779498, -0.00900903, -0.00982189, -0.0101022, -0.00972969, -0.00860251, -0.00664446, -0.00381105, -9.42981e-05, 0.00447417, 0.00982189, 0.0158365, 0.0223686, 0.029237, 0.0362354, 0.043141, 0.0497236, 0.0557563, 0.0610254, 0.0653402, 0.0685424, 0.0705129, 0.071178, 0.0705129, 0.0685424, 0.0653402, 0.0610254, 0.0557563, 0.0497236, 0.043141, 0.0362354, 0.029237, 0.0223686, 0.0158365, 0.00982189, 0.00447417, -9.42981e-05, -0.00381105, -0.00664446, -0.00860251, -0.00972969, -0.0101022, -0.00982189, -0.00900903, -0.00779498, -0.00631445, -0.00469834, -0.00306724, -0.00152603, -0.000159826, 0.000968657, 0.00182023, 0.00237887, 0.00265002, 0.00265778, 0.0024412, 0.00204999, 0.00153999, 0.000968657, 0.000390914, -0.000144451, -0.000597617, -0.000939668, -0.00115359, -0.00123433, -0.00118798, -0.00103027, -0.000784422, -0.000478711, -0.0001438, 0.000189842, 0.000494315, 0.00074627, 0.000928385, 0.00103027, 0.00104876, 0.000987636, 0.000856832, 0.000671192, 0.000448959, 0.000210087, -2.54617e-05, -0.000239315, -0.000416052, -0.000544244, -0.000617119, -0.000632806, -0.000594181, -0.000508343, -0.000385779, -0.000239315, -8.29334e-05, 6.94303e-05, 0.000205018, 0.000313223, 0.000386335, 0.000420011, 0.000413445, 0.000369244, 0.000293033, 0.000192834, 7.82776e-05, -4.02695e-05, -0.000152599, -0.000249499, -0.000323465, -0.000369244, -0.00038416, -0.00036822, -0.000323992, -0.000256273];

f_offset_range = 30e3; %Hz

%EbN0_db = 0:20;
%nr_blocks = 30;
EbN0_db = 200;
nr_blocks = 1;

nr_errors = zeros(length(EbN0_db),1);
mean_frequency_error = zeros(length(EbN0_db),1); %save the mean of frequency error estimate
real_frequency_error = zeros(length(EbN0_db),1); %save the "real frequency errors
tsamp_save = zeros(length(EbN0_db),nr_blocks); %save the mean of t_samp
%% Generate pn- sequence.
shift_register = [0,1,0,1,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1];
shift_mask =     [0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
x = struct('d_shift_register', shift_register, ...
           'd_mask', shift_mask, ...
           'input', 1, ...
           'output',0);
scram_bits = scrambler(x,N);

%% Modulate scram_bits to complex symbols
symbols = modulator(scram_bits,BITS_PER_SYMBOL);

%% Upsample and "transmitt"
%För att få samma form på filtret med
%"root_raised_cosine(samples_per_symbol, rolloff, truncation)" använd
%rrc_taps = 20039*root_raised_cosin(16, 0.5, 5.5);
%Men den fungerar inte så bra med jämna sampel/symbol...
tx = upfirdn(symbols, d_tx_taps_gnuradio, SAMPEL_PER_SYMBOL);

%% Save transmit data to file
if save_data_to_file == 1
    v = write_data_to_file(file_name, tx);
    if v==0
        disp('Something went wrong during file- write!');
    else
        disp(['Data written to file: ' file_name]);
    end
end

for snr_point = 1:length(EbN0_db)
    disp(['snr_point: ' num2str(snr_point) '= ' num2str(EbN0_db(snr_point)) 'dB']);
    tic
    f_offset = -(f_offset_range/fs)+(2*f_offset_range/fs).*rand(1,1);
    for blk = 1:nr_blocks
        disp(['blk: ' num2str(blk)]);
%% Simulation of channel...
        if simulate_receiver==1
            if 1 %%Sänd sekvens är kortare än mottagen.
                rx = zeros(length(tx)*3,1);
                
                sigma_sqr=norm(d_tx_taps_gnuradio)/ BITS_PER_SYMBOL /10^(EbN0_db(snr_point)/10);
                %noise = sqrt(sigma_sqr/2)*(randn(size(rx)).*exp(j*2*pi*rand(size(rx)))); %noise vector
                noise = sqrt(sigma_sqr/2)*randn(size(rx)); %noise vector
                frequency_noise = exp((j*2*pi*f_offset)*(1:length(tx)));
                rx = noise;
                start = 1000;
                %start = round(0.5e5 + (3.5e5-0.5e5).*rand(1,1));
                rx(start:start+length(tx)-1) = rx(start:start+length(tx)-1) + (tx'.*frequency_noise');
            else %%Sänd sekvens är lika lång som mottagen
                sigma_sqr=norm(d_tx_taps_gnuradio)/ BITS_PER_SYMBOL /10^(EbN0_db(snr_point)/10);
                n = sqrt(sigma_sqr/2)*(randn(size(tx)).*exp(j*2*pi*rand(size(tx)))); %noise vector

                frequency_noise = exp((j*2*pi*f_offset)*(1:length(tx)));
                rx = tx.*frequency_noise+n;
            end
%% RECEIVER
            %training_sequence = shift_register; 
            %ts_rrc = upfirdn(training_sequence, d_tx_taps_gnuradio, 16);

%% "Channel filter", lpf before syncronization.
%            rx_lp = conv(rx,channel_filter_taps);
%% RRC- filter
            rx_rrc = conv(rx,d_rx_taps);
            %rx_rrc=conv(fliplr(pulse_shape),rx);

%% Synchronize, Frequnecy
            [rx_freq_synced,frequency_errors,costas_error] = costas_loop(rx_rrc, costas_alpha, costas_beta, costas_max_freq);

%% Find "start"
            [t_samp sync_corr] = sync(rx_freq_synced', scram_bits(1:128), SAMPEL_PER_SYMBOL, 1, length(rx_freq_synced)-16*128);
            disp(['t_samp: ' num2str(t_samp)]);
%% Synchronize, Time
            %% Den första raden fungerar om längden av mottagen signal är lika med
            %% längden av sänd signal.
            %[rx_time_freq_synced, timing_errors] = m_and_m_algorithm(rx_freq_synced(round(length(channel_filter_taps)/2+length(d_rx_taps)/2):end)-mm_omega/2, mm_mu, mm_gain_mu, mm_omega, mm_gain_omega, mm_omega_relative_limit);
            %[rx_time_freq_synced, timing_errors] = m_and_m_algorithm(rx_freq_synced(t_samp:end), mm_mu, mm_gain_mu, mm_omega, mm_gain_omega, mm_omega_relative_limit);
            %rx_time_freq_synced = rx_freq_synced(t_samp:16:t_samp+16*N);
            
            symbols = zeros(N/BITS_PER_SYMBOL,1); 
            symbols(:,1) = rx_freq_synced(t_samp:SAMPEL_PER_SYMBOL:t_samp+SAMPEL_PER_SYMBOL*N/BITS_PER_SYMBOL-1);
            training_symbols = modulator(scram_bits(1:64),BITS_PER_SYMBOL);
            
            rx_time_freq_synced = symbols;
%% Downsample
            %done in m_and_m_algorithm...

%% Demodulate syncronized received symbols
            %scram_bits2 = demodulator(rx_time_freq_synced(1:N/2),BITS_PER_SYMBOL);
            %scram_bits2 = demodulator(rx_time_freq_synced,BITS_PER_SYMBOL);
            rx_scram_bits = zeros(N,1);
            rx_scram_bits(:,1) = demodulator(symbols(:,1),BITS_PER_SYMBOL);

%% Despread the bits
            shift_register = [0,1,0,1,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1];
            shift_mask =     [0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
            %x = struct('d_shift_register', shift_register, ...
            %           'd_mask', shift_mask, ...
            %           'input', scram_bits2(1), ...
            %           'output',0);
            %descram_bits = descrambler(x,scram_bits2,N);
            x = struct('d_shift_register', shift_register, ...
                       'd_mask', shift_mask, ...
                       'input', rx_scram_bits(1,1), ...
                       'output',0);
            descram_bits = zeros(N,1);
            descram_bits(:,1) = descrambler(x,rx_scram_bits(:,1),N);
    
            error_density_this_run = 1-sum(descram_bits)/length(descram_bits);
            nr_errors(snr_point) = nr_errors(snr_point) + error_density_this_run;
            mean_frequency_error(snr_point) = mean_frequency_error(snr_point) + mean(frequency_errors);
            tsamp_save(snr_point,blk) = t_samp;
        end
    end
    toc
    disp(['SNR: ' num2str(EbN0_db(snr_point)) 'dB']);
    disp(['Mean frequency errors: ' num2str(mean(frequency_errors)*fs) 'Hz']);
    disp(['Frequency offset: ' num2str(f_offset*fs) 'Hz']);
    disp(['mean frequency estimation error: ' num2str((mean(frequency_errors)-f_offset)*fs) 'Hz']);
    if plot_detailed_figures == 1
        figure();
            plot(rx_freq_synced(1:16:end),'.');
            title(['frequency syced signal, SNR: ' num2str(EbN0_db(snr_point)) 'dB'])
        figure();
            plot(rx_time_freq_synced,'.'), 
            title(['time and frequency synced signal, SNR: ' num2str(EbN0_db(snr_point)) 'dB'])
        figure();
            plot(frequency_errors), hold on
            plot(ones(length(frequency_errors),1)*f_offset,'r')
            plot(ones(length(frequency_errors),1)*mean(frequency_errors),'g')
            title(['frequency errors, SNR: ' num2str(EbN0_db(snr_point)) 'dB'])
            legend('Estimated frequency offset',['Real frequency offset ' num2str(f_offset) '\nu'],['Mean estimated frequency offset ' num2str(mean(frequency_errors)) '\nu']);
        %figure();
        %    plot(timing_errors)
        %    title(['Timing errror, SNR: ' num2str(EbN0_db(snr_point)) 'dB']);
        figure();
            plot(ones(length(descram_bits),1),'ro'), hold on
            plot(descram_bits,'-x'), axis([0 length(descram_bits) -1 2])
            title(['original bit sequence, and descrambled bits, SNR: ' num2str(EbN0_db(snr_point)) 'dB']);
            legend('original bit sequence', 'descrambled bits')
    end
    real_frequency_error(snr_point) = f_offset;
end
BER = (nr_errors / nr_blocks) / sum(shift_mask);
mean_frequency_error = mean_frequency_error/nr_blocks;

%% Stuff for comparing ber with theoretical limits.
diversity_order = 2;
M = BITS_PER_SYMBOL^2;
[ber_awgn, ber_fading] = theoretical_ber(EbN0_db,diversity_order,M);

%% Plot and print
if 0
disp('BER: '); BER
figure();
    semilogy(ber_awgn,'ro-'), hold on
    semilogy(ber_fading,'go-')
    semilogy(BER,'x-')
    title('Ber')
    legend('theoretical ber awgn',['theoretical ber fading, diversity ' num2str(diversity_order)], 'ber')
figure();
    plot(EbN0_db,((real_frequency_error-mean_frequency_error).^2)), hold on
    plot(EbN0_db,(ones(length(EbN0_db),1)*mean((real_frequency_error-mean_frequency_error).^2)),'r');
    title('(real frequency error- mean frequency error)^2')
    legend('(f_e - E[f_e])^2', ['E[(f_e - E[f_e])^2] = ' num2str(mean((real_frequency_error-mean_frequency_error).^2)*fs) ' Hz']);
    xlabel('SNR dB')
end
% end

%% Animation of costas- loop output.
%figure();
%paint_lag = 500;
%loop_response = rx_freq_synced;
%for k=paint_lag:length(loop_response)
%    plot(loop_response(k-(paint_lag-1):k),'x')
%    axis([-6000 6000 -6000 6000]);
%    pause(0.005)
%end