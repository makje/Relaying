#include <iostream>
#include "rx_path.h"
#include <gruel/realtime.h>

// Shared pointer constructor
//tx_path::tx_path(int interpolation_rate, int channel, int side, int gain, double rf_freq)
rx_path_sptr make_rx_path(int decimation_rate, int channel, int side, int gain, double rf_freq, int n_buffers){
  return gnuradio::get_initial_sptr(new rx_path(decimation_rate, channel, side, gain, rf_freq, n_buffers));
}

rx_path::rx_path(int decimation_rate, int channel, int side, int gain, double rf_freq, int n_buffers):gr_top_block("rx"){

	printf("Enable Realtime scheduling... ");
	gruel::enable_realtime_scheduling()!=gruel::RT_OK ? printf("Failed\n"):printf("Success\n");

	int magic_number = 10240;
	d_s0 = my_gr_make_file_sink(sizeof(short),"./data_from_usrp.dat",magic_number*n_buffers);
	d_u0 = usrp_make_source_s();
	configure_usrp(decimation_rate,rf_freq, gain, channel);

	printf("Connect usrp and file sink...\n");
	connect(d_u0,0, d_s0,0);
}

void rx_path::configure_usrp(int decim, double rf_freq, int gain, int channel){
	d_u0->set_decim_rate (decim);
	usrp_subdev_spec usds = d_u0->pick_rx_subdevice();
	d_u0->set_mux(d_u0->determine_rx_mux_value(usds));
	d_db = d_u0->selected_subdev(usds);
	d_db->set_enable(true);
	d_db->set_gain(gain);
	d_u0->set_nchannels(channel);
	
	usrp_tune_result result;
	d_u0->tune(d_db->which(), d_db, rf_freq, &result);
	printf("Tune result:\n");
	printf("Baseband freq:\t\t%lf\n",result.baseband_freq);
	printf("DXC freq:\t\t%lf\n",result.dxc_freq);
	printf("Resudal freq:\t\t%lf\n",result.residual_freq);
	printf("Spectrum inverted:\t");
	result.inverted?printf("Yes\n"):printf("No\n");
	return;
}

