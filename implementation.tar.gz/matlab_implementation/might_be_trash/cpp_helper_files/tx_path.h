#include <gruel/realtime.h>
#include <gr_file_sink.h>
#include <usrp_source_s.h>
#include <gr_file_source.h>
#include <usrp_subdev_spec.h>
#include <usrp_sink_s.h>
#include <gr_top_block.h>

class tx_path;
typedef boost::shared_ptr<tx_path> tx_path_sptr;
tx_path_sptr make_tx_path(int interpolation_rate, int channel, int side, int gain, double rf_freq);

class tx_path : public gr_top_block{
	private:
		int 			d_interpolation_rate;
		int 			d_channel;
		int 			d_side;
		int 			d_gain;
		double 			d_rf_freq;
		usrp_sink_s_sptr	d_tx0;
		db_base_sptr 		d_db0;
		gr_file_source_sptr	d_file_src;
	public:
    		tx_path(int interpolation_rate, int channel, int side, int gain, double rf_freq);
		void configure_usrp(int interp, int gain, int channel, double rf_freq);
		~tx_path();
    friend tx_path_sptr make_tx_path(int, int, int, int, double);
};
