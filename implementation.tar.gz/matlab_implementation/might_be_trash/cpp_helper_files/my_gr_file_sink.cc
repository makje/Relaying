/* -*- c++ -*- */
/*
 * Copyright 2004,2006,2007 Free Software Foundation, Inc.
 * 
 * This file is part of GNU Radio
 * 
 * GNU Radio is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * GNU Radio is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with GNU Radio; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "my_gr_file_sink.h"
#include <gr_io_signature.h>
#include <stdexcept>

#include <iostream>

/** Test för att skicka SIGRTMIN*/
#include<stdio.h>
#include<signal.h>
#include<sys/time.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<time.h>
#include<fcntl.h>
#include <string.h>

#include <errno.h> 
#include <sys/types.h>
#include <unistd.h>

my_gr_file_sink_sptr
my_gr_make_file_sink (size_t itemsize, const char *filename, long final_size)
{
  return my_gr_file_sink_sptr (new my_gr_file_sink (itemsize, filename, final_size));
}

my_gr_file_sink::my_gr_file_sink(size_t itemsize, const char *filename, long final_size)
  :gr_file_sink(itemsize, filename){
	d_itemsize = itemsize;
	d_my_number_of_items = 0;
	d_my_final_size = final_size;
}

my_gr_file_sink::~my_gr_file_sink(){
}

int 
my_gr_file_sink::work (int noutput_items,
		    gr_vector_const_void_star &input_items,
		    gr_vector_void_star &output_items)
{
  char *inbuf = (char *) input_items[0];
  int  nwritten = 0;

  do_update();				// update d_fp is reqd
  
  if (!d_fp)
    return noutput_items;		// drop output on the floor


  while (nwritten < noutput_items){
    int count = fwrite (inbuf, d_itemsize, noutput_items - nwritten, d_fp);
    if (count == 0){	// FIXME add error handling
			break;
		}
    nwritten += count;
    inbuf += count * d_itemsize;
  }
	d_my_number_of_items = d_my_number_of_items + nwritten;
	if(d_my_number_of_items>d_my_final_size){
	/*
		union sigval sval;
		memset(&sval, 0, sizeof(sval));
		pid_t pid = getpid();
		int ret = sigqueue(pid, SIGRTMIN, sval);
		if(ret<0){
			printf("Sigqueue returned: %d\n",ret);
			printf("%s\n",strerror(errno));
		}
	*/	
		return -1;
	}
  return nwritten;
}