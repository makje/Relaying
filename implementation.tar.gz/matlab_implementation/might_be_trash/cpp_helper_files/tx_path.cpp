#include "tx_path.h"

//#include <stdio.h>
#include <iostream>
#include <iomanip>
using namespace std;
tx_path_sptr make_tx_path(int interpolation_rate, int channel, int side, int gain, double rf_freq){
  return gnuradio::get_initial_sptr(new tx_path(interpolation_rate, channel, side, gain, rf_freq));
}

tx_path::tx_path(int interpolation_rate, int channel, int side, int gain, double rf_freq):gr_top_block("tx_path"){

	d_interpolation_rate = interpolation_rate;
	d_channel = channel;
	d_side = side;
	d_gain = gain;
	d_rf_freq = rf_freq;

	printf("Enable Realtime scheduling... ");
	gruel::enable_realtime_scheduling()!=gruel::RT_OK ? printf("Failed\n"):printf("Success\n");
	
	d_tx0 = usrp_make_sink_s();
	d_file_src = gr_make_file_source(sizeof(short), "data_to_usrp.dat", true);
	configure_usrp(d_interpolation_rate, d_gain, d_channel, d_rf_freq);

	printf("Connect file source and usrp sink...\n");
	connect(d_file_src,0, d_tx0,0);
}

void tx_path::configure_usrp(int interp, int gain, int channel, double rf_freq){
  d_tx0->set_interp_rate (interp);
  usrp_subdev_spec usds = d_tx0->pick_tx_subdevice();
  d_tx0->set_mux(d_tx0->determine_tx_mux_value(usds));
  d_db0 = d_tx0->selected_subdev(usds);
  d_db0->set_enable(true);
  d_db0->set_gain(gain);
  d_tx0->set_nchannels(channel);
  usrp_tune_result result;
  if(d_tx0->tune(d_db0->which(), d_db0, d_rf_freq, &result)){
	printf("Success\n");
	printf("Baseband frequency:\t%f\n",result.baseband_freq);
	printf("Dxc- frequency:\t\t%f\n",result.dxc_freq);
	printf("Resudal frequency:\t%f\n",result.residual_freq);
	printf("Spectrum Inverted:\t");
	result.inverted?printf("yes\n"):printf("no\n");
  }
  else{
	printf("Failed\n");
  }
  return;
}
tx_path::~tx_path(){
	printf("In tx_path destructor::\n");
	printf("write 0x%0x using mask 0x%0x ... ",-129,224);
	d_tx0->write_io (d_side, -129, 224) ? printf("Success\n"):printf("Failed\n");
  	printf("write 0x%0x using mask 0x%0x ... ",-129,128);
	d_tx0->write_io (d_side, -129, 128) ? printf("Success\n"):printf("Failed\n");

	//printf("set_enable(false)... ");
	//d_db0->set_enable(false) ? printf("Success\n"):printf("Failed\n");
	//printf("Stopping ...");
	//d_tx0->stop() ? printf("Success\n"):printf("Failed\n");
}
