//My gr_file_sink.
#include <gr_file_sink.h>

class my_gr_file_sink;
typedef boost::shared_ptr<my_gr_file_sink> my_gr_file_sink_sptr;

my_gr_file_sink_sptr my_gr_make_file_sink(size_t itemsize, const char *filename, long final_size);

class my_gr_file_sink : public gr_file_sink
{
  friend my_gr_file_sink_sptr my_gr_make_file_sink(size_t itemsize, const char *filename, long final_size);

 private:
  size_t	d_itemsize;
	long d_my_number_of_items;
	long d_my_final_size;

 protected:
  my_gr_file_sink(size_t itemsize, const char *filename, long final_size);

 public:
  ~my_gr_file_sink();

  int work(int noutput_items,
	   gr_vector_const_void_star &input_items,
	   gr_vector_void_star &output_items);
};

