//test002.h
#include <gr_top_block.h>
#include "my_gr_file_sink.h"
#include <usrp_source_s.h>
#include <usrp_subdev_spec.h>

class rx_path;
typedef boost::shared_ptr<rx_path> rx_path_sptr;

rx_path_sptr make_rx_path(int, int, int, int, double, int);

class rx_path : public gr_top_block{
	private:
		usrp_source_s_sptr	d_u0;
		my_gr_file_sink_sptr	d_s0;	
		db_base_sptr 		d_db;
		rx_path(int, int, int, int, double, int);
		void configure_usrp(int, double, int, int);
	public:
    friend rx_path_sptr make_rx_path(int, int, int, int, double, int);
};
