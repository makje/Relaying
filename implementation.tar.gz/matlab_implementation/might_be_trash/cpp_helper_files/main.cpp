//Main.cpp
#include "tx_path.h"
#include "rx_path.h"
#include <string.h>
#include <signal.h>
#include <gr_local_sighandler.h>

#include<stdio.h>
#include<signal.h>
#include<sys/time.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<time.h>
#include<fcntl.h>

/*FIXME: Used for txrx...*/
rx_path_sptr top_block1;
tx_path_sptr top_block2;

static void sig_handler(int sig){
	if(sig == SIGALRM){
		printf("SIGALRM raised\n");
		top_block2->stop();
		printf("top_block2->stop() executed\n");
	}
	if(sig == SIGRTMIN){
		printf("SIGRTMIN raised\n");
		top_block1->wait();
		printf("top_block1->wait() executed\n");
	}
}


int main(int argc,char **argv){
	//Init vairables.
	double rf_freq = 0.0; 
	int gain = 0;
	int n_buffers = 0;
	bool do_transmit = false;
	bool do_receive = false;
	bool do_txrx = false;
	int sig = 0; //used as return- value from sigwait()
	sigset_t set_int; //set of signals to wait for in sigwait()
	sigset_t set_alrm;
	sigset_t set_rtmin;

	if (strncmp(argv[4],"transmit",8)==0)
		do_transmit = true;

	if (strncmp(argv[4],"receive",7)==0)
		do_receive = true;

	if (strncmp(argv[4],"txrx",7)==0)
		do_txrx = true;

	struct sigaction new_action;	//create structure
 	memset (&new_action, 0, sizeof (new_action)); //zero set the structure

 	new_action.sa_handler = sig_handler; //add pointer to signal- handling function
 	sigemptyset (&new_action.sa_mask); //zero- set the signal mask.
 	new_action.sa_flags = 0; // flags... ??

	//Install do-nothing-on-SIGINT-signal-handler.
 	if (sigaction(SIGINT, &new_action, 0) < 0){
	    printf("sigaction (install new)");
 	}

	if (sigaction(SIGRTMIN, &new_action, 0) < 0){
	    printf("sigaction (install new)");
 	}
	if (sigaction(SIGALRM, &new_action, 0) < 0){
		printf("Failed to install SIGALRM action\n");
	}

	sigemptyset(&set_int); //empty the signalset used with sigwait()
	sigaddset(&set_int, SIGINT); //add SIGINT to signal- set
	
	n_buffers = atoi(argv[1]);
 	rf_freq=atof(argv[2]);
	gain=atoi(argv[3]);

	if (do_transmit){ //launch transmit
		//tx_path(int interpolation_rate, int channel, int side, int gain, double rf_freq);
		tx_path_sptr top_block = make_tx_path(16, 1, 0, gain, rf_freq);
		top_block->start();
		sigwait(&set_int,&sig);
		top_block->stop();
	}
	if (do_receive){ //launch receive.
		//make_rx_path(decimation_rate,channel,side,gain,rf_freq,n_buffers)
		rx_path_sptr top_block = make_rx_path(8, 1, 0, gain, rf_freq, n_buffers);
		top_block->run();
		//sigwait(&set_rtmin,&sig);
		//top_block->stop();
	}
	if(do_txrx){
		
		top_block1 = make_rx_path(8, 1, 1, gain, rf_freq, n_buffers);
		top_block2 = make_tx_path(16,1,0,gain,rf_freq);
		
		long alarm_interval = 500000;
		struct itimerval itimer;
		memset(&itimer, 0, sizeof(itimer));
		//sätt timer- intervall
		setitimer(ITIMER_REAL,&itimer,NULL);
		sigemptyset(&set_alrm); //töm "set:et"
		sigaddset(&set_alrm, SIGALRM); //läggtill sigalrm till set:et
		itimer.it_interval.tv_usec = alarm_interval;
		itimer.it_value.tv_usec = alarm_interval;
		//Sätt timern.
		setitimer(ITIMER_REAL,&itimer,NULL);
		
		int counter = 0;
		while(counter++<2){
			top_block2->start();
			sigwait(&set_alrm,&sig);
			top_block2->wait();
			//sleep(1);
			top_block1->run();
			//top_block1->start();
			sigwait(&set_rtmin,&sig);
			top_block1->wait();
		}
	}
	
	return 0;
}
