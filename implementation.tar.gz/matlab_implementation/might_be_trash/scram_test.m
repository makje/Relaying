%% Scramble -> descramble test

N = 10000; %antal bitar.
introduce_error_in_scrambled_bit_stream = 1; %1/0

%0x8A, 0x7F, 7
%8A (hex) = 10001010 (bin)
%7F (hex) = 01111111 (bin)
%(int mask, int seed, int len)

shift_register = [0,1,1,1,1,1,1,1];
shift_mask =     [1,0,0,0,1,0,1,0];
x = struct('d_shift_register', shift_register, ...
           'd_mask', shift_mask, ...
           'input', 1, ...
           'output',0);
scram_bits = scrambler(x,N);
[r_scrambits, lags] = xcorr(scram_bits);

if introduce_error_in_scrambled_bit_stream == 1
    for k=1:length(shift_register)
        start = 1000*k;
        for l=start:start+(k-1)
            scram_bits(l) = mod(scram_bits(l)+1,2);
        end
    end
end

x = struct('d_shift_register', shift_register, ...
           'd_mask', shift_mask, ...
           'input', scram_bits(1), ...
           'output',0);
descram_bits = descrambler(x,scram_bits,N);

plot(descram_bits), title('despread bits'), xlabel('bit number'), ylabel('bit value')
axis([0 length(descram_bits) -1 2]);
