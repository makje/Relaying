% GPL
% [output, timing_errors] = m_and_m_algorithm(input, mu, gain_mu, omega,
% omega_gain, omega_relative_limit)
%
function [output, timing_errors] = m_and_m_algorithm(input, mu, gain_mu, omega, omega_gain, omega_relative_limit)
    d_mu = mu;
    d_gain_mu = gain_mu;
    d_omega = omega;
    d_gain_omega = omega_gain;
    d_omega_relative_limit = omega_relative_limit;
    d_min_omega = d_omega*(1.0 - d_omega_relative_limit);% minimum allowed omega
    d_max_omega = d_omega*(1.0 + d_omega_relative_limit);% maximum allowed omeg
    d_omega_mid = 0.5*(d_min_omega+d_max_omega);

    FUDGE = 16;
    ii = 1; %input index
    oo = 1; %output index
    ni = length(input)-FUDGE; %don't use more input than this
    
    %initialize variables.
    u = 0+1j*0; x=0+1j*0; y=0+1j*0;
    d_p_2T = 0; d_p_1T = 0; d_p_0T = 0;
    d_c_2T = 0; d_c_1T = 0; d_c_0T = 0;
    output = zeros(ceil((length(input)/d_omega)),1);
    timing_errors = zeros(length(output),1);
    
    while ( ( oo < length(input)) && ( ii < ni ) )
        d_p_2T = d_p_1T;
        d_p_1T = d_p_0T;
        
        %d_p_0T = d_interp->interpolate(x(ii),d_mu);
        %gri_mmse_fir_interpolator_cc::gri_mmse_fir_interpolator_cc (){
        %  filters.resize (NSTEPS + 1);
        %  
        %  for (int i = 0; i < NSTEPS + 1; i++){
        %    std::vector<float> t (&taps[i][0], &taps[i][NTAPS]);
        %    filters[i] = gr_fir_util::create_gr_fir_ccf (t);
        %  }
        %}
        %gr_complex gri_mmse_fir_interpolator_cc::interpolate (const gr_complex input[], float mu){
        %  int	imu = (int) rint (mu * NSTEPS);
        %  assert (imu >= 0);
        %  assert (imu <= NSTEPS);
        %  gr_complex r = filters[imu]->filter (input);
        %  return r;
        %}
        %d_p_0T = input(round(ii+d_mu*d_omega));
        d_p_0T = input(ii+round(d_mu*d_omega));
        %%skall egentligen vara typ det interpolerade sampel- världet vid
        %%ex 16.01 sampel framåt...
        
        d_c_2T = d_c_1T;
        d_c_1T = d_c_0T;
        real_part= -1;
        imag_part = -1;
        if real(d_p_0T) > 0
            real_part=1;
        end
        if imag(d_p_0T) > 0
            imag_part=1;
        end
        d_c_0T = real_part+1j*imag_part;
        %d_c_0T = (real_part+1j*imag_part)/sqrt(2);
        
        x = (d_c_0T - d_c_2T) * conj(d_p_1T);
        y = (d_p_0T - d_p_2T) * conj(d_c_1T);
        
        u = y - x;
        %u = y*x;
        mm_val = real(u); %tau- hat

        output(oo) = d_p_0T;
        oo = oo+1;
        
        %limit mm_val
        mm_val = 0.5*(abs(mm_val+1.0)-abs(mm_val-1.0));
        d_omega = d_omega + d_gain_omega * mm_val;

        branchless_clip_add = 0.5*(abs((d_omega-d_omega_mid)+d_omega_relative_limit)-abs((d_omega-d_omega_mid)-d_omega_relative_limit));
        d_omega = d_omega_mid + branchless_clip_add;

        %loop filter
        d_mu = d_mu + d_omega + d_gain_mu * mm_val;
        ii = ii+floor(d_mu);
        
        d_mu = d_mu-floor(d_mu);
        
        %write the error signal to the second output
        timing_errors(oo) = d_mu;

        if (ii < 1)	%clamp it.  This should only happen with bogus input
        	ii = 1;
        end
    end

end