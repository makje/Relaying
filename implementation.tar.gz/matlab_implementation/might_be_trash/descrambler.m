function descrambled_bits = descrambler(x,scrambled_bits,N)
    descram_bits = zeros(1,N);
    %make first turn in the loop manualy...
    y = lfsr(x);
    descram_bits(1) = y.output;
    for k=2:N
        y.input = scrambled_bits(k);
        y = dlfsr(y);
        descram_bits(k) = y.output;
    end
    descrambled_bits = descram_bits;
end