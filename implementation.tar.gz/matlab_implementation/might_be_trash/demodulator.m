function y = demodulator(x, bits_per_symbol)
    switch bits_per_symbol
        case 2
            y = qpsk_demodulate(x);
        otherwise
            disp('Only qpsk (2 bits per symbol) is implemented at this time');
    end
end