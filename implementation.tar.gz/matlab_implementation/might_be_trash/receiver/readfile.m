%readfile(file_name, format)
%
%Reads a file specefied by file_name and format
%and returns the content.
function x = readfile(file_name, format)
    fid = fopen(file_name,'r');
    tmp = fread(fid,format);
    x = tmp(1:2:end)-1j*tmp(2:2:end);
    fclose(fid);
    clear fid;
    clear tmp;
end
