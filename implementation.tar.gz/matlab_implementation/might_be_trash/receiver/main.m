clear all
clc
close all

%% Matlab receiver...

%% Parameters
BITS_PER_SYMBOL = 2;
N = 10000;
costas_alpha = .05;
costas_beta = .00025;
costas_max_freq = 0.5;
mm_mu = 0.5;
mm_gain_mu = 0.001;
mm_omega = 16; 
mm_gain_omega = 0.000001;
mm_omega_relative_limit = 0.0001;
do_receive = 0; %Should reception with usrp be done, or is it done already. 1/0

if do_receive == 1
    path_to_program = './';
    program_name = 'single_antenna';
    number_of_buffers = 1000;
    rf_frequency = 1.9025e9;
    rf_gain = 40;
    
    command = ['sudo ' path_to_program program_name ' '...
                num2str(number_of_buffers) ' ' num2str(rf_frequency) ' '...
                num2str(rf_gain) ' receive'];
    system(command);
end

%% Read the file 'data_from_usrp.dat'
rx = readfile('data_from_usrp.dat','int16');
start = 2.7e6+1.77e4+60+7;
stop = start+1.602e5;
rx = rx(start:stop);
shift_register = [0,1,0,1,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1];
shift_mask =     [0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];

%% "Channel filter", lpf before syncronization.
channel_filter_taps= [0.000932948, 0.0018801, 0.00153291, -0.00118865, -0.00540242, -0.00664081, 4.2447e-18, 0.0128483, 0.0203788, 0.00882501, -0.0222674, -0.0505095, -0.0403626, 0.0301637, 0.145668, 0.254549, 0.299185, 0.254549, 0.145668, 0.0301637, -0.0403626, -0.0505095, -0.0222674, 0.00882501, 0.0203788, 0.0128483, 4.2447e-18, -0.00664081, -0.00540242, -0.00118865, 0.00153291, 0.0018801, 0.000932948];
rx_lp = conv(rx,channel_filter_taps);
%% RRC- filter
d_rx_taps = [ -0.000256273, -0.000323992, -0.00036822, -0.00038416, -0.000369244, -0.000323465, -0.000249499, -0.000152599, -4.02695e-05, 7.82776e-05, 0.000192834, 0.000293033, 0.000369244, 0.000413445, 0.000420011, 0.000386335, 0.000313223, 0.000205018, 6.94303e-05, -8.29334e-05, -0.000239315, -0.000385779, -0.000508343, -0.000594181, -0.000632806, -0.000617119, -0.000544244, -0.000416052, -0.000239315, -2.54617e-05, 0.000210087, 0.000448959, 0.000671192, 0.000856832, 0.000987636, 0.00104876, 0.00103027, 0.000928385, 0.00074627, 0.000494315, 0.000189842, -0.0001438, -0.000478711, -0.000784422, -0.00103027, -0.00118798, -0.00123433, -0.00115359, -0.000939668, -0.000597617, -0.000144451, 0.000390914, 0.000968657, 0.00153999, 0.00204999, 0.0024412, 0.00265778, 0.00265002, 0.00237887, 0.00182023, 0.000968657, -0.000159826, -0.00152603, -0.00306724, -0.00469834, -0.00631445, -0.00779498, -0.00900903, -0.00982189, -0.0101022, -0.00972969, -0.00860251, -0.00664446, -0.00381105, -9.42981e-05, 0.00447417, 0.00982189, 0.0158365, 0.0223686, 0.029237, 0.0362354, 0.043141, 0.0497236, 0.0557563, 0.0610254, 0.0653402, 0.0685424, 0.0705129, 0.071178, 0.0705129, 0.0685424, 0.0653402, 0.0610254, 0.0557563, 0.0497236, 0.043141, 0.0362354, 0.029237, 0.0223686, 0.0158365, 0.00982189, 0.00447417, -9.42981e-05, -0.00381105, -0.00664446, -0.00860251, -0.00972969, -0.0101022, -0.00982189, -0.00900903, -0.00779498, -0.00631445, -0.00469834, -0.00306724, -0.00152603, -0.000159826, 0.000968657, 0.00182023, 0.00237887, 0.00265002, 0.00265778, 0.0024412, 0.00204999, 0.00153999, 0.000968657, 0.000390914, -0.000144451, -0.000597617, -0.000939668, -0.00115359, -0.00123433, -0.00118798, -0.00103027, -0.000784422, -0.000478711, -0.0001438, 0.000189842, 0.000494315, 0.00074627, 0.000928385, 0.00103027, 0.00104876, 0.000987636, 0.000856832, 0.000671192, 0.000448959, 0.000210087, -2.54617e-05, -0.000239315, -0.000416052, -0.000544244, -0.000617119, -0.000632806, -0.000594181, -0.000508343, -0.000385779, -0.000239315, -8.29334e-05, 6.94303e-05, 0.000205018, 0.000313223, 0.000386335, 0.000420011, 0.000413445, 0.000369244, 0.000293033, 0.000192834, 7.82776e-05, -4.02695e-05, -0.000152599, -0.000249499, -0.000323465, -0.000369244, -0.00038416, -0.00036822, -0.000323992, -0.000256273];
rx_rrc = conv(rx,d_rx_taps);
%% Synchronize, Frequnecy
[rx_freq_synced,frequency_errors] = costas_loop(rx_rrc, costas_alpha, costas_beta, costas_max_freq);

%% Synchronize, Time
[rx_time_freq_synced, timing_errors] = m_and_m_algorithm(rx_freq_synced, mm_mu, mm_gain_mu, mm_omega, mm_gain_omega, mm_omega_relative_limit);
rx_time_freq_synced = rx_time_freq_synced(9:end);
%% Downsample
%done in m_and_m_algorithm...

%% Demodulate syncronized received symbols
scram_bits2 = demodulator(rx_time_freq_synced,BITS_PER_SYMBOL);

%% Despread the bits
x = struct('d_shift_register', shift_register, ...
           'd_mask', shift_mask, ...
           'input', scram_bits2(1), ...
           'output',0);
descram_bits = zeros(1,N);
%make first turn in the loop manualy...
y = dlfsr(x);
descram_bits(1) = y.output;
for k=2:N
    y.input = scram_bits2(k);
    y = dlfsr(y);
    descram_bits(k) = y.output;
end

%% Stuff to correct BER.
prob = zeros(length(shift_mask),1); %Prob(1) = probability of 1 consecutive bit error
                                    %Prob(2) = probability of 2 consecutive
                                    %...
for k=1:length(prob)
    prob(k) = (1/2)^k;
end
nr_bit_errors = length(shift_mask)*ones(length(shift_mask),1);
for k=2:2:length(nr_bit_errors)
    nr_bit_errors(k) = k;
end
magic_number = prob'*nr_bit_errors;
ones_density = sum(descram_bits)/length(descram_bits);

disp(['BER: ' num2str(1- ones_density/magic_number) ' %'])