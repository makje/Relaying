%function writefile(file_name, var, mode)
%
%file_name: name of file to write to
%var: variable to write to the file
%mode: mode that the binary file will be written in
%
function writefile(file_name,var,mode)
    fid = fopen(file_name,'w');
    fwrite(fid,var,mode);
    fclose(fid);
end