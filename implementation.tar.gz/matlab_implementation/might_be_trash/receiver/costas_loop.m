% Implements a costas crossover loop, see 
% "Acquisition Performance of Various QPSK Carrier Tracking Loops"
%
function [optr, foptr] = costas_loop(input, alpha, beta, max_freq)
    d_alpha = alpha;
    d_beta = beta;
    d_max_freq = max_freq;
    d_min_freq = -d_max_freq;
    d_freq = (d_max_freq+d_min_freq)/2;
    d_phase = 0;
    optr = zeros(length(input),1);
    foptr = zeros(length(input),1);

    for k=1:length(input)
        nco_out = cos(-d_phase)+1j*sin(-d_phase);
        
        optr(k) = input(k)*nco_out;

        if real(optr(k))>0
            real_part = 1;
        else
            real_part = -1;
        end
        if imag(optr(k))>0
            imag_part = 1;
        else
            imag_part = -1;
        end

        error = real_part * imag(optr(k)) - imag_part*real(optr(k));
        
        %clamp error
        if error > 1
            error = 1;
        end
        if error < -1
            error = -1;
        end
        
        d_freq = d_freq + d_beta * error;
        d_phase = d_phase + d_freq + d_alpha * error;

        while d_phase>2*pi
            d_phase = d_phase - 2*pi;
        end

        while d_phase < -2*pi
            d_phase = d_phase+2*pi;
        end

        if d_freq > d_max_freq
            d_freq = d_max_freq;
        end
        if d_freq < d_min_freq
            d_freq = d_min_freq;
        end                

        foptr(k) = d_freq;
    end
end