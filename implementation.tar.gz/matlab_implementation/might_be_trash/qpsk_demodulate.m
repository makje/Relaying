function y = qpsk_demodulate(x)
% Symbol constellation.
%        |
%    00  |  01
% -------|------->    
%    10  |  11
%        |

    bits = zeros(1, length(x)*2);
    counter = 1;
    for k=1:length(x)
        if imag(x(k))<0
            bits(counter)=1;
        else
            bits(counter)=0;
        end
        if real(x(k))<0
            bits(counter+1)=0;
        else
            bits(counter+1)=1;
        end
        counter = counter+2;
    end
    y = bits;
end
