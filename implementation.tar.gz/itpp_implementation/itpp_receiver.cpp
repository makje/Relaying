//qpsk receiver it++
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <usb.h>			/* needed for usb functions */
#include <getopt.h>
#include <assert.h>
#include <math.h>
#include <stdexcept>
#include <usrp/usrp_standard.h>
#include <usrp/usrp_bytesex.h>
#include <vector>
#include <complex>
void init_usrp(usrp_standard_rx_sptr urx){
	double rf_freq = 1902500000.0;
	int gain = 20;
	if (!urx->set_rx_freq(0, rf_freq)){
		throw(std::out_of_range("Failed setting center frequency"));
	}

	usrp_subdev_spec spec(0,0);
  //spec.side = 0;
  //spec.subdev = 0;
	
	db_base_sptr subdev = urx->selected_subdev(spec);
  
	printf("Subdevice name is %s\n", subdev->name().c_str());
  printf("Subdevice freq range: (%g, %g)\n", subdev->freq_min(), subdev->freq_max());

  unsigned int mux = urx->determine_rx_mux_value(spec);
  printf("mux: %#08x\n",  mux);
  urx->set_mux(mux);

  subdev->set_gain(gain);
	printf("Gain set to max: %d\n", gain);
  float input_rate = urx->adc_rate() / urx->decim_rate();
  printf("baseband rate: %g\n",  input_rate);

  usrp_tune_result r;
  bool ok = urx->tune(subdev->which(), subdev, rf_freq, &r);

  if(!ok) {
    throw(std::runtime_error("Could not set frequency."));
  }
	
  subdev->set_enable(true);
  
  printf("target_freq:     %f\n", rf_freq);
  printf("ok:              %s\n", ok ? "true" : "false");
  printf("r.baseband_freq: %f\n", r.baseband_freq);
  printf("r.dxc_freq:      %f\n", r.dxc_freq);
  printf("r.residual_freq: %f\n", r.residual_freq);
  printf("r.inverted:      %d\n", r.inverted);

}
//max_bytes = 10240
static bool test_input(usrp_standard_rx_sptr urx, int nr_buffers, FILE *fp)
{
  int													fd = -1;
  static const int						BUFSIZE = urx->block_size();
	const unsigned int					MAX_BUFFERS = nr_buffers;
  static const unsigned int		N = BUFSIZE/sizeof(short);
  short												buf[N*MAX_BUFFERS];
  int													nbytes = 0;
	short *b_ptr = buf;
	if (fp)
		fd = fileno(fp);
	
	memset(buf,0,sizeof(buf));
	printf("BUFFSIZE: %d\n",BUFSIZE);
	printf("MAX_BUFFERS: %d\n",MAX_BUFFERS);
	printf("N: %d\n", N);
	printf("nr_buffers: %d\n",nr_buffers);
	bool overrun;
	int noverruns = 0;
	//for (nbytes = 0; max_bytes == 0 || nbytes < max_bytes; nbytes += BUFSIZE){
	//for(nbytes = 0; nbytes< max_bytes; nbytes+=BUFSIZE){
	for(nbytes=0;nbytes<N*2*2*MAX_BUFFERS;nbytes+=BUFSIZE){
		//unsigned int	ret = urx->read(b_ptr, sizeof(buf), &overrun);
		unsigned int	ret = urx->read((void*)b_ptr, N, &overrun);
		b_ptr+=N/2;
		//if (ret != sizeof (buf)){
		if (ret != N){
			fprintf (stderr, "test_input: error, ret = %d\n", ret);
		}

		if (overrun){
			printf ("rx_overrun\n");
			noverruns++;
		}
	}

	if (fd != -1){
		for (unsigned int i = 0; i < sizeof (buf) / sizeof (short); i++)
			buf[i] = usrp_to_host_short(buf[i]);

		if (write(fd, buf, sizeof(buf)) == -1){
			perror("write");
			fd = -1;
		}
	}

	fclose(fp);
	printf ("noverruns = %d\n", noverruns);
	return true;
}

int main(){
	
	int which_board = 0;
	int decim = 8;
	usrp_standard_rx_sptr urx =  usrp_standard_rx::make (which_board, decim, 1, -1);

  if(urx == 0){
		throw "Failed creating usrp- object";
	}

	init_usrp(urx);

  urx->start();		// start data xfers
	int nr_buffers = 10;
	FILE *fp = 0;
	char	*output_filename = {"test.out"};
	if (output_filename){
		fp = fopen (output_filename, "wb");
		if (fp == 0)
			perror (output_filename);
	}
	test_input(urx, nr_buffers, fp);
	urx->stop();
	
	return 0;
}
