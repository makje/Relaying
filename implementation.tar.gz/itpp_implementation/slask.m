clc
fid = fopen('test.out');
data = fread(fid,'short');
fclose(fid);
cdata = data(1:2:end)+j*data(2:2:end);
subplot(2,1,1)
plot(real(cdata)), hold on
plot(imag(cdata),'r')

subplot(2,1,2)
fft_len = length(cdata)*4;
f_axis = -0.5:1/(fft_len-1):0.5;
plot(f_axis,10*log10(abs(fftshift(fft(cdata,fft_len)))));