#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <unistd.h>
#include <usb.h>			/* needed for usb functions */
#include <getopt.h>
#include <assert.h>
#include <math.h>
#include <boost/program_options.hpp>


#include <usrp/usrp_standard.h>
#include <itpp/itcomm.h>
#include <itpp/comm/convcode.h>
#include <itpp/base/vec.h>
#include <usrp_basic.h>

#include "myQPSK.h"
using namespace itpp;

using std::cout;
using std::endl;

void init_usrp(usrp_standard_tx_sptr &utx){
	int which = 0;
	//int fusb_block_size = 512;
	//int fusb_nblocks = 1024;
	int interp = 16;
	int gain = 0;
	double rf_freq = 1902500000.0;
	//usrp_standard_tx_sptr utx = usrp_standard_tx::make (which, interp, 1, -1, fusb_block_size, fusb_nblocks);
//usrp_standard_tx_sptr utx = usrp_standard_tx::make (which, interp, 1, -1);
	utx = usrp_standard_tx::make(which, interp, 1, -1);
	
	usrp_subdev_spec spec(0,0);
  //spec.side = 0;
  //spec.subdev = 0;
	
	db_base_sptr subdev = utx->selected_subdev(spec);
  
	printf("Subdevice name is %s\n", subdev->name().c_str());
  printf("Subdevice freq range: (%g, %g)\n", subdev->freq_min(), subdev->freq_max());

  unsigned int mux = utx->determine_tx_mux_value(spec);
  printf("mux: %#08x\n",  mux);
  utx->set_mux(mux);

  //gain = subdev->gain_max();
	gain = 40;
  subdev->set_gain(gain);
	printf("Gain set to max: %d\n", gain);
  float input_rate = utx->dac_rate() / utx->interp_rate();
  printf("baseband rate: %g\n",  input_rate);

  usrp_tune_result r;

  if (rf_freq < 0)
    rf_freq = (subdev->freq_min() + subdev->freq_max()) * 0.5;
  double target_freq = rf_freq;
  bool ok = utx->tune(subdev->which(), subdev, target_freq, &r);

  if(!ok) {
    throw(std::runtime_error("Could not set frequency."));
  }

  subdev->set_enable(true);
  
  printf("target_freq:     %f\n", target_freq);
  printf("ok:              %s\n", ok ? "true" : "false");
  printf("r.baseband_freq: %f\n", r.baseband_freq);
  printf("r.dxc_freq:      %f\n", r.dxc_freq);
  printf("r.residual_freq: %f\n", r.residual_freq);
  printf("r.inverted:      %d\n", r.inverted);

}

int main(){
  //Declarations of scalars and vectors:
  int Number_of_bits;
  double Ec, Eb;

  bvec bits, transmitted_bits;
  //cvec transmitted_symbols, samples;
	cvec transmitted_symbols, rrc_samples;
	Vec<std::complex<short> > send_samples;

  //myQPSK qpsk;                 //The QPSK modulator class
	QPSK qpsk;
  it_file ff;                //For saving the results to file
  //Real_Timer tt;           //timer used to measure the execution time
	
	usrp_standard_tx_sptr utx;
	try{
		init_usrp(utx);
	}
	catch(std::exception e){
		cout << "couht exception" << e.what() << endl;
		//More shutdown- code...
		return -1;
	}

  //Init signal
  Ec = 1.0;
  Eb = Ec / 2.0;

	Number_of_bits = 896;
	int Number_of_header_bits = 1024-Number_of_bits;
	
	bvec header_bits(Number_of_header_bits);
	bvec header_bits_zeros(Number_of_header_bits);
	header_bits.zeros();
	
	int header_start = 0;
	int header_end = header_start + 16;
	for(int i=header_start;i<header_end;i++){
		if(i==header_start+1 || i==header_start+4 || i == header_start+8 || i==header_start+15 || i == header_start+15){
		 header_bits(i) = 1;
		}
		else{
			header_bits(i) = 0;
		}
	}

  RNG_randomize();
	
	Convolutional_Code code;
	ivec generator(3);
	generator(0)=0133;
	generator(1)=0165;
	generator(2)=0171;
	code.set_generator_polynomials(generator, 7);
	
	//roll-off factor, filter length, upsampling- factor.
	//Root_Raised_Cosine< std::complex<short> > rrc(0.5,8,8);
	Root_Raised_Cosine<std::complex<double> > rrc(0.5,6,5);
	

	bvec access_bits("");
	
	unsigned int nr_packets = 10000;
	utx->start();
	bool underrun = false;
	int nr_underruns = 0;
	for(unsigned int i=0;i<nr_packets;i++){

		bits = randb(Number_of_bits);
		//printf("sizeof bits: %d\n", bits.size());
		bits.ins(0, header_bits);
		transmitted_symbols = qpsk.modulate_bits(bits);
		
		rrc_samples = rrc.shape_symbols(transmitted_symbols);
		rrc_samples = rrc_samples * 8000;
		send_samples.set_size(rrc_samples.length());
		for(unsigned int i=0;i<rrc_samples.length();i++){
			send_samples[i].real() = (short)rrc_samples[i].real();
			send_samples[i].imag() = (short)rrc_samples[i].imag();
			
		}
		/*
		printf("send_sampels.length(): %d\n", send_samples.length());
		printf("Sizeof BUFFER: %d\n", utx->block_size());
		printf("sizeof(short)*2*send_sampels.length() = %d\n",sizeof(short)*2*send_samples.length());
		printf("=======================================\n\n");
		*/
		//usrp_basic_tx::write (const void *buf, int len, bool *underrun)
		utx->write((void*)send_samples._data(),sizeof(short)*2*send_samples.length(),&underrun);
		if(underrun){
			printf("UNDERRUN\n");
			nr_underruns++;
			underrun = false;
		}
	}
	printf("Number of underruns: %d\n",nr_underruns);
	utx->stop();
	return 0;
}