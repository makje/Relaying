#include <itpp/itbase.h>
#include <itpp/itcomm.h>
#include <itpp/itstat.h>
#include <itpp/comm/pulse_shape.h>

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <vector>
#include <complex>
#include <sstream>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <usb.h>			/* needed for usb functions */
#include <getopt.h>
#include <assert.h>
#include <math.h>
#include <stdexcept>
#include <usrp/usrp_standard.h>
#include <usrp/usrp_bytesex.h>


using namespace itpp;
using std::cout;
using std::endl;

int main(){
	Root_Raised_Cosine<std::complex<double> > rrc_rx(0.5,4,8);	
	cout << "rrc_rx_pulse_shape = " << rrc_rx.get_pulse_shape() << endl;
	cout << "upsampling_factor = " << rrc_rx.get_upsampling_factor() << endl;
	cout << "pulse length in nr symbols: " << rrc_rx.get_pulse_length() << endl;
	cout << "get_filter_length () = " << rrc_rx.get_filter_length () << endl;
	return 0;
}
