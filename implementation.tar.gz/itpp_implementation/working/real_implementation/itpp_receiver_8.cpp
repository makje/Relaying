/*
	Receives n (set to 10) buffers from the usrp and
	calculates the BER.
	!! IT WORKS !! =;OP I'M AS HAPPY AS I CAN BE !!
	
*/

#include <itpp/itbase.h>
#include <itpp/itcomm.h>
#include <itpp/itstat.h>
#include <itpp/comm/pulse_shape.h>

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <vector>
#include <complex>
#include <sstream>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <usb.h>			/* needed for usb functions */
#include <getopt.h>
#include <assert.h>
#include <math.h>
#include <stdexcept>
#include <usrp/usrp_standard.h>
#include <usrp/usrp_bytesex.h>
#include <gruel/realtime.h>
using namespace itpp;
using std::cout;
using std::endl;

const int nr_test_tones = 13;
const vec test_tones = linspace(-30e3,30e3,nr_test_tones);

	//USRP constants.
	const int			BUFSIZE = 		2*4096; //urx->block_size();
	const int			which_board = 	0;
	const int			decim = 		64;
	const unsigned int	N = 			BUFSIZE/sizeof(short);
	const unsigned int	MAX_BUFFERS = 	10;
	short				buf[N]; //4096 -> 2048 samples...
	//svec				buf(N);
	int					nbytes = 		0;
	short				*b_ptr = 		buf;
	//short				*b_ptr =		buf._data();

cmat frequency_offset_matrix(nr_test_tones,N);
mat cm(nr_test_tones,N);

bool squelch(const cvec &in, cvec &out, const double th);
void coarse_sync(const cvec &received_samples,cvec &coarse_synced, const cvec &head_symbols, int &sync_index);
void fine_sync(const cvec &coarse_synved, const cvec &header_symbols, cvec &fine_synced, const int sync_index);
void init_usrp(usrp_standard_rx_sptr &urx);
int main(){
	/*if(gruel::RT_OK == gruel::enable_realtime_scheduling()){
		printf("Enabled realtime scheduling\n");
	}
	else{
		printf("Failed to enable realtime scheduling\n");
	}*/
	
	cout << "Setting up frequency- matrix" << endl;	
	for(int i=0;i<nr_test_tones;i++){
		frequency_offset_matrix.set_row(i, exp(std::complex<double>(0.0,1.0)*2*pi*(test_tones(i)/1.0e6)*linspace(0,N-1,N)));
	}
	#ifdef _DEBUG_
		printf("BUFFSIZE: %d\n",BUFSIZE);
		printf("MAX_BUFFERS: %d\n",MAX_BUFFERS);
		printf("N: %d\n", N);
	#endif
	//Declarations of scalars;
	const double Ec = 1.0;				//The transmitted energy per QAM symbol is 1.
	const double Eb = Ec / 2.0;         //The transmitted energy per bit is 0.5.
	const double roll_off_factor = 0.5;	//Rolloff factor in rrc		
	double bit_error_rate;				//bit error rate
	const int symbols_per_packet = 116;	//number of symbols per packet
	const int upsampling_factor = 8;	//Upsampling- factor
	const int filter_length = 4; 		//FIR- filter is upsampling_factor*filter_length + 1...

	//Declarations of vectors:
	vec bit_errors(MAX_BUFFERS);
	bvec received_bits;                 //bvec is a vector containing bits
	bvec transmitted_bits;
	cvec head_symbols;
	cvec received_symbols;           	//cvec is a vector containing double_complex
	cvec received_samples;
	cvec from_channel;
	cvec received_header;
	cvec rxfc;							//Received (fine) frequency- compensated
	cvec rxfcp;							//Received freq and phase copmensated
	cvec f_o_f;							//frequency offset in header
	cvec coarse_synced;					//Coarse frequency offset compensated
										//and time- synced

	bvec head_bits = "1,1,0,1,0,0,0,1,0,0,0,0,1,1,0,0,\
					  1,1,1,1,0,1,0,0,0,0,0,0,0,1,0,0,\
					  1,1,1,1,1,1,1,0,0,0,0,1,0,0,1,0,\
					  1,1,1,1,0,0,1,1,1,1,1,1,0,0,0,1";
					  
	bvec pilot_bits= "1,0,1,0";
	bvec data_bits = "1,1,0,1, 1,1,0,0, 0,0,1,0, 0,0,0,1, 1,1,0,0,\
					  1,0,1,1, 0,0,0,0, 0,1,1,1, 1,0,0,1, 1,1,0,1,\
					  0,1,0,0, 0,1,0,0, 0,0,0,1, 0,1,1,0, 1,1,0,1,\
					  0,1,0,0, 1,0,1,0, 0,0,1,0, 0,0,0,0, 1,1,1,0,\
					  0,1,1,0, 0,0,0,0, 1,0,1,0, 0,0,1,1";
	//The transmitted bits (for BER- calculations).
	transmitted_bits = concat(head_bits, data_bits(0,3), pilot_bits);	
	transmitted_bits = concat(transmitted_bits, data_bits(4 ,7 ), pilot_bits, data_bits(8 ,11), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(12,15), pilot_bits, data_bits(16,19), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(20,23), pilot_bits, data_bits(24,27), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(28,31), pilot_bits, data_bits(32,35), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(36,39), pilot_bits, data_bits(40,43), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(44,47), pilot_bits, data_bits(48,51), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(52,55), pilot_bits, data_bits(56,59), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(60,63), pilot_bits, data_bits(64,67), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(68,71), pilot_bits, data_bits(72,75), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(76,79), pilot_bits, data_bits(80,83), pilot_bits);
	
	//Declarations of classes:
	QAM qam(4);
	BERC berc;                     		//Count bit errors

	Real_Timer tt;                 		//Total timer
	Real_Timer cs;						//Coarse- sync timer.
	Real_Timer fc;						//Fine- sync timer
	Real_Timer rt;						//Read timer
	Root_Raised_Cosine<std::complex<double> > rrc_rx(roll_off_factor,filter_length,upsampling_factor);
	std::stringstream ss_vector_out;

	head_symbols = qam.modulate_bits(head_bits);


	//Create usrp- object and configure it.
	usrp_standard_rx_sptr urx =  usrp_standard_rx::make (which_board, decim, 1, -1);
	if(urx == 0){ throw "Failed creating usrp- object"; }
	init_usrp(urx);
	
	#ifdef _TIME_TT_ 
		tt.tic();
	#endif
	urx->start();		// start data xfers

	int noverruns = 0;

	for(unsigned int i=0;i<MAX_BUFFERS;i++){
		cvec host_order_complex_vec(2048);
		do{
			b_ptr = buf;
			#ifdef _TIME_READ_
				rt.tic();
			#endif
			memset((void *)b_ptr,0,N);
			bool overrun = false;
			unsigned int	ret = urx->read((void*)b_ptr, N, &overrun);
		
			if (ret != N){
				fprintf(stderr, "test_input: error, ret = %d\n", ret);
			}
			if (overrun){
				printf ("rx_overrun\n");
				noverruns++;
			}

			//Convert to host- order, and complex vector.
			int ctr = 0;
			for(unsigned int k=0;k<1024;k++){
				host_order_complex_vec(k) = std::complex<double>(1.0,0.0)*double(usrp_to_host_short(buf[ctr]))+
											std::complex<double>(0.0,1.0)*double(usrp_to_host_short(buf[ctr+1]));
				ctr+=2;
			}
		 //bool squelch(const cvec &in, cvec &out, const double th);
		}while(!squelch(host_order_complex_vec,from_channel,17.0));

		//END OF READ BUFFER FROM USRP


		#ifdef _TIME_READ_
			cout << "Read from usrp: "; rt.toc_print();
		#endif

		received_samples = rrc_rx.shape_samples(from_channel);
		//coarse_synced.zeros();
		int sync_index = 0;
		#ifdef _TIME_CS_
			cs.tic();
		#endif
		coarse_sync(received_samples, coarse_synced, head_symbols, sync_index);	
		#ifdef _TIME_CS_
			cout << "Coarse sync: "; cs.toc_print();
		#endif
		received_symbols.set_size(length(coarse_synced), false);
		//received_symbols.zeros();
		#ifdef _TIME_FS_
			fc.tic();
		#endif
		fine_sync(coarse_synced, head_symbols, received_symbols, sync_index);
		#ifdef _TIME_FS_
			cout << "Fine sync: "; fc.toc_print();
		#endif

		received_bits = qam.demodulate_bits(received_symbols); //Demodulate.

		//Calculate the bit error rate:
		berc.clear();  //Clear the bit error rate counter
		berc.count(transmitted_bits, received_bits); //Count the bit errors
		bit_errors(i) = berc.get_errorrate();

		#ifdef _GET_BER_
			//tt.toc_print();
			cout << endl;
			cout << "BER = " << berc.get_errorrate() << endl;
			cout << endl;
		#endif

	}
	
	urx->stop();
	//Exit program:
	#ifdef _TIME_TT_
		cout << "Total time: "; tt.toc_print();
	#endif
	#ifdef _DEBUG_
		it_file ff;                    		//For saving the results to file
		ff.open("cm.it");
		ff << Name("from_channel") << from_channel;
		ff << Name("fine_synced") << received_symbols;
	  	ff << Name("cm") << cm;
	  	ff.close();
	#endif

	return 0;

}

void coarse_sync(const cvec &received_samples,cvec &coarsed_sync,const cvec &head_symbols, int &si){
	int N = length(received_samples);
	int n = 0;
	bool is_synced = false;
	std::stringstream svo;
	double max_corr = 0.0;
	int freq_index = 0;
	int sync_index = 0;
	#ifdef _DEBUG_
		cm.zeros();
	#endif
	while(n<N/2 && !is_synced){
		svo.str("");
		svo << n << ":" << "8" << ":" << n+8*31;
		ivec index_list = svo.str();
		for(int f=0;f<nr_test_tones;f++){
			cvec comp_tone = frequency_offset_matrix.get_row(f);
			cvec tmp = elem_mult(comp_tone(index_list),received_samples(index_list));
			double c = sqr(abs(elem_mult_sum(tmp, conj(head_symbols))));
			#ifdef _DEBUG_
				cm.set(f,n,c);
			#endif
			//if(c>max_corr){
			//double c = sqr(abs(elem_mult_sum(elem_mult(comp_tone(index_list),received_samples(index_list)),conj(head_symbols))));
			//cout << "c: " << c << endl;
			if(c>max_corr){
				freq_index = f;
				sync_index = n;
				max_corr = c;
			}/*else{
				if(max_corr>5.5e9 && c<max_corr/2){
					is_synced = true;
					cout << ".";
					break;
				}
			}*/
			
		}
		if(max_corr<200.0){
			n+=3;
		}
		n++;
	}
	//cvec comp_tone = exp(std::complex<double>(0.0,1.0)*2*pi*(test_tones(freq_index)/1.0e6)*linspace(0,N-1,N));
	cvec comp_tone = frequency_offset_matrix.get_row(freq_index);
	cvec tmp = elem_mult(received_samples,comp_tone);
	svo.str("");
	svo << sync_index << ":" << "8" << ":" << sync_index+8*115;	//FIXME MAGIC NUMBER
	coarsed_sync = tmp(svo.str());
	si = sync_index;
}

void fine_sync(const cvec &coarse_synced, const cvec &header_symbols, cvec &fine_synced, const int sync_index){
	const int N = 2048;
	cvec rx_header = coarse_synced(0,31); //FIXME magic number
	cvec f_o_f = elem_mult(rx_header,conj(header_symbols)); //f_o_f = c*|s|*exp(j*2*pi*(f_offset/fs)*i)
    cvec F_O_F = fft(f_o_f,N);
    cvec test = concat(F_O_F.right(40),F_O_F.left(40)); //needed??
    int mi = max_index(abs(test)); //(1)
    //int mi = max_index(abs(F_O_F));
	float f_hat = (float(mi)-float((length(test))-1.0)/2.0)/float(N); //(1)
	

	cvec f_offset = exp(std::complex<double>(0.0,1.0)*2*pi*(-f_hat)*linspace(sync_index,sync_index+N-1,N));
	fine_synced = elem_mult(coarse_synced,f_offset);
    fine_synced = fine_synced/mean(elem_mult(fine_synced(0,31),conj(header_symbols)));
}

void init_usrp(usrp_standard_rx_sptr &urx){
	//double rf_freq = 1902500000.0;
	//double rf_freq = 1.8e9;
	double rf_freq = 3.0e6;
	if (!urx->set_rx_freq(0, rf_freq)){
		throw(std::out_of_range("Failed setting center frequency"));
	}

	usrp_subdev_spec spec(0,0);
	db_base_sptr subdev = urx->selected_subdev(spec);

	printf("Subdevice name is %s\n", subdev->name().c_str());
	printf("Subdevice freq range: (%g, %g)\n", subdev->freq_min(), subdev->freq_max());

	unsigned int mux = urx->determine_rx_mux_value(spec);
	printf("mux: %#08x\n",  mux);
	urx->set_mux(mux);
	int gain = 10;
	subdev->set_gain(gain);
	printf("Gain set to max: %d\n", gain);
	float input_rate = urx->adc_rate() / urx->decim_rate();
	printf("baseband rate: %g\n",  input_rate);

	usrp_tune_result r;
	bool ok = urx->tune(subdev->which(), subdev, rf_freq, &r);

	if(!ok) {
		throw(std::runtime_error("Could not set frequency."));
	}

	subdev->set_enable(true);

	printf("target_freq:     %f\n", rf_freq);
	printf("ok:              %s\n", ok ? "true" : "false");
	printf("r.baseband_freq: %f\n", r.baseband_freq);
	printf("r.dxc_freq:      %f\n", r.dxc_freq);
	printf("r.residual_freq: %f\n", r.residual_freq);
	printf("r.inverted:      %d\n", r.inverted);

	return;
}

bool squelch(const cvec &in, cvec &out, const double th){
	/* Convert svec in to cvec*/
	static std::complex<double> last_mean = 0.0;
	static bool state_have_signal = false;
	std::complex<double> lm = mean(in);
	//std::complex<double> lm = mean(out);

	double p = 20*log10(abs(lm/last_mean));
	
	#ifdef _DEBUG_
		cout << "length(in): " << length(in);
		cout << "\tMEAN: " << lm;
		cout << "\tLast mean: " << last_mean;
		cout << "\tP: " << p << endl;
	#endif

	last_mean = lm; //last_mean is static...

	if(!state_have_signal){ //If we do not have a signal
		if(p>th){ //over threshold
			state_have_signal = true;
			out = in;
		}
		else{ //under threshold
			state_have_signal = false;
			out.zeros();
		}
	}
	else{ //Else we have a signal
		if(p<= th){ //we are below threshold
			state_have_signal = false;
			out.zeros();
		}
		else{ //Above threshold
			state_have_signal = true;
			out = in;
		}
	}

	return state_have_signal;
}
