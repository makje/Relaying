/*
	Transmitter
*/
#include <itpp/itbase.h>
#include <itpp/itcomm.h>
#include <itpp/itstat.h>
#include <itpp/base/random.h>
#include <itpp/comm/pulse_shape.h>

//All needed??
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <usb.h>
#include <getopt.h>
#include <assert.h>
#include <math.h>
#include <stdexcept>
#include <vector>
#include <complex>
#include <sstream>

#include <usrp/usrp_standard.h>
#include <usrp_sink_s.h> //USRP- tx
#include <usrp_subdev_spec.h>
using namespace itpp;
using std::cout;
using std::endl;

void setup_usrp(usrp_sing_s_sptr &tx){
	int board_nr = 0;
	int interp_rate = 128;
	int channel = 0;

	tx = usrp_make_sink_s();
	
	bool ok = false;
	printf("Setting interpolation rate to %d... ", d_interp);
	ok = d_tx->set_interp_rate(d_interp);
	ok?printf("ok\n"):printf("FAILED\n");

	usrp_subdev_spec usds = d_tx->pick_tx_subdevice();
	
	printf("Setting mux to 0x%0x... ", d_tx->determine_tx_mux_value(usds));
	ok = d_tx->set_mux(d_tx->determine_tx_mux_value(usds));
	ok?printf("ok\n"):printf("FAILED\n");

	d_db = d_tx->selected_subdev(usds);
	
	printf("Set enable true... ");	
	ok = d_db->set_enable(true);
	ok?printf("ok\n"):printf("FAILED\n");

	printf("Setting gain to %lf... ",int(d_gain));
	ok = d_db->set_gain(int(d_gain));
	ok?printf("ok\n"):printf("FAILED\n");

	printf("Setting nchannels to 1...");
	ok = d_tx->set_nchannels(1);
	ok?printf("ok\n"):printf("FAILED\n");
	
	usrp_tune_result tr;
	ok = d_tx->tune(d_db->which(), d_db, d_rf_freq, &tr);
	printf("Tune result:\n");
	printf("Baseband freq:\t\t%lf M\n",tr.baseband_freq/1e6);
	printf("DXC freq:\t\t%lf M\n",tr.dxc_freq/1e6);
	printf("Residual freq\t\t%lf M\n",tr.residual_freq/1e6);
	ok?printf("Tune ok\n"):printf("Tune failed\n");
	
}

int main(){
	double Ec, Eb;						//Energy per symbol/bit
	bvec transmitted_bits;				//binary bits
	cvec transmitted_symbols;			//tx- symbols, complex qam modulated
	cvec transmitted_samples;			//tx- samples, convert them to svec before
										//they are sent to the usrp.
	svec to_usrp;						//tx- samples, sent to the usrp

	QAM qam(4);							//QAM- modulation/demodulation object	
	it_file ff;							//File object, to save data in
	Ec = 1.0;							//The transmitted energy per QAM symbol is 1.
	Eb = Ec / 2.0;						//The transmitted energy per bit is 0.5.
	const int symbols_per_packet = 116;	//Packet length in symbols
	const int upsampling_factor = 8;	//Upsampling- factor.
	const int filter_length = 4;		//FIR- filter is upsampling_factor*filter_length + 1...
	const double roll_off_factor = 0.5;
	
	usrp_sink_s_sptr usrp_tx;			//TX- USRP object
	
	bvec head_bits = "1,1,0,1,0,0,0,1,0,0,0,0,1,1,0,0,\
					  1,1,1,1,0,1,0,0,0,0,0,0,0,1,0,0,\
					  1,1,1,1,1,1,1,0,0,0,0,1,0,0,1,0,\
					  1,1,1,1,0,0,1,1,1,1,1,1,0,0,0,1";
					  
	bvec pilot_bits= "1,0,1,0";
	bvec data_bits = "1,1,0,1, 1,1,0,0, 0,0,1,0, 0,0,0,1, 1,1,0,0,\
					  1,0,1,1, 0,0,0,0, 0,1,1,1, 1,0,0,1, 1,1,0,1,\
					  0,1,0,0, 0,1,0,0, 0,0,0,1, 0,1,1,0, 1,1,0,1,\
					  0,1,0,0, 1,0,1,0, 0,0,1,0, 0,0,0,0, 1,1,1,0,\
					  0,1,1,0, 0,0,0,0, 1,0,1,0, 0,0,1,1";

	Root_Raised_Cosine<std::complex<double> > rrc_tx(roll_off_factor,filter_length,upsampling_factor);
	Root_Raised_Cosine<std::complex<double> > rrc_rx(roll_off_factor,filter_length,upsampling_factor);

	//String- manipulators for expressions like "1:8:100" when manupulating vectors...
	std::stringstream ss_vector_out;

	//Assemble a packet
	transmitted_bits = concat(head_bits, data_bits(0,3), pilot_bits);	
	transmitted_bits = concat(transmitted_bits, data_bits(4 ,7 ), pilot_bits, data_bits(8 ,11), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(12,15), pilot_bits, data_bits(16,19), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(20,23), pilot_bits, data_bits(24,27), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(28,31), pilot_bits, data_bits(32,35), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(36,39), pilot_bits, data_bits(40,43), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(44,47), pilot_bits, data_bits(48,51), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(52,55), pilot_bits, data_bits(56,59), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(60,63), pilot_bits, data_bits(64,67), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(68,71), pilot_bits, data_bits(72,75), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(76,79), pilot_bits, data_bits(80,83), pilot_bits);

	//QAM- modulate the bits
	transmitted_symbols = qam.modulate_bits(transmitted_bits);
	
	//Pad symbols to fit into a usb- pack
	cvec pad_vec(6); pad_vec.zeros();
	transmitted_samples = concat(pad_vec, transmitted_symbols, pad_vec);
	
	//Pulse- shape the symbols
	transmitted_samples = rrc_tx.shape_symbols(transmitted_samples);

	to_usrp = to_svec(transmitted_samples);

	#ifdef _DEBUG_
		cout << "length(transmitted_symbols) = " << length(transmitted_symbols) << endl;
		cout << "pad_vec.length(): " << pad_vec.length() << endl;
		cout << "length(transmitted_samples): " << length(transmitted_samples) << endl;
		cout << "Saving results to ./tx_debug.it" << endl;
		cout << endl;

		//open tx_debug.it
		ff.open("tx_debug.it");
		
		//Save data to ff- object.
		ff << Name("tx_bits") << transmitted_bits;
		ff << Name("tx_symbols") << transmitted_symbols;
		ff << Name("tx_samples_d") << transmitted_samples;
		ff << Name("tx_samples_s") << to_usrp;
		ff << Name("rrc_tx") << rrc_tx.get_pulse_shape();
		
		//Close file- object
		ff.close();
	#endif

	cout << "Setup USRP" << endl;
	setup_usrp(usrp_tx);
	/*
	usrp_tx.copy_to_usrp_buffer(gr_vector_const_void_star &input_items,
								int  input_index,
				   				int	input_items_available,
				   				int  &input_items_consumed,	// out
							   	void *usrp_buffer,
				   				int  usrp_buffer_length,
				   				int	&bytes_written);
	*/
	//Exit program:
	return 0;
}
