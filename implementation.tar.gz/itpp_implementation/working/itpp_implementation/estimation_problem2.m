clear all
close all
clc

l = 128;
hdr_l = 128;
hdr_start = 1;

sm = 2.*round(rand(l,2))-1; %Generate +-1 in two columns
s = (sm(:,1)+1j*sm(:,2))/sqrt(2); %create symbols, nomalize energy

hdr = s(hdr_start:hdr_start+hdr_l-1); %"header", search for this...
n = randn(l,1)/20; %Generate noise
%f_offset = 30e3 + 10e3.*randn(1,1); %Frequency offset, N(30e3,10e3)
f_offset = 1e5;
fs = 1e6; %Sampling frequency
f_error = exp(1j*2*pi*(f_offset/fs).*(1:l)); %Generate error- vector
phase_err = (2*pi).*rand(1,l)-pi; % Generate phase- noise U[-pi:pi]
c = exp(1j*phase_err); %channel- gain- vector.

rx = c.*(s.').*f_error+n.'; % Received downsampled symbols

%c_hat = (conj( rx.* conj(s).' )./mean(abs(rx))).*rx;

header_hat = conj(rx(1:hdr_l).* conj(s(1:hdr_l)).')./mean(abs(rx(1:hdr_l)));

%% Code for ploting the normalized frequency offset
%% Estimation error versus true frequency offset
%% Depending on length of fft.
%clear all
%itload qpsk_result_file4.it
%tmp = [];
%
%for k=8:16
%    [y i] = max(fft(f_o_f,2^k));
%    tmp = [tmp (i/(2^k))/(23456/1e6)];
%end
%
%plot([2^8, 2^9, 2^10, 2^11, 2^12, 2^13, 2^14, 2^15, 2^16],tmp),
%title('Normalized frequency estimation error versus length of FFT')
%xlabel('FFT- length')
%ylabel('frequency estimation error/true frequency estimation')