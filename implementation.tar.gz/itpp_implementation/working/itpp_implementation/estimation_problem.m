%Estimation- problem
%fs = 1e6;
%c=(1+(0.25*randn(16,1)));
%f=20e3+linspace(100,1000,16)';
%phi = 2*pi-2*pi*rand(16,1);
%r = c.*exp(1j*2*pi*(f/fs)+phi);

%% Newtons metod, kräver J uträknad... Kanske kan testa...
% Kräver även att man har bra start- gissningar...
%
% Start- gissning på x = [1 0.5]-> 3- itterationer
% Start- gissning på x = [50 150] -> 10- itterationer
%
%x = [50 150]', iter = 0; dxnorm = 1;
%while dxnorm>0.5e-4 && iter <= 10
%    f = [2 * x(1) + x(2) - x(1)*x(2)/2-2
%        x(1)+2*x(2)-cos(x(2))/2-1.5];
%    J = [2-x(2)/2   1-x(1)/2
%        1           2+sin(x(2))/2];
%    dx=-J\f;
%    x=x+dx;
%    dxnorm = norm(dx,inf), iter = iter+1
%end
%x, iter
%end
%t=[0.5 1 1.5 2]'; y=[0.3 0.5 1.4 0.5]';


%% NEWTONS METOD
itload qpsk_result_file5.it
fs = 1e6;
c=(1+(0.25*randn(16,1)));
f=60e3;
phi = pi*ones(16,1);
r = c.*exp(1j*2*pi*(f)+phi);
%t=[1:16]'; y = c.*exp(1j*2*pi*(f/fs).*t+phi);
t=[1:32]'; y = f_o_f;

stem(t,y);

a=1.0; b=1.0; w=30e3; t0=1.2; c=[a b w t0]';
iter = 0; dcnorm=[1];
cc = [];
%while dcnorm(end)>0.5e-5 && iter<1000
while iter<1000
    u=w*(t-t0); f=a+b*exp(1j*2*pi*(w/fs).*t+t0);
    %   dFi/da    dFi/db  dFi/dw           dFi/dt0
    %J=[ones(4,1) sin(u) b*(t-t0).*cos(u) -w*b*cos(u)];
    
    delta1 = 0.1;    delta2 = 0.1;
    delta3 = 500;    delta4 = 0.1;
    
    aw=a+delta1;
    fa=aw+b.*exp(1j*2*pi*(w/fs).*t+t0)-y;
    dfa=(fa-f)/delta1;
    
    bw=b+delta2;
    fb=a+bw.*exp(1j*2*pi*(w/fs).*t+t0)-y;
    dfb=(fb-f)/delta2;
    
    ww=w+delta3;
    fw=a+b.*exp(1j*2*pi*(ww/fs).*t+t0)-y;
    dfw=(fw-f)/delta3;
    
    tw=t0+delta4;
    ft=a+b.*exp(1j*2*pi*(tw/fs).*t+tw)-y;
    dft=(ft-f)/delta4;
    
    J=[dfa dfb dfw dft];
    
    dc=-J\f;
    dcnorm= [dcnorm norm(dc,inf)];
    c=c+dc;
    iter=iter+1;
    cc = [cc; c'];
    a=c(1); b=c(2); w=c(3); t0=c(4);
end
disp(['a: ' num2str(c(1))]);
disp(['b: ' num2str(c(2))]);
disp(['w: ' num2str(c(3))]);
disp(['t0:' num2str(c(4))]);
disp(['iter: ' num2str(iter)]);
%tt=(0:0.05:100);
%Ft=a+b.*exp(1j*2*pi*(w/fs)*tt+t0);
%figure(); plot(t,y,'o'), hold on
%figure(); plot(tt,Ft);

plot(c(1)+c(2).*exp(1j*2*pi*(c(3)/fs).*[1:32]+c(4)).*f_o_f.')
