/*
Carse sync working, but slowly... It's generating the test- tones in the sync-
function... It's not optimal from a speed perspective... But it's doing the
right thing... Moving on to itpp_transmitter7.cpp
*/
#include <itpp/itbase.h>
#include <itpp/itcomm.h>
#include <itpp/itstat.h>

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <usb.h>
#include <getopt.h>
#include <assert.h>
#include <math.h>
#include <stdexcept>
#include <usrp/usrp_standard.h>
#include <vector>
#include <complex>

#include <itpp/itcomm.h>
#include <itpp/base/random.h>
#include <itpp/comm/pulse_shape.h>

#include <sstream>
using namespace itpp;
using std::cout;
using std::endl;
double usrp_frequency_offset = 0.0; //SHOULD make this local... Although it's 04:33...
#ifdef _DEBUG_
	mat cm(13,1125);
#endif
void channel(const cvec &in, cvec &out);
void coarse_sync(const cvec &received_samples,cvec &coarse_synced, const cvec &head_symbols);
int main(){

	//Declarations of scalars and vectors:
	double Ec, Eb, bit_error_rate;
	vec EbN0dB, EbN0, N0, noise_variance; //, bit_error_rate; //vec is a vector containing double
	bvec transmitted_bits, received_bits;                 //bvec is a vector containing bits
	cvec transmitted_symbols, received_symbols;           //cvec is a vector containing double_complex
	cvec transmitted_samples, received_samples;
	cvec channel_freq_offset;
	cvec phase_noise;
	cvec from_channel;
	cvec head_symbols;
	cvec received_header;
	cvec rxfc;
	cvec rxfcp;
	cvec f_o_f;
	cvec coarse_synced;

	//Declarations of classes:
	QAM qam(4);
	
	it_file ff;                    //For saving the results to file
	BERC berc;                     //Used to count the bit errors
	Real_Timer tt;                 //The timer used to measure the execution time
	Uniform_RNG phase_generator(-pi, pi);
	Uniform_RNG freq_generator(-30e3,30e3);
	//Init:
	Ec = 1.0;                      //The transmitted energy per QPSK symbol is 1.
	Eb = Ec / 2.0;                 //The transmitted energy per bit is 0.5.
	//EbN0dB = linspace(0.0, 9.0, 10); //Simulate for 10 Eb/N0 values from 0 to 9 dB.
	//EbN0dB = linspace(0,10,11);
	EbN0dB = "20";
	EbN0 = inv_dB(EbN0dB);         //Calculate Eb/N0 in a linear scale instead of dB.
	N0 = Eb * pow(EbN0, -1.0);     //N0 is the variance of the (complex valued) noise.
	const int symbols_per_packet = 116;

	//bit_error_rate.set_size(EbN0dB.length(), false);
	bit_error_rate = 1.0;

	//Randomize the random number generators in it++:
	RNG_randomize();
	usrp_frequency_offset = freq_generator(); //random frequency offset from usrp


	bvec head_bits = "1,1,0,1,0,0,0,1,0,0,0,0,1,1,0,0,\
					  1,1,1,1,0,1,0,0,0,0,0,0,0,1,0,0,\
					  1,1,1,1,1,1,1,0,0,0,0,1,0,0,1,0,\
					  1,1,1,1,0,0,1,1,1,1,1,1,0,0,0,1";
					  
	bvec pilot_bits= "1,0,1,0"; //0, 1, 2.
	bvec data_bits = "1,1,0,1, 1,1,0,0, 0,0,1,0, 0,0,0,1, 1,1,0,0,\
					  1,0,1,1, 0,0,0,0, 0,1,1,1, 1,0,0,1, 1,1,0,1,\
					  0,1,0,0, 0,1,0,0, 0,0,0,1, 0,1,1,0, 1,1,0,1,\
					  0,1,0,0, 1,0,1,0, 0,0,1,0, 0,0,0,0, 1,1,1,0,\
					  0,1,1,0, 0,0,0,0, 1,0,1,0, 0,0,1,1";

	int upsampling_factor = 8;
	int filter_length = 4; //FIR- filter is upsampling_factor*filter_length + 1...
	double roll_off_factor = 0.5;
	Root_Raised_Cosine<std::complex<double> > rrc_tx(roll_off_factor,filter_length,upsampling_factor);
	Root_Raised_Cosine<std::complex<double> > rrc_rx(roll_off_factor,filter_length,upsampling_factor);

	//String- manipulators for expressions like "1:8:100" when manupulating vectors...
	std::string vector_str;
	std::stringstream ss_vector_out;

	//TRANSMITTER
	//Generate a vector of random bits to transmit:
	//Did this with a for- loop, but this feels safer =;O
	//transmitted_bits = head_bits;

	transmitted_bits = concat(head_bits, data_bits(0,3), pilot_bits);	
	transmitted_bits = concat(transmitted_bits, data_bits(4 ,7 ), pilot_bits, data_bits(8 ,11), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(12,15), pilot_bits, data_bits(16,19), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(20,23), pilot_bits, data_bits(24,27), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(28,31), pilot_bits, data_bits(32,35), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(36,39), pilot_bits, data_bits(40,43), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(44,47), pilot_bits, data_bits(48,51), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(52,55), pilot_bits, data_bits(56,59), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(60,63), pilot_bits, data_bits(64,67), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(68,71), pilot_bits, data_bits(72,75), pilot_bits);
	transmitted_bits = concat(transmitted_bits, data_bits(76,79), pilot_bits, data_bits(80,83), pilot_bits);
	//transmitted_bits = concat(transmitted_bits, data_bits(84,87), pilot_bits, data_bits(88,91));
	//transmitted_bits = concat(transmitted_bits, pilot_bits, data_bits(92,95));


	transmitted_symbols = qam.modulate_bits(transmitted_bits);
	head_symbols = qam.modulate_bits(head_bits);
	cout << "length(transmitted_symbols) = " << length(transmitted_symbols) << endl;
	cout << "length(head_symbols) = " << length(head_symbols) << endl;
	
	//cvec pad_vec(((128-length(transmitted_symbols))/2)*8);
	cvec pad_vec(6);
	pad_vec.zeros();
	transmitted_samples = concat(pad_vec, transmitted_symbols, pad_vec);
	cout << "pad_vec.length(): " << pad_vec.length() << endl;

	transmitted_samples = rrc_tx.shape_symbols(transmitted_samples);
	cvec rrc_head_symbols = rrc_tx.shape_symbols(head_symbols);
	cout << "length(transmitted_samples): " << length(transmitted_samples) << endl;
	cout << "length(rrc_head_symbols): " << length(rrc_head_symbols) << endl;

	//CHANNEL
	channel(transmitted_samples, from_channel);		
			
	//RECEIVER
	received_samples = rrc_rx.shape_samples(from_channel);
	cout << "length(received_samples) = " << length(received_samples) << endl;
	
	//reset string- manipulators...
	/*
		Coarse frequency offset and time- index synchronization.
	*/

	//cvec coarse_synced(length(received_samples));
	//coarse_synced.set_size(length(received_samples));
	coarse_synced.zeros();
	coarse_sync(received_samples, coarse_synced, head_symbols);

	received_symbols = coarse_synced;
	
	#ifdef _DEBUG_
		cout << "length(received_symbols) = " << length(received_symbols) << endl;
		cout << "22x: ";
		cout << "ss_vector_out.str() = " << ss_vector_out.str() << endl;
		cout << "length(received_samples) = " << length(received_samples) << endl;
	#endif

	int rN = length(received_symbols); //length of received symbols
	received_header = received_symbols.get(0,31); //these are (hopefully) our header
	
	received_bits = qam.demodulate_bits(received_symbols); //Demodulate.
	
	//Calculate the bit error rate:
	berc.clear();  //Clear the bit error rate counter
	berc.count(transmitted_bits, received_bits); //Count the bit errors


	#ifdef _DEBUG_
		cout << endl;
		cout << "EbN0dB = " << EbN0dB << " [dB]" << endl;
		cout << "BER = " << berc.get_errorrate() << endl;
		cout << "Saving results to ./qpsk_result_file6.it" << endl;
		cout << endl;

		//Save the results to file:
		ff.open("qpsk_result_file6.it");
		ff << Name("EbN0dB") << EbN0dB;
		ff << Name("ber") << berc.get_errorrate();

		ff << Name("tx_bits") << transmitted_bits;
		ff << Name("tx_symbols") << transmitted_symbols;

		ff << Name("from_channel") << from_channel;
		ff << Name("channel_freq_offset") << channel_freq_offset;
		ff << Name("phase_noise") << phase_noise;
		ff << Name("rx_symbols") << received_symbols;
		ff << Name("f_o_f") << f_o_f;
		ff << Name("rxfc") << rxfc;
		ff << Name("rxfcp") << rxfcp;
		ff << Name("tx_samples") << transmitted_samples;
		ff << Name("rx_samples") << received_samples;
		ff << Name("rrc_tx") << rrc_tx.get_pulse_shape();
		ff << Name("rrc_rx") << rrc_rx.get_pulse_shape();
		ff << Name("received_bits") << received_bits;
		ff << Name("transmitted_bits") << transmitted_bits;
		ff << Name("received_header") << received_header;
		ff << Name("coarse_synced") << coarse_synced;
		ff << Name("cm") << cm;
	#endif
	ff.close();
	cout << "usrp_frequency_offset = " << usrp_frequency_offset << endl;
	//Exit program:
	return 0;

}

void channel(const cvec &in, cvec &out){
	double snr = 20; //dB
	AWGN_Channel awgn_channel;     //The AWGN channel class
	awgn_channel.set_noise(0.5*pow(inv_dB(snr),-1.0)); //Set awgn power
	cvec channel_delay(100); //Create a delay... 100 samples
	
	channel_delay.zeros(); //channel- delay = 0
	cvec from_channel = concat(channel_delay,in); //concat delay and signal
	cvec freq_offset = exp(std::complex<double>(0.0,1.0)*2*pi*(usrp_frequency_offset/1.0e6)*linspace(0,length(from_channel)-1,length(from_channel)));
	from_channel = elem_mult(from_channel,freq_offset);
	#ifdef _DEBUG_
		cout << "14x: ";
		cout << length(from_channel) << " " << length(in) << endl;
	#endif

	from_channel = awgn_channel(from_channel); //add awgn
	out = from_channel;
}

void coarse_sync(const cvec &received_samples,cvec &coarsed_sync,const cvec &head_symbols){
	int N = length(received_samples);
	int nr_test_tones = 13;
	vec test_tones = linspace(-30e3,30e3,nr_test_tones);

	int n = 0;
	bool is_synced = false;
	std::stringstream svo;
	int mr=0,mc=0;
	double max_corr = 0.0;
	int freq_index = 0;
	int sync_index = 0;
	while(n<N/2 && !is_synced){
		svo.str("");
		svo << n << ":" << "8" << ":" << n+8*31;
		#ifdef _DEBUG_
			cout << "coarse_sync: " << svo.str() << endl;
		#endif
		ivec index_list = svo.str();
		for(int f=0;f<nr_test_tones;f++){
			#ifdef _DEBUG_
				cout << "f: " << f << endl;
			#endif
			cvec comp_tone = exp(std::complex<double>(0.0,1.0)*2*pi*(test_tones(f)/1.0e6)*linspace(0,N-1,N));

			/*cvec freq_compensation = tone_matrix.get_row(p); //get tone
			cvec freq_compensated_rx = elem_mult(freq_compensation(access_list),possible_rx_header); //multiply tone with rx			
			double c = abs(elem_mult_sum(freq_compensated_rx,conj(rrc_head_symbols)));*/
			#ifdef _DEBUG_
				cout << "header length: " << length(head_symbols) << endl;
				cout << "length comp_tone(intex_list): " << length(comp_tone(index_list)) << endl;
				cout << "length from_channel(index_list): " << length(received_samples(index_list)) << endl;
			#endif
			cvec tmp = elem_mult(comp_tone(index_list),received_samples(index_list));
			double c = sqr(abs(elem_mult_sum(tmp, conj(head_symbols))));
			cout << "c: " << c << " " << n << endl;
			cm.set(f,n,c);
			if(c>max_corr){
				freq_index = f;
				sync_index = n;
				max_corr = c;
			}else{
				if(max_corr>450.0 && c<max_corr/2){
					is_synced = true;
					break;
				}
			}
			
		}
		n++;	
	}
	#ifdef _DEBUG_
		cout << "Max- corr: " << max_corr << "\t max- index: " << sync_index << endl;
	#endif
	cvec comp_tone = exp(std::complex<double>(0.0,1.0)*2*pi*(test_tones(freq_index)/1.0e6)*linspace(0,N-1,N));
	cvec tmp = elem_mult(received_samples,comp_tone);
	svo.str("");
	svo << sync_index << ":" << "8" << ":" << sync_index+8*115;	
	coarsed_sync = tmp(svo.str());	
}
