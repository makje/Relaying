/*
This code produces BER at the receiver side comparable with
theoretical receiver with fading channel diversity 1.
*/

#include <itpp/itbase.h>
#include <itpp/itcomm.h>
#include <itpp/itstat.h>

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <usb.h>
#include <getopt.h>
#include <assert.h>
#include <math.h>
#include <stdexcept>
#include <usrp/usrp_standard.h>
#include <vector>
#include <complex>

using namespace itpp;
struct max_tuple{
	int index;
	double freq;
	double corr;
	max_tuple(int i, double f, double c){
		index = i; freq = f; corr = c;
	}
};
//These lines are needed for use of cout and endl
using std::cout;
using std::endl;

//==============================================================================
//Make these variables local in the future... it's ugly and wrong to have globals!
static volatile int g_buffer_counter = 0;
usrp_standard_rx_sptr urx;

static int BUFSIZE;
static int N;
static volatile int g_overrun_counter = 0;
//==============================================================================
static volatile bool signaled = false;
static const int DECIM = 128;
static double fs = 128e6/DECIM; //sampling frequency

static void sig_handler(int sig){
  signaled = true;
}

void application_init(){

	//Put application initialization- code here...	
	double rf_freq = 3e6;
	int which_board = 0;
	int gain = 10;

	urx =  usrp_standard_rx::make (which_board, DECIM, 1, -1); //create usrp- object

	if (!urx->set_rx_freq(0, rf_freq)){
		throw(std::out_of_range("Failed setting center frequency"));
	}

	usrp_subdev_spec spec(0,0);
	db_base_sptr subdev = urx->selected_subdev(spec);

	printf("Subdevice name is %s\n", subdev->name().c_str());
	printf("Subdevice freq range: (%g, %g)\n", subdev->freq_min(), subdev->freq_max());

	unsigned int mux = urx->determine_rx_mux_value(spec);
	printf("mux: %#08x\n",  mux);
	
	urx->set_mux(mux);
	subdev->set_gain(gain);
	printf("Gain set to max: %d\n", gain);
	
	float input_rate = urx->adc_rate() / urx->decim_rate();
	printf("baseband rate: %g\n",  input_rate);

	usrp_tune_result r;
	bool ok = urx->tune(subdev->which(), subdev, rf_freq, &r);

	if(!ok){ 
		throw(std::runtime_error("Could not set frequency."));
	}

	subdev->set_enable(true);
	printf("target_freq:     %f\n", rf_freq);
	printf("ok:              %s\n", ok ? "true" : "false");
	printf("r.baseband_freq: %f\n", r.baseband_freq);
	printf("r.dxc_freq:      %f\n", r.dxc_freq);
	printf("r.residual_freq: %f\n", r.residual_freq);
	printf("r.inverted:      %d\n", r.inverted);
	BUFSIZE = urx->block_size();
	N = BUFSIZE/sizeof(short);
}


int main()
{
	//Declarations of scalars and vectors:	
	int i, Number_of_bits;
	double Ec, Eb;
	vec EbN0dB, EbN0, N0, noise_variance, bit_error_rate;
	bvec transmitted_bits, received_bits, access_list;

	cvec tx, transmitted_symbols, transmitted_samples, hdr_syms1, hdr_syms2;
	cvec pad_vec;
	cvec rx, received_symbols, received_samples, freq_compensated_rx,rx_frequency_compensated;
	cvec freq_compensation;
	cvec rx_freq_compensated_rx_hdr;
	cvec best_rx_freq_comp;
	
	cvec from_channel;
	cvec channel_delay(100);
	
	//Declarations of classes:
	QAM qam(4);
	AWGN_Channel awgn_channel;    //The AWGN channel class
	it_file ff;                   //For saving the results to file
	BERC berc;                    //Used to count the bit errors
	Real_Timer tt;            	//The timer used to measure the execution time
	bvec head_bits1= "0,0,0,0,0,0,1,1,1,0,0,0,1,1,0,1,\
	 				  0,0,1,0,1,1,1,1,0,0,0,1,0,0,1,1";
	bvec head_bits2= "1,1,0,0,1,0,0,0,1,1,1,1,0,1,0,0,\
					  1,0,1,1,0,0,0,1,1,1,0,0,0,0,0,0"; //Reversed head_bits1...
	bvec pilot_bits= "0,0,0,1"; //0, 1, 2.
	bvec data_bits = "1,1,0,1,1,1,0,0,0,0, 1,0,0,0,0,1,1,1,0,0,\
					  1,0,1,1,0,0,0,0,0,1, 1,1,1,0,0,1,1,1,0,1,\
					  0,1,0,0,0,1,0,0,0,0, 0,1,0,1,1,0,1,1,0,1,\
					  0,1,0,0,1,0,1,0,0,0, 1,0,0,0,0,0,1,1,1,0,\
					  0,1,1,0,0,0,0,0,1,0, 1,0,0,0,1,1";
  //Init:
  	const int symbols_per_buffer = 112;
	const int bits_per_symbol = 2;
	Ec = 1.0;                      	//The transmitted energy per qam symbol is 1.
	Eb = Ec / bits_per_symbol;	   	//The transmitted energy per bit is 0.5.
	//EbN0dB = linspace(0.0, 20, 21);	//Simulate for 10 Eb/N0 values from 0 to 9 dB.
	EbN0dB = "20";
	EbN0 = inv_dB(EbN0dB);         	//Calculate Eb/N0 in a linear scale instead of dB.
	N0 = Eb * pow(EbN0, -1.0);     	//N0 is the variance of the (complex valued) noise.
	const float roll_off_factor = 0.5;
	const int filter_length = 32;
	const int samples_per_symbol = 8;
	const int data_symbols_per_buffer = 48;
	Root_Raised_Cosine<std::complex<double> > rrc_tx(roll_off_factor, filter_length, samples_per_symbol);
	Root_Raised_Cosine<std::complex<double> > rrc_rx(roll_off_factor, filter_length, 1);
	
	bit_error_rate.set_size(EbN0dB.length(), false);
	RNG_randomize();
 
 	//Corerlation matrix
 	//int nrf = 100;
 	mat cm(1024,1024);
	vec max_corr(EbN0dB.length());
	ivec max_index(EbN0dB.length());
	vec f_max(EbN0dB.length());
	//cm.zeros();
 	double usrp_frequency_offset = 20e3;
	//Iterate over all EbN0dB values:
	for(i = 0; i < EbN0dB.length(); i++) {
    	cout << "Now simulating Eb/N0 value number " << i + 1 << " of " << EbN0dB.length() << "("<< EbN0dB(i) << " dB)" << endl;

		//Setup transmitted bits.
		transmitted_bits.clear();
		transmitted_bits.set_size(0, false);
		transmitted_bits = concat(head_bits1,head_bits2,data_bits(0,3), pilot_bits, data_bits(4,7));

		for(int j=8;j<data_symbols_per_buffer*bits_per_symbol;j=j+4){
			transmitted_bits = concat(transmitted_bits, pilot_bits,data_bits(j,j+3));
		}

		//cout << "transmitted_bits.length() = " << transmitted_bits.length() << endl;

		transmitted_symbols =	qam.modulate_bits(transmitted_bits);
		hdr_syms1 =				qam.modulate_bits(head_bits1);
		hdr_syms2 =				qam.modulate_bits(head_bits2);
		
		transmitted_samples = rrc_tx.shape_symbols(transmitted_symbols);
		
		//Pad vector to fit a USB- buffer
		pad_vec(1024-transmitted_samples.length());
		pad_vec.zeros();
		tx = concat(pad_vec, transmitted_samples);

		//Channel
		//{ //channel- scoped variables...
			cvec channel_frequency_tone(length(tx));
			channel_frequency_tone.zeros();
			for(int l=0;l<channel_frequency_tone.length();l++){
				channel_frequency_tone(l) = std::complex<double>(cos(2*pi*(usrp_frequency_offset/fs)*l),sin(2*pi*(usrp_frequency_offset/fs)*l));
			}
			//cout << "channel_frequency_tone = " << channel_frequency_tone << endl;
			tx = elem_mult(tx, channel_frequency_tone);
			awgn_channel.set_noise(N0(i));
			channel_delay.zeros();
			from_channel = concat(channel_delay, tx);
		//}
		
		//Receiver
		Real_Timer tt;
		tt.tic();
		rx = awgn_channel(from_channel);
		//rx = rrc_rx.shape_samples(rx);
		
		//Generate tone- matrix:
		vec tones_vector = linspace(-50e3,50e3,1024);
		cmat tone_matrix(tones_vector.length(),rx.length());
		{
			for(int r=0;r<tones_vector.length();r++){
				for(int s=0;s<rx.length();s++){
					tone_matrix.set(r,s,std::complex<double>(cos(2*pi*(tones_vector(r)/fs)*s),
															 sin(2*pi*(tones_vector(r)/fs)*s)));
				}
			}
		}
		int sync_index = 0;
		int freq_index = 0;
		{ //scope sync.
			int n = 0; bool is_synced = false;
			while(!is_synced && n<length(rx)-16*8){ //16 = nr header symbols, 8 = samples per symbol
				//FIXME:: Make access_list bvec of length hdr_syms.length() //16.
				access_list.set_size(rx.length(),false);
				access_list.zeros();
				for(int k=n;k<(hdr_syms1.length()*samples_per_symbol)+n;k=k+samples_per_symbol){
					access_list(k) = 1;
				}
				freq_compensation(length(rx));
				{
					for(int p=0;p<tones_vector.length();p++){
						freq_compensation = tone_matrix.get_row(p); //get tone
						freq_compensated_rx = elem_mult(freq_compensation,rx); //multiply tone with rx
						rx_freq_compensated_rx_hdr = freq_compensated_rx.get(access_list); //get possible rx hdr- syms
					
						double c = abs(elem_mult_sum(rx_freq_compensated_rx_hdr,conj(hdr_syms1))); //check
						cm.set(p,n,c);				
						//FIXME: What happens if this is never true ??? 
						//double gamma = max(rrc_tx.get_pulse_shape()); //can't really use gamma, 
						if(within_tolerance(c,length(hdr_syms1),0.04*length(hdr_syms1))){
							is_synced = true;
							sync_index = n;
							freq_index = p;
						}
					} 
				} 
				n++;
			}	//end while
		} //end scope sync.
		
		double mf = tones_vector(freq_index); //get frequency to compensate with
		cout << "mf: " << mf << "\tsync_index: " << sync_index << endl;
		cout << "frequency estimation error: " << usrp_frequency_offset+mf << endl;
		access_list.set_size(rx.length(),false); //set access- list to correct size
		best_rx_freq_comp = tone_matrix.get_row(freq_index);

		//Set access- list		
		for(int m=sync_index;m<rx.length();m=m+samples_per_symbol){
			access_list(m) = 1;
		}
		
		//Multiply received samples with frequency- tone
		rx_frequency_compensated = elem_mult(best_rx_freq_comp,rx);
		
		/**
			Alright... we have the symbols...
		*/
		
		//rx_frequency_compensated = rrc_rx.shape_samples(rx_frequency_compensated);
		
		received_bits = qam.demodulate_bits(rx_frequency_compensated.get(access_list));

		berc.clear();
		berc.count(transmitted_bits, received_bits);
		bit_error_rate(i) = berc.get_errorrate();
		tt.toc_print();
		cout << endl;
  }
  cout << "data_bits.length() : " << data_bits.length() << endl;

  cout << endl;
  cout << "EbN0dB = " << EbN0dB << " [dB]" << endl;
  cout << "BER = " << bit_error_rate << endl;
  cout << "Saving results to ./qpsk_result_file2.it" << endl;
  cout << endl;

  ff.open("qpsk_result_file2.it");
  ff << Name("EbN0dB") << EbN0dB;
  ff << Name("ber") << bit_error_rate;
  ff << Name("from_channel") << from_channel;
  ff << Name("cm") << cm;
  ff << Name("rx") << rx;
  ff << Name("tx") << tx;
  ff << Name("hdr_syms1") << hdr_syms1;
  ff << Name("rrc_tx") << rrc_tx.get_pulse_shape();
  ff << Name("rrc_rx") << rrc_rx.get_pulse_shape();
  ff << Name("rx_frequency_compensated") << rx_frequency_compensated.get(access_list);
  ff.close();
  return 0;
}

