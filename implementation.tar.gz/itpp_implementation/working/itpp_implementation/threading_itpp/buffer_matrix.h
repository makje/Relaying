#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread/condition.hpp>
#include <itpp/itcomm.h>
#include <iostream>

//#include <usrp/usrp_bytesex.h>
#include <netinet/in.h>

typedef boost::mutex::scoped_lock scoped_lock;

class FIFO_Buffer{
	private:
		boost::mutex *mutex_vec;

		boost::condition cond;
		unsigned int p, c, full;
		unsigned int d_nbuffers;
		unsigned int d_buffer_size;
		short buf[10][4096*2];
	public:
		FIFO_Buffer();
		FIFO_Buffer(int buffer_size=4096, int nbuffers=10);
		~FIFO_Buffer(){ delete[] buf; };
		void put(short *cv);
		bool put_nowait(short *cv);
		void get(itpp::cvec &ret_vec);
};
