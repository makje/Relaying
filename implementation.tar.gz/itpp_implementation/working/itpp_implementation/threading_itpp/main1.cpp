/**
This code starts two threads, one for picking up data from the usrp and
put it in a FIFO. The other one is just printing data, but should do SP.
The problem is that there seems to be discont. in the data...

This project is on hold
*/

#include <signal.h>
#include "buffer.h" //Thread- safe fifo.

#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <itpp/itcomm.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <usb.h>
#include <getopt.h>
#include <assert.h>
#include <math.h>
#include <stdexcept>
#include <usrp/usrp_standard.h>
#include <vector>
#include <complex>

using namespace itpp;
using namespace boost;
using std::cout;
using std::endl;

//==============================================================================
//Make these variables local in the future... it's ugly and wrong to have globals!
mutex io_mutex;
static volatile int g_buffer_counter = 0;
usrp_standard_rx_sptr urx;
static const int MAX_BYTES = 4096;
static const int MAX_BUFFERS_TO_READ = 1000;
FIFO_Buffer buf(2*MAX_BYTES,10);
cvec from_fifo(MAX_BYTES);
// Work state- machine
enum state{INITIALIZING,ACCUIERING_SNR_ESTIMATE,SEARCHING_FOR_SIGNAL,DECODE_SIGNAL};
/*USRP -> FIFO variables*/
static int BUFSIZE;
static int N;

static volatile int g_overrun_counter = 0;
//==============================================================================

static volatile bool signaled = false;
static void 
sig_handler(int sig){
  signaled = true;
}

/*This function is run in a thread buffering the received signal from the usrp
  into the fifo- que
*/
void usrp_to_fifo(){
	int	nbytes = 0;
	bool overrun;
	int noverruns = 0;
	short tmp_buffer[N]; //local buffer to fill with usrp- data.
	while(!signaled){	
		for (nbytes = 0; nbytes < MAX_BYTES; nbytes += BUFSIZE){
			unsigned int ret = urx->read(tmp_buffer, sizeof(tmp_buffer), &overrun);
			
			if (ret != sizeof(tmp_buffer)){
				{ boost::mutex::scoped_lock lock(io_mutex);
					fprintf (stderr, "test_input: error, ret = %d\n", ret);
				}
			}

			if (overrun){
				{ boost::mutex::scoped_lock lock(io_mutex);
					printf ("rx_overrun\n");
				}
				noverruns++;
				g_overrun_counter++;
			}
			
			buf.put(tmp_buffer);
		}
	}
	return;
}

void application_init(){
	//Put application initialization- code here...	
	double rf_freq = 3e6;
	int which_board = 0;
	int decim = 128;
	int gain = 10;

	urx =  usrp_standard_rx::make (which_board, decim, 1, -1);

	if (!urx->set_rx_freq(0, rf_freq)){
		throw(std::out_of_range("Failed setting center frequency"));
	}

	usrp_subdev_spec spec(0,0);
	//spec.side = 0;
	//spec.subdev = 0;

	db_base_sptr subdev = urx->selected_subdev(spec);
	{ boost::mutex::scoped_lock lock(io_mutex);
		printf("Subdevice name is %s\n", subdev->name().c_str());
		printf("Subdevice freq range: (%g, %g)\n", subdev->freq_min(), subdev->freq_max());
	}

	unsigned int mux = urx->determine_rx_mux_value(spec);
	{ boost::mutex::scoped_lock lock(io_mutex);
		printf("mux: %#08x\n",  mux);
	}
	urx->set_mux(mux);
	subdev->set_gain(gain);
	{ boost::mutex::scoped_lock lock(io_mutex);
		printf("Gain set to max: %d\n", gain);
	}
	float input_rate = urx->adc_rate() / urx->decim_rate();
	
	{ boost::mutex::scoped_lock lock(io_mutex);
		printf("baseband rate: %g\n",  input_rate);
	}

	usrp_tune_result r;
	bool ok = urx->tune(subdev->which(), subdev, rf_freq, &r);

	if(!ok){ 
		throw(std::runtime_error("Could not set frequency."));
	}

	subdev->set_enable(true);
	{ boost::mutex::scoped_lock lock(io_mutex);
		printf("target_freq:     %f\n", rf_freq);
		printf("ok:              %s\n", ok ? "true" : "false");
		printf("r.baseband_freq: %f\n", r.baseband_freq);
		printf("r.dxc_freq:      %f\n", r.dxc_freq);
		printf("r.residual_freq: %f\n", r.residual_freq);
		printf("r.inverted:      %d\n", r.inverted);
	}
	BUFSIZE = urx->block_size();
	N = BUFSIZE/sizeof(short);
}

void work(){
	while(!signaled){
		buf.get(from_fifo);
		g_buffer_counter++;
		if(g_buffer_counter>10){
			signaled = true;
		}
		//Do signal processing...
		
	}
	
	{ boost::mutex::scoped_lock(io_mutex);
		cout << "NR Buffers read: " << g_buffer_counter<< endl;
	}
	
}

int main(){
	printf("Install signal handler for SIGINT\n");
	struct sigaction action;
	memset(&action, 0, sizeof(action));
	
	action.sa_handler = sig_handler;
	sigemptyset(&action.sa_mask);
	action.sa_flags = 0;
	
	if(sigaction(SIGINT, &action, 0)<0){
		printf("Unable to install signal- handler!\n");
		return -1;
	}

	application_init();
	
	if(urx == 0){
		throw "Failed creating usrp- object";
	}

	thread t0 = thread(&usrp_to_fifo);
	urx->start();		// start data xfers
	thread t1 = thread(&work);
		
	t0.join(); //wait for thread 0 to finish. 
	t1.join();
	urx->stop();
	cout << "NR overruns total: " << g_overrun_counter << endl;
	return 0;
}

