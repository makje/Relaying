#include "buffer.h"
#include <iostream>
using namespace boost;
using std::cout;
using std::endl;

FIFO_Buffer::FIFO_Buffer(int buffer_size, int nbuffers) : p(0), c(0), full(0), d_nbuffers(nbuffers), d_buffer_size(buffer_size) {
	//buf = new short[nbuffers][buffer_size];
	/*ROWS, COLUMNS
	// <--- BUFFER_SIZE --->
	// /\
	// || NBUFFER
	// \/
	*/
	memset(buf,0,nbuffers*buffer_size);
} 
void FIFO_Buffer::put(short *cv){
	scoped_lock lock(mutex);
	if (full == d_nbuffers){
		//Buffer is full, wait
		while(full == d_nbuffers)
			cond.wait(lock);
	}
	for(unsigned int i=0;i<d_buffer_size;i++){
		//buf[p][i] = usrp_to_host_short(cv[i]);
		buf[p][i] = ntohs(cv[i]);
	}
	
	p = (p+1) % d_nbuffers;
	++full;
	cond.notify_one();
}
bool FIFO_Buffer::put_nowait(short *cv){
	scoped_lock lock(mutex);
	if (full == d_nbuffers){
		return false;
	}
	for(unsigned int i=0;i<d_buffer_size;i++){
		buf[p][i] = ntohs(cv[i]);
	}
	p = (p+1) % d_nbuffers;
	++full;
	cond.notify_one();
	return true;
}

void FIFO_Buffer::get(itpp::cvec &ret_vec){
	assert(ret_vec.length()*2 == d_buffer_size);
	
	scoped_lock lk(mutex); 
	if (full == 0){
		/*{ boost::mutex::scoped_lock(io_mutex);
			cout << "buffer empty; WAIT" << endl;
		}*/
		while (full == 0) 
			cond.wait(lk);
	}
	int counter = 0;
	for(unsigned int i=0;i<d_buffer_size;i=i+2){
		ret_vec[counter++] = std::complex<double>(double(buf[c][i]),double(buf[c][i+1]));
	}
	c = (c+1) % d_nbuffers;
	--full;
	cond.notify_one();
	return;
}

