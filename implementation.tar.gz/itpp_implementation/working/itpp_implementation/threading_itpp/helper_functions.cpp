/* HELPER FUNCTION */
#include "helper_functions.h"

/*This function is run in a thread buffering the received signal from the usrp
  into the fifo- que
*/
void usrp_to_fifo(){
	while(true){
		{ boost::mutex::scoped_lock(io_mutex);
			cout << "USRP->FIFO" << endl;
		}

		int	nbytes = 0;
		bool overrun;
		int noverruns = 0;

		//for (nbytes = 0; MAX_BYTES == 0 || nbytes < MAX_BYTES; nbytes += BUFSIZE){
		short tmp_buffer[N]; //local buffer to fill with usrp- data.
/*		for(int i=0;i<N;i++){ //zero- set the buffer... Needed??
			tmp_buffer[i] = 0;
		}*/
	
		for (nbytes = 0; nbytes < MAX_BYTES; nbytes += BUFSIZE){
			unsigned int ret = urx->read (tmp_buffer, sizeof(tmp_buffer), &overrun);
			if (ret != sizeof (tmp_buffer)){
				{ boost::mutex::scoped_lock lock(io_mutex);
					fprintf (stderr, "test_input: error, ret = %d\n", ret);
				}
			}

			if (overrun){
				{ boost::mutex::scoped_lock lock(io_mutex);
					printf ("rx_overrun\n");
				}
				noverruns++;
			}
			//for (unsigned int i = 0; i < sizeof (tmp_buffer)/sizeof(short); i++){
			buf.put(tmp_buffer);
			//}
		}
	}
	return;
}

void application_init(){
	//Put application initialization- code here...	
	int which_board = 0;
	int decim = 128;
	urx =  usrp_standard_rx::make (which_board, decim, 1, -1);
	double rf_freq = 3e6;
	if (!urx->set_rx_freq(0, rf_freq)){
		throw(std::out_of_range("Failed setting center frequency"));
	}

	usrp_subdev_spec spec(0,0);
	//spec.side = 0;
	//spec.subdev = 0;

	db_base_sptr subdev = urx->selected_subdev(spec);
	{ boost::mutex::scoped_lock lock(io_mutex);
		printf("Subdevice name is %s\n", subdev->name().c_str());
		printf("Subdevice freq range: (%g, %g)\n", subdev->freq_min(), subdev->freq_max());
	}

	unsigned int mux = urx->determine_rx_mux_value(spec);
	{ boost::mutex::scoped_lock lock(io_mutex);
		printf("mux: %#08x\n",  mux);
	}
	urx->set_mux(mux);
	int gain = 20;
	subdev->set_gain(gain);
	{ boost::mutex::scoped_lock lock(io_mutex);
		printf("Gain set to max: %d\n", gain);
	}
	float input_rate = urx->adc_rate() / urx->decim_rate();
	
	{ boost::mutex::scoped_lock lock(io_mutex);
		printf("baseband rate: %g\n",  input_rate);
	}

	usrp_tune_result r;
	bool ok = urx->tune(subdev->which(), subdev, rf_freq, &r);

	if(!ok){ 
		throw(std::runtime_error("Could not set frequency."));
	}

	subdev->set_enable(true);
	{ boost::mutex::scoped_lock lock(io_mutex);
		printf("target_freq:     %f\n", rf_freq);
		printf("ok:              %s\n", ok ? "true" : "false");
		printf("r.baseband_freq: %f\n", r.baseband_freq);
		printf("r.dxc_freq:      %f\n", r.dxc_freq);
		printf("r.residual_freq: %f\n", r.residual_freq);
		printf("r.inverted:      %d\n", r.inverted);
	}
	BUFSIZE = urx->block_size();
	N = BUFSIZE/sizeof(short);
}
