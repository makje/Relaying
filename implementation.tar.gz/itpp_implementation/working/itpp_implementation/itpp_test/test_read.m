addpath('/usr/local/share/itpp/');
cd /home/mattias/Desktop/itpp_test/

itload qpsk_res.it


nswcp = 8*31;
fs = 8e6;

start_counter = 0;
max_corr_sum = 0.0;
max_index = 0;
is_synced = false;
rx_header_symbols = [];
corr = [];

fr = 50e3;
nf = 1024;
fcv = linspace(-fr,fr,nf);
freq_corr_vec = zeros(1,nf);

corr_mat = zeros(length(rx_samples)-nswcp,nf);
max_vec = zeros(1,length(rx_samples)-nswcp);

while( ( start_counter < (length(rx_samples) - nswcp) ))
    tmp_rx_symbols = rx_samples(start_counter+(1:8:256));
    
    corr = xcorr(tmp_rx_symbols*fcv, tx_header_symbols);
    plot(corr)
    corr_mat(start_counter, abs(corr));
    max_vec(start_counter) = max(abs(corr(0)*fcv));
    
    if(max_vec(start_counter)>max_corr_sum)
        max_corr_sum = max_vec(start_counter);
        max_index = start_counter;
    end
    start_counter=start_counter+1;
end

% access_list.zeros();
% for(int i=0;i<256;i=i+8){
% access_list(i+max_index) = 1;
% }
% rx_symbols = rx_samples.get(access_list);
% cout << "rx_symbols.length() = " << rx_symbols.length() << endl;
% 
% 
% //Vector containing the current frequency- correction tone.
% cvec freq_correction( rx_symbols);
% 
% //for each nf
% for(int i=0;i<nf;i++){
% for(int j=0;j<freq_correction.length();j++){
%     freq_correction(j) = std::complex<double>(cos(2*pi*(fcv(i)/fs)*j*8),sin(2*pi*(fcv(i)/fs)*j*8));
% }
% cvec tmp1 = elem_mult(freq_correction,rx_symbols);
% cvec tmp2 = xcorr(tmp1, tx_header_symbols,0);
% //cout << "tmp2 = " <<tmp2 << endl;
% freq_corr_vec(i) = abs(tmp2(0));
% }
% 
% cout << "freq_corr_vec = " << freq_corr_vec << endl;
% int m_index = 0;
% max(freq_corr_vec,m_index);
% cout << "Frequency offset estimation: " << fcv(m_index) << " Hz" << endl;
% //==========================================================================
% /*
% Found correct sampling time and offset- frequnecy...
% */
% //Set access- list for found sample- instant...
% access_list.zeros();
% for(int i =max_index;i<access_list.size();i=i+8){ //FIXME 8...
% access_list(i) = 1;
% }
% 
% float corr_freq = fcv(m_index);
% int nr_symbols = floor((rx_samples.length()-max_index)/8); //FIXME
% freq_correction.set_size(nr_symbols);
% 
% for(int i=0;i<nr_symbols;i++){
% freq_correction(i) = std::complex<double>(cos(2*pi*(corr_freq/fs)*i*8),sin(2*pi*(corr_freq/fs)*i*8)); 
% //FIXME: Precalculate for speed... 
% //FIXME *8... use variable...
% }
% 
% //Extract the samples set in access_list.
% cvec tmp_syms = rx_samples.get(access_list);
% rx_symbols = elem_mult(tmp_syms, freq_correction);
% 
% rx_bits = qam.demodulate_bits(rx_symbols);
% cout << "# RX BITS / # TX BITS / # TX DATA BITS" << endl;
% cout << "symbols demodulated to bits (" << rx_bits.length() << "/"<< tx_bits.length() <<"/"<< tx_data_bits.length() <<")" << endl;
% 
% //Calculate the bit error rate:
% berc.clear();                            //Clear the bit error rate counter
% berc.count(tx_bits, rx_bits); 			 //Count the bit errors
% bit_error_rate = berc.get_errorrate();   //Save the estimated BER in the result vector
% 
% double tt_toc = tt.toc();
% cout << "Time elapsed: " << tt_toc << endl;
% cout << "-> " << 1.0/tt_toc << " Hz" << endl;
% cout << "-> " << (1.0/tt_toc)*tx_bits.length() << " bits synced / second " << endl;
% //Print the results:
% cout << endl;
% cout << "EbN0dB = " << EbN0dB << " [dB]" << endl;
% cout << "BER = " << bit_error_rate << endl;
% cout << "Saving results to ./qpsk_res.it" << endl;
% cout << endl;
% 
