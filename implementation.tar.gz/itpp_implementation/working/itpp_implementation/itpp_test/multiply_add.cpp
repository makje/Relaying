#include "multiply_add.h"

double multiply_sum(cvec v1, cvec v2){
	cvec product = elem_mult(v1,v2);
	double d = 0.0;
	
	for(int i=0;i<product.length();i++){
		d += abs( product(i) );
	}
	return d;
}
	
	
