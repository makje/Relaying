#include <iostream>
#include <itpp/itcomm.h>
#include <itpp/stat/misc_stat.h>
using namespace itpp;

//These lines are needed for use of cout and endl
using std::cout;
using std::endl;

int main()
{
	//Declarations of scalars and vectors:
	double Ec, Eb;
	double EbN0dB, EbN0, N0, bit_error_rate;
	//vec EbN0dB, EbN0, N0, bit_error_rate;
	bvec rx_bits, tx_header_bits, tx_data_bits, tx_bits;
	cvec tx_symbols, rx_symbols, rx, tx_samples, rx_samples, upsampled_symbols, tx_header_symbols;
	tx_header_bits = "\
				1,0,0,0,0,1,1,1,1,0,1,1,0,0,0,0,1,1,0,0,1,0,0,1,1,1,1,0,0,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,1,1,0,0,0,1,0,1,1,1,0,1,1,0,0,1,0,0,0,1,0,0";
	tx_data_bits="\
				0,0,1,1,0,0,0,1,0,1,0,1,1,0,1,0,1,1,0,0,1,1,0,0,1,0,1,1,0,1,1,1,0,0,1,1,1,1,0,1,\
				1,1,1,0,1,0,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,1,0,1,1,0,0,1,0,0,0,1,1,0,\
				0,1,0,1,0,0,0,0,0,0,1,0,1,1,1,1,0,0,1,1,1,0,0,1,0,1,1,1,1,0,0,0,0,1,1,0,0,1,0,0,\
				1,0,1,0,0,1,1,1,1,0,0,1,0,1,1,0,1,0,1,1,0,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,1,0,1,\
				0,1,0,1,1,1,0,0,1,1,0,1,1,0,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,1,\
				1,1,1,1,1,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,0,0,1,0,0,\
				0,1,0,1,1,0,0,0,1,1,0,0,1,1,1,1,0,1,1,0,1,1,0,0,0,1,0,0,1,0,0,1,1,0,1,0,0,1,0,0,\
				1,1,1,0,0,0,1,0,0,1,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,0,0,0,0,0,0,1,0,0,1,1,0,0,0,\
				0,1,0,1,1,1,1,1,1,1,0,0,0,1,0,1,1,1,1,1,0,0,1,0,0,0,1,1,1,0,1,1,0,1,0,1,1,0,0,1,\
				0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,1,\
				1,0,1,0,0,1,1,0,0,1,1,0,0,0,0,0,0,1,0,0,1,1,0,0,1,0,1,1,1,0,0,1,1,0,1,0,1,1,1,0,\
				1,0,1,0,0,1,0,1,1,1,0,0,0,0,1,0,1,1,0,1,1,1,1,0,0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,\
				1,0,1,0,1,0,0,1,0,1,1,0,0,0,1,0,1,1,1,1,0,0,1,1,0,0,1,0,1,0,0,1,1,1,0,1,0,1,1,1,\
				0,1,1,1,0,0,1,0,0,1,1,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,1,1,0,0,1,0,0,0,0,1,0,1,0,0,\
				1,0,0,1,0,0,1,1,1,0,0,0,0,1,1,0,1,0,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,0,0,1,1,0,1,0,\
				1,0,1,0,0,0,1,0,0,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,0,1,0,0,1,1,0,\
				1,1,0,1,1,1,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1,1,0,1,1,0,0,1,1,0,0,1,1,1,0,1,1,\
				1,0,0,0,1,1,0,1,1,1,0,0,1,1,0,0,1,0,1,1,0,0,0,1,1,1,0,1,1,0,0,1,1,1,0,0,0,1,0,0,\
				0,1,0,1,1,1,1,0,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,1,0,0,1,1,1,1,1,1,0,1,0,1,1,1,0,\
				0,0,0,0,0,0,1,1,1,1,0,1,0,0,1,1,0,1,1,0,0,0,1,1,0,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,\
				1,0,1,0,0,0,1,0,1,0,0,1,0,1,1,1,1,1,0,0,1,0,1,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,0,1,1,1,1,1,1,1,1,1,1,0,1,0,1,0,0,1,1,1,0,1,1,0,1,1,0,1,0,0,0,1,1,1,1,1,1,1,\
				0,1,0,0,0,0,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,0,1,0,1,1,0,0,0,1,0,0,0,1,1,1,0,0,1,0,\
				1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,1,0,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,0,1,0,1,0,1,0";
	tx_bits= "\
				1,0,0,0,0,1,1,1,1,0,1,1,0,0,0,0,1,1,0,0,1,0,0,1,1,1,1,0,0,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,1,1,0,0,0,1,0,1,1,1,0,1,1,0,0,1,0,0,0,1,0,0, \
				0,0,1,1,0,0,0,1,0,1,0,1,1,0,1,0,1,1,0,0,1,1,0,0,1,0,1,1,0,1,1,1,0,0,1,1,1,1,0,1,\
				1,1,1,0,1,0,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,1,0,1,1,0,0,1,0,0,0,1,1,0,\
				0,1,0,1,0,0,0,0,0,0,1,0,1,1,1,1,0,0,1,1,1,0,0,1,0,1,1,1,1,0,0,0,0,1,1,0,0,1,0,0,\
				1,0,1,0,0,1,1,1,1,0,0,1,0,1,1,0,1,0,1,1,0,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,1,0,1,\
				0,1,0,1,1,1,0,0,1,1,0,1,1,0,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,1,\
				1,1,1,1,1,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,0,0,1,0,0,\
				0,1,0,1,1,0,0,0,1,1,0,0,1,1,1,1,0,1,1,0,1,1,0,0,0,1,0,0,1,0,0,1,1,0,1,0,0,1,0,0,\
				1,1,1,0,0,0,1,0,0,1,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,0,0,0,0,0,0,1,0,0,1,1,0,0,0,\
				0,1,0,1,1,1,1,1,1,1,0,0,0,1,0,1,1,1,1,1,0,0,1,0,0,0,1,1,1,0,1,1,0,1,0,1,1,0,0,1,\
				0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,1,\
				1,0,1,0,0,1,1,0,0,1,1,0,0,0,0,0,0,1,0,0,1,1,0,0,1,0,1,1,1,0,0,1,1,0,1,0,1,1,1,0,\
				1,0,1,0,0,1,0,1,1,1,0,0,0,0,1,0,1,1,0,1,1,1,1,0,0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,\
				1,0,1,0,1,0,0,1,0,1,1,0,0,0,1,0,1,1,1,1,0,0,1,1,0,0,1,0,1,0,0,1,1,1,0,1,0,1,1,1,\
				0,1,1,1,0,0,1,0,0,1,1,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,1,1,0,0,1,0,0,0,0,1,0,1,0,0,\
				1,0,0,1,0,0,1,1,1,0,0,0,0,1,1,0,1,0,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,0,0,1,1,0,1,0,\
				1,0,1,0,0,0,1,0,0,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,0,1,0,0,1,1,0,\
				1,1,0,1,1,1,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1,1,0,1,1,0,0,1,1,0,0,1,1,1,0,1,1,\
				1,0,0,0,1,1,0,1,1,1,0,0,1,1,0,0,1,0,1,1,0,0,0,1,1,1,0,1,1,0,0,1,1,1,0,0,0,1,0,0,\
				0,1,0,1,1,1,1,0,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,1,0,0,1,1,1,1,1,1,0,1,0,1,1,1,0,\
				0,0,0,0,0,0,1,1,1,1,0,1,0,0,1,1,0,1,1,0,0,0,1,1,0,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,\
				1,0,1,0,0,0,1,0,1,0,0,1,0,1,1,1,1,1,0,0,1,0,1,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,0,1,1,1,1,1,1,1,1,1,1,0,1,0,1,0,0,1,1,1,0,1,1,0,1,1,0,1,0,0,0,1,1,1,1,1,1,1,\
				0,1,0,0,0,0,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,0,1,0,1,1,0,0,0,1,0,0,0,1,1,1,0,0,1,0,\
				1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,1,0,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,0,1,0,1,0,1,0";
		
	//Declarations of classes:
	QAM qam(4);                    //The QAM modulator class
	AWGN_Channel awgn_channel;     //The AWGN channel class
	it_file ff;                    //For saving the results to file
	BERC berc;                     //Used to count the bit errors
	Real_Timer tt;                 //The timer used to measure the execution time
	Stat stat;
	
	double roll_off_factor = 0.5;
	int filter_length = 64;
	int upsampling_factor = 8;

 	Root_Raised_Cosine<std::complex<double> > rrc_tx(roll_off_factor, filter_length, upsampling_factor);
 	Root_Raised_Cosine<std::complex<double> > rrc_rx(roll_off_factor, filter_length, upsampling_factor);

	//Reset and start the timer:
	tt.tic();

	//Init:
	Ec = 1.0;                      		//The transmitted energy per QAM symbol is 1.
	Eb = Ec / 2.0;                 		//The transmitted energy per bit is 0.5.
	//EbN0dB = linspace(0.0, 9.0, 10); 	//Simulate for 10 Eb/N0 values from 0 to 9 dB.
	EbN0dB = 20;
	EbN0 = inv_dB(EbN0dB);         		//Calculate Eb/N0 in a linear scale instead of dB.
	N0 = Eb * pow(EbN0, -1.0);     		//N0 is the variance of the (complex valued) noise.


	//Randomize the random number generators in it++:
	RNG_randomize();

	//Modulate the bits to QAM symbols:
	tx_symbols = qam.modulate_bits(tx_bits);
	tx_header_symbols = qam.modulate_bits(tx_header_bits);
	tx_samples = rrc_tx.shape_symbols(tx_symbols); //performs upsampling as well

	//		+---------------------------------------------------+
	//		|						Channel						|
	//		+---------------------------------------------------+
	/*
	const vec avg_power_dB="20";
	const ivec delay_prof="0";
	TDL_Channel tdlc(avg_power_dB, delay_prof);
	tdlc.set_norm_doppler(0.1);
	*/
	awgn_channel.set_noise(N0);
	rx = awgn_channel(tx_samples);
	//rx = tdlc(tx_samples);
	
	//		+---------------------------------------------------+
	//		|				Start of receiver					|
	//		+---------------------------------------------------+
	
	rx_samples = rrc_rx.shape_samples(rx);
	bvec access_list;
	//access_list.set_size(4096); //FIXME. Static length.
	access_list.set_size(rx_samples.length());
	access_list.zeros();
	
//find signal()
	
	//Found max index, sample.
	//Set access- list for found sample- instant...
	access_list.zeros();
	for(int i =max_index;i<access_list.length();i=i+8){
		access_list(i) = 1;
	}

	//Extract the samples set in access_list.
	cout << "Access list for sampling created" << endl;
	rx_symbols = rx_samples.get(access_list);
	
	
	cout << "samples sampled to symbols" << endl;
	rx_bits = qam.demodulate_bits(rx_symbols);
	
	cout << "symbols demodulated to bits (" << rx_bits.length() << "/"<< tx_bits.length() <<"/"<< tx_data_bits.length() <<")" << endl;
	
	//Calculate the bit error rate:
	berc.clear();                            //Clear the bit error rate counter
	berc.count(tx_bits, rx_bits); 			 //Count the bit errors
	bit_error_rate = berc.get_errorrate();   //Save the estimated BER in the result vector
	
	//tt.toc();

	//Print the results:
	cout << endl;
	cout << "EbN0dB = " << EbN0dB << " [dB]" << endl;
	cout << "BER = " << bit_error_rate << endl;
	cout << "Saving results to ./qpsk_res.it" << endl;
	cout << endl;

	//Save the results to file:
	ff.open("qpsk_res.it");
	//ff << Name("EbN0dB") << EbN0dB;
	//ff << Name("ber") << bit_error_rate;

	ff << Name("tx_bits") << tx_bits;
	ff << Name("tx_symbols") << tx_symbols;
	ff << Name("tx_samples") << tx_samples;
	ff << Name("rx_samples") << rx_samples;
	ff << Name("rx_symbols") << rx_symbols;
	ff << Name("rx_bits") << rx_bits;
	//ff << Name("rx_header_symbols") << rx_header_symbols;
	ff << Name("tx_header_symbols") << tx_header_symbols;
	ff << Name("rx") << rx;
	ff.close();
	cout << "Done\n";
	//Exit program:
	return 0;
}

int find_signal(const cvec &rx_samples, cvec &rx_header_symbols ){
	//		+---------------------------------------------------+
	//		|				find start of signal				|
	//		+---------------------------------------------------+

	int start_counter = 0;
	//Variables for correlation.
	double max_corr_sum = 0.0;
	int max_index = 0;
	cvec corr;
	
	while(start_counter < ( rx_samples.size() - 792 )){ //FIXME 792...
		
		//generate access- list.
		access_list.zeros();
		for(int i=0;i<256;i=i+8){ //FIXME static length loop...
			access_list(i+start_counter) = 1;
		}
		
		//Sample the signal at the (by access_list) specefied points.
		rx_header_symbols = rx_samples.get(access_list);
		
		//Calculate correlation between modulated header bits and sampled signal,
		//with max- offset = 0.
		corr.zeros();
		corr = xcorr(rx_header_symbols, tx_header_symbols,0);
		cout << "{" << corr << " " << rx_header_symbols*tx_header_symbols << "} ";

		//Update maximal corr- sum.
		if(abs(sum(corr))>max_corr_sum){
			max_corr_sum = abs(sum(corr));
			max_index = start_counter;	

			/*
				Make check if we are within tolerance for having a complete training- sequence.
			*/
			//within_tolerance(number, reference, tolerance)
			if(within_tolerance(max_corr_sum, tx_header_symbols.length(),0.01*tx_header_symbols.length())){
				is_synced = true;
				start_counter++; //Needed... 
			}
		}
		start_counter++;
		
		/*
			Fetch new data if we reach this conidition...
		*/
		if(start_counter>1000000){ //FIXME, Number needed... Something with buffer- length and everything...
			//Fetch more data...
		}
	}
	//cout << "mi: " << max_index << "\tmc: " << max_corr_sum << endl;
	return max_index;
}
}
