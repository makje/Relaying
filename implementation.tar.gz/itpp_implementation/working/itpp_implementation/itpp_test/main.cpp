#include <itpp/signal/source.h>

using namespace itpp;

int main(){
	//Sine_Source sine_source(double freq, double mean=0.0, double ampl=1.0, double inphase=0.0);
	Sine_Source sine_source(1e6, 0.0, 16000.0, 0.0);
}
