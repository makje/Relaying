
/*
The code is kind of working, except that it never chooses a sampling- point and
offset- frequency.

The code was abandoned, because it is very slow. I'll rewrite it to find the
best sampling instant in time, and then try to correct the frequency- offset.

This way the plan to use some kind of fancy algorithm for calculating the
"next frequency- offset to try" will also be simplified...
*/

#include <iostream>
#include <itpp/itcomm.h>
#include <itpp/stat/misc_stat.h>
using namespace itpp;

/* Helper struct for finding largest number*/
struct max_pair{
	double value;
	int index;
	int foffset;
	
	max_pair(){
		value = 0.0;
		index = 0;
		foffset = 0;
	}
	
	max_pair(double mv, int i, int fof){
		value = mv;
		index = i;
		foffset = fof;
	}
	double get_value(){ return value; }
	int get_index(){ return index; }
	int get_fof(){ return foffset; }
};

//These lines are needed for use of cout and endl
using std::cout;
using std::endl;

int main(){

	//Declarations of scalars and vectors:
	double Ec, Eb;
	vec EbN0dB, EbN0, N0, bit_error_rate(20);

	bvec rx_bits, tx_header_bits, tx_data_bits, tx_bits;
	cvec tx_symbols, rx_symbols, rx, tx_samples, rx_samples, upsampled_symbols, tx_header_symbols;

	tx_header_bits = "\
				1,0,0,0,0,1,1,1,1,0,1,1,0,0,0,0,1,1,0,0,1,0,0,1,1,1,1,0,0,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,1,1,0,0,0,1,0,1,1,1,0,1,1,0,0,1,0,0,0,1,0,0";
	tx_data_bits="\
				0,0,1,1,0,0,0,1,0,1,0,1,1,0,1,0,1,1,0,0,1,1,0,0,1,0,1,1,0,1,1,1,0,0,1,1,1,1,0,1,\
				1,1,1,0,1,0,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,1,0,1,1,0,0,1,0,0,0,1,1,0,\
				0,1,0,1,0,0,0,0,0,0,1,0,1,1,1,1,0,0,1,1,1,0,0,1,0,1,1,1,1,0,0,0,0,1,1,0,0,1,0,0,\
				1,0,1,0,0,1,1,1,1,0,0,1,0,1,1,0,1,0,1,1,0,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,1,0,1,\
				0,1,0,1,1,1,0,0,1,1,0,1,1,0,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,1,\
				1,1,1,1,1,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,0,0,1,0,0,\
				0,1,0,1,1,0,0,0,1,1,0,0,1,1,1,1,0,1,1,0,1,1,0,0,0,1,0,0,1,0,0,1,1,0,1,0,0,1,0,0,\
				1,1,1,0,0,0,1,0,0,1,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,0,0,0,0,0,0,1,0,0,1,1,0,0,0,\
				0,1,0,1,1,1,1,1,1,1,0,0,0,1,0,1,1,1,1,1,0,0,1,0,0,0,1,1,1,0,1,1,0,1,0,1,1,0,0,1,\
				0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,1,\
				1,0,1,0,0,1,1,0,0,1,1,0,0,0,0,0,0,1,0,0,1,1,0,0,1,0,1,1,1,0,0,1,1,0,1,0,1,1,1,0,\
				1,0,1,0,0,1,0,1,1,1,0,0,0,0,1,0,1,1,0,1,1,1,1,0,0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,\
				1,0,1,0,1,0,0,1,0,1,1,0,0,0,1,0,1,1,1,1,0,0,1,1,0,0,1,0,1,0,0,1,1,1,0,1,0,1,1,1,\
				0,1,1,1,0,0,1,0,0,1,1,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,1,1,0,0,1,0,0,0,0,1,0,1,0,0,\
				1,0,0,1,0,0,1,1,1,0,0,0,0,1,1,0,1,0,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,0,0,1,1,0,1,0,\
				1,0,1,0,0,0,1,0,0,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,0,1,0,0,1,1,0,\
				1,1,0,1,1,1,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1,1,0,1,1,0,0,1,1,0,0,1,1,1,0,1,1,\
				1,0,0,0,1,1,0,1,1,1,0,0,1,1,0,0,1,0,1,1,0,0,0,1,1,1,0,1,1,0,0,1,1,1,0,0,0,1,0,0,\
				0,1,0,1,1,1,1,0,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,1,0,0,1,1,1,1,1,1,0,1,0,1,1,1,0,\
				0,0,0,0,0,0,1,1,1,1,0,1,0,0,1,1,0,1,1,0,0,0,1,1,0,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,\
				1,0,1,0,0,0,1,0,1,0,0,1,0,1,1,1,1,1,0,0,1,0,1,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,0,1,1,1,1,1,1,1,1,1,1,0,1,0,1,0,0,1,1,1,0,1,1,0,1,1,0,1,0,0,0,1,1,1,1,1,1,1,\
				0,1,0,0,0,0,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,0,1,0,1,1,0,0,0,1,0,0,0,1,1,1,0,0,1,0,\
				1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,1,0,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,0,1,0,1,0,1,0";
	tx_bits= "\
				1,0,0,0,0,1,1,1,1,0,1,1,0,0,0,0,1,1,0,0,1,0,0,1,1,1,1,0,0,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,1,1,0,0,0,1,0,1,1,1,0,1,1,0,0,1,0,0,0,1,0,0, \
				0,0,1,1,0,0,0,1,0,1,0,1,1,0,1,0,1,1,0,0,1,1,0,0,1,0,1,1,0,1,1,1,0,0,1,1,1,1,0,1,\
				1,1,1,0,1,0,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,1,0,1,1,0,0,1,0,0,0,1,1,0,\
				0,1,0,1,0,0,0,0,0,0,1,0,1,1,1,1,0,0,1,1,1,0,0,1,0,1,1,1,1,0,0,0,0,1,1,0,0,1,0,0,\
				1,0,1,0,0,1,1,1,1,0,0,1,0,1,1,0,1,0,1,1,0,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,1,0,1,\
				0,1,0,1,1,1,0,0,1,1,0,1,1,0,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,1,\
				1,1,1,1,1,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,0,0,1,0,0,\
				0,1,0,1,1,0,0,0,1,1,0,0,1,1,1,1,0,1,1,0,1,1,0,0,0,1,0,0,1,0,0,1,1,0,1,0,0,1,0,0,\
				1,1,1,0,0,0,1,0,0,1,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,0,0,0,0,0,0,1,0,0,1,1,0,0,0,\
				0,1,0,1,1,1,1,1,1,1,0,0,0,1,0,1,1,1,1,1,0,0,1,0,0,0,1,1,1,0,1,1,0,1,0,1,1,0,0,1,\
				0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,1,\
				1,0,1,0,0,1,1,0,0,1,1,0,0,0,0,0,0,1,0,0,1,1,0,0,1,0,1,1,1,0,0,1,1,0,1,0,1,1,1,0,\
				1,0,1,0,0,1,0,1,1,1,0,0,0,0,1,0,1,1,0,1,1,1,1,0,0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,\
				1,0,1,0,1,0,0,1,0,1,1,0,0,0,1,0,1,1,1,1,0,0,1,1,0,0,1,0,1,0,0,1,1,1,0,1,0,1,1,1,\
				0,1,1,1,0,0,1,0,0,1,1,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,1,1,0,0,1,0,0,0,0,1,0,1,0,0,\
				1,0,0,1,0,0,1,1,1,0,0,0,0,1,1,0,1,0,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,0,0,1,1,0,1,0,\
				1,0,1,0,0,0,1,0,0,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,0,1,0,0,1,1,0,\
				1,1,0,1,1,1,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1,1,0,1,1,0,0,1,1,0,0,1,1,1,0,1,1,\
				1,0,0,0,1,1,0,1,1,1,0,0,1,1,0,0,1,0,1,1,0,0,0,1,1,1,0,1,1,0,0,1,1,1,0,0,0,1,0,0,\
				0,1,0,1,1,1,1,0,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,1,0,0,1,1,1,1,1,1,0,1,0,1,1,1,0,\
				0,0,0,0,0,0,1,1,1,1,0,1,0,0,1,1,0,1,1,0,0,0,1,1,0,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,\
				1,0,1,0,0,0,1,0,1,0,0,1,0,1,1,1,1,1,0,0,1,0,1,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,0,1,1,1,1,1,1,1,1,1,1,0,1,0,1,0,0,1,1,1,0,1,1,0,1,1,0,1,0,0,0,1,1,1,1,1,1,1,\
				0,1,0,0,0,0,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,0,1,0,1,1,0,0,0,1,0,0,0,1,1,1,0,0,1,0,\
				1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,1,0,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,0,1,0,1,0,1,0";
		
	//Declarations of classes:
	QAM qam(4);                    //The QAM modulator class
	AWGN_Channel awgn_channel;     //The AWGN channel class
	it_file ff;                    //For saving the results to file
	BERC berc;                     //Used to count the bit errors
	Real_Timer tt;                 //The timer used to measure the execution time
	Stat stat;
	float fs = 8e6;
	double roll_off_factor = 0.5;
	int filter_length = 32;
	int upsampling_factor = 8;
 	Root_Raised_Cosine<std::complex<double> > rrc_tx(roll_off_factor, filter_length, upsampling_factor);
 	
	//Init:
	Ec = 1.0;                      		//The transmitted energy per QAM symbol is 1.
	Eb = Ec / 2.0;                 		//The transmitted energy per bit is 0.5.
	EbN0dB = linspace(0.0, 9.0, 10); 	//Simulate for 10 Eb/N0 values from 0 to 10 dB.
	EbN0 = inv_dB(EbN0dB);         		//Calculate Eb/N0 in a linear scale instead of dB.
	N0 = Eb * pow(EbN0, -1.0);     		//N0 is the variance of the (complex valued) noise.
	cout << "Ec: " << Ec << endl;
	cout << "Eb: " << Eb << endl;
	cout << "EbN0dB: " << EbN0dB << endl;
	cout << "EbN0: " << EbN0 << endl;
	cout << "N0: " << N0 << endl;
	
	int sample_itterator=0;
	int N = 4096;
	bvec access_list;
	access_list.set_size(N);

	cvec tmp_rx_symbol_vector;
	double max_corr_sum = 0.0;
	int max_index = 0;
	int max_freq_offset = 0;
	bool is_synced = false;
	double d_tmp_corr = 0.0;

	//Channel stuff.
	float _n_ampl = 1.0;
	float fo = 20e3;
	tx_samples.set_size(N);
	cvec _f_offset_vec(tx_samples.length());
 	
	/** Initialize all vectors needed for the loop. */
	cvec tmp_rx_header_symbols(32), tmp_freq, tmp_freq_mult_rx_hdr_syms(length(tmp_rx_header_symbols)), tmp_corr(1);

	/* Init receiver variables... */
	int nf = 32; //Nr of frequency- steps
	float frequency_range = 50e3/fs;
	vec pilot_tones_vector(linspace(-frequency_range,frequency_range,nf));

	cmat ptm(N+1,nf+1); //matrix with pilot- tones.
	mat cm(N,nf); //matrix with correlations
	ptm.zeros();
	cm.zeros();
	cout << "Fill pilot- tone matrix... ";
	for(int i=0;i<nf;i++){
		cvec tmp_vec(N);
		for(int j=0;j<N;j++){
			tmp_vec(j) = std::complex<double>(cos(2*pi*pilot_tones_vector(i)*j),
											  sin(2*pi*pilot_tones_vector(i)*j));
		}
		ptm.set_col(i,tmp_vec);
	}
	cout << "Done" << endl;

 	bit_error_rate.set_size(EbN0dB.length(), false);

	//Randomize the random number generators in it++:
	RNG_randomize();

	
	//Loop over a few snr...
	cout << "EbN0dB.length() = " << EbN0dB.length() << endl;
	cout << "Beginning to loop over snr- values" << endl;
	for(int snr=0;snr<EbN0dB.length();snr++){
		cout << "SNR:: " << EbN0dB(snr) << endl;
		//Modulate the bits to QAM symbols:
		tx_symbols = qam.modulate_bits(tx_bits);
		tx_header_symbols = qam.modulate_bits(tx_header_bits);
		tx_samples = rrc_tx.shape_symbols(tx_symbols); //performs upsampling as well
		//		+---------------------------------------------------+
		//		|						Channel						|
		//		+---------------------------------------------------+
		cout << "\tCHANNEL::" << endl;
		cout << "\t\tCreate frequency offset " << fo << "[Hz]... " << endl;
		for(int i=0;i<_f_offset_vec.length();i++){
			_f_offset_vec(i) = std::complex<double>(cos(2*pi*(fo/fs)*i),
													sin(2*pi*(fo/fs)*i));	
		}
		cout << "Done" << endl;
		
		_f_offset_vec = _n_ampl*_f_offset_vec;

		//Multiply tx- samples with frequency offset.
		cout << "\t\tMultiply tx_samples and frequency offset vector" << endl;
		tx_samples = elem_mult(tx_samples,_f_offset_vec);

		cout << "\t\tSet channel noise to " << EbN0dB(snr) << endl;
		awgn_channel.set_noise(N0(snr));
		rx = awgn_channel(tx_samples);

		//		+---------------------------------------------------+
		//		|				Start of receiver					|
		//		+---------------------------------------------------+
		cout << "\tRECEIVER::" << endl;
		Root_Raised_Cosine<std::complex<double> > rrc_rx(roll_off_factor, filter_length, upsampling_factor);
		
		/* RRC- filter the incomming signal */
		cout << "\t\tRRC- filter incomming signal" << endl;
		rx_samples = rrc_rx.shape_samples(rx); //Polyfilter!

		/* FIND START OF SIGNAL */
		cout << "\t\tSynchronize int time and frequency" << endl;
		tt.tic();
		sample_itterator = 0;
		int N_samples_to_process = N-tx_header_bits.length()*Eb*upsampling_factor;
		cout << "\t\tRead samles [0: " << N_samples_to_process << "] from rx_samples[]" << endl;
		is_synced = false;
		while( ( sample_itterator < N_samples_to_process ) &&
				 !is_synced){ 
			access_list.zeros();
			for(int j=0;j<(tx_header_bits.length()*Eb);j++){ //j = [0 8 16 32 ... 256] + sample_counter
				access_list(sample_itterator + j*upsampling_factor) =  1;
				int tmp = j*upsampling_factor; //just to check...
			}
			//sample incomming rx_samples into tmp_rx_header_symbols
			cout << "\t\tSample rx_samples at ["<<sample_itterator<<": "<< upsampling_factor<<": "<<sample_itterator+(tx_header_bits.length()*Eb)<<"]"<< endl;
			tmp_rx_header_symbols = rx_samples.get(access_list);
			
			//for each freaquency- offset multiply tmp_rx_header_symbols
			//with frequency- offset pilot tone j, and correlate the result with
			//tx_header_symbols.
			
			//FIXME: Change order of calculation to something faster, ex.
			//We might pre- calculate a matrix with frequency- offsetted training- sequences 
			//with for instance the frequency- offsetted training- sequences in the columns.
			//
			for(int j=0;(j<nf) && !is_synced;j++){
				//pick out downsampled version of current frequency, starting at n = i.
				tmp_freq = (ptm.get_col(j)).get(access_list); //Valid construct??
			
				//Multiply frequency and symbols
				for(int k=0;k<tmp_freq_mult_rx_hdr_syms.length();k++){
					tmp_freq_mult_rx_hdr_syms(k)=tmp_freq(k)*tmp_rx_header_symbols(k);
				}
			
				//correlate frequency- offseted symbols with known symbols.
				tmp_corr = xcorr(tx_header_symbols,tmp_freq_mult_rx_hdr_syms,0);
				d_tmp_corr = abs(tmp_corr(0));
				
				cm.set(sample_itterator,j,d_tmp_corr);
			
				//Check if we should updata max- sum.
				if(d_tmp_corr > max_corr_sum && !is_synced){
					max_corr_sum = d_tmp_corr;
					max_index = sample_itterator;
					//max_freq_offset = pilot_tones_vector(j)*fs;
					max_freq_offset = j;
			
					//Check wether to quit or not...
					if(within_tolerance(d_tmp_corr, length(tx_header_symbols),0.01*length(tx_header_symbols))){
						is_synced = true; 
					}
					else{
						//we have a new largest value...
						//calculate gradient, and take step in it's direction...
					}
				}
			}
			sample_itterator++;

			//if we have a low  correlation.
			//itterate one extra time- step... 
			if(max_corr_sum<15.0){
				sample_itterator++;
			}
		}
		tt.toc_print();
		cout << "\t\tMax corr sum: " << max_corr_sum << 
				"\tMax index (time): " << max_index << 
				"\tMax frequency offset: " << pilot_tones_vector(max_freq_offset)*fs << "Hz" << endl;

		//found frequency offset and time- index to start sample.
		access_list.zeros();
		int symbol_counter = 0;
			symbol_counter++;
		for(int j=max_index;j<N;j=j+upsampling_factor){ //FIXME static plus...
			access_list(j) = 1;
		}
		rx_symbols = rx_samples.get(access_list);
		cvec tmp_freq2(symbol_counter), freq_mult_rx_syms(symbol_counter);

		//pick out downsampled version of current frequency, starting at n = i.
		//tmp_freq = (ptm.get_col(max_freq_offset)).get(access_list); //Valid construct??

		int ctr = 0;		
		for(int k=0;k<(rx_symbols.length())*upsampling_factor;k=k+upsampling_factor){
			tmp_freq2(k) = std::complex<double>(cos(2*pi*pilot_tones_vector(max_freq_offset)*k),
												sin(2*pi*pilot_tones_vector(max_freq_offset)*k));
			ctr++;
		}
	
		//Multiply frequency and symbols
		for(int k=0;k<freq_mult_rx_syms.length();k++){
			freq_mult_rx_syms(k)=tmp_freq2(k)*rx_symbols(k);
		}

		rx_bits = qam.demodulate_bits(freq_mult_rx_syms);

		cout << "\t\tsymbols demodulated to bits (" << rx_bits.length() << "/"<< tx_bits.length() <<"/"<< tx_data_bits.length() <<")" << endl;
		
		//Calculate the bit error rate:
		berc.clear();                            //Clear the bit error rate counter
		berc.count(tx_bits, rx_bits); 			 //Count the bit errors
		bit_error_rate(snr) = berc.get_errorrate();   //Save the estimated BER in the result vector
		cout << "\t\t!" << endl;
		//tt.toc();
	}
	//Print the results:
	cout << endl;
	cout << "EbN0dB = " << EbN0dB << " [dB]" << endl;
	cout << "BER = " << bit_error_rate << endl;
	cout << "Saving results to ./qpsk_res.it" << endl;
	cout << endl;


	ff.open("qpsk_res_c.it");
	ff << Name("cm") << cm;
	ff << Name("rx") << rx;
	ff << Name("ptm")<< ptm;
	ff << Name("f_offset") << _f_offset_vec;
	ff << Name("rx_symbols") << rx_symbols;
	ff.close();
	return 0;
}

