#include <iostream>
#include <itpp/itcomm.h>
#include <itpp/stat/misc_stat.h>
using namespace itpp;

//These lines are needed for use of cout and endl
using std::cout;
using std::endl;

int main()
{
	//Declarations of scalars and vectors:
	double Ec, Eb;
	double EbN0dB, EbN0, N0, bit_error_rate;
	//vec EbN0dB, EbN0, N0, bit_error_rate;
	bvec rx_bits, tx_header_bits, tx_data_bits, tx_bits;
	cvec tx_symbols, rx_symbols, rx, tx_samples, rx_samples, upsampled_symbols, tx_header_symbols;
	tx_header_bits = "\
				1,0,0,0,0,1,1,1,1,0,1,1,0,0,0,0,1,1,0,0,1,0,0,1,1,1,1,0,0,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,1,1,0,0,0,1,0,1,1,1,0,1,1,0,0,1,0,0,0,1,0,0";
	tx_data_bits="\
				0,0,1,1,0,0,0,1,0,1,0,1,1,0,1,0,1,1,0,0,1,1,0,0,1,0,1,1,0,1,1,1,0,0,1,1,1,1,0,1,\
				1,1,1,0,1,0,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,1,0,1,1,0,0,1,0,0,0,1,1,0,\
				0,1,0,1,0,0,0,0,0,0,1,0,1,1,1,1,0,0,1,1,1,0,0,1,0,1,1,1,1,0,0,0,0,1,1,0,0,1,0,0,\
				1,0,1,0,0,1,1,1,1,0,0,1,0,1,1,0,1,0,1,1,0,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,1,0,1,\
				0,1,0,1,1,1,0,0,1,1,0,1,1,0,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,1,\
				1,1,1,1,1,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,0,0,1,0,0,\
				0,1,0,1,1,0,0,0,1,1,0,0,1,1,1,1,0,1,1,0,1,1,0,0,0,1,0,0,1,0,0,1,1,0,1,0,0,1,0,0,\
				1,1,1,0,0,0,1,0,0,1,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,0,0,0,0,0,0,1,0,0,1,1,0,0,0,\
				0,1,0,1,1,1,1,1,1,1,0,0,0,1,0,1,1,1,1,1,0,0,1,0,0,0,1,1,1,0,1,1,0,1,0,1,1,0,0,1,\
				0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,1,\
				1,0,1,0,0,1,1,0,0,1,1,0,0,0,0,0,0,1,0,0,1,1,0,0,1,0,1,1,1,0,0,1,1,0,1,0,1,1,1,0,\
				1,0,1,0,0,1,0,1,1,1,0,0,0,0,1,0,1,1,0,1,1,1,1,0,0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,\
				1,0,1,0,1,0,0,1,0,1,1,0,0,0,1,0,1,1,1,1,0,0,1,1,0,0,1,0,1,0,0,1,1,1,0,1,0,1,1,1,\
				0,1,1,1,0,0,1,0,0,1,1,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,1,1,0,0,1,0,0,0,0,1,0,1,0,0,\
				1,0,0,1,0,0,1,1,1,0,0,0,0,1,1,0,1,0,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,0,0,1,1,0,1,0,\
				1,0,1,0,0,0,1,0,0,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,0,1,0,0,1,1,0,\
				1,1,0,1,1,1,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1,1,0,1,1,0,0,1,1,0,0,1,1,1,0,1,1,\
				1,0,0,0,1,1,0,1,1,1,0,0,1,1,0,0,1,0,1,1,0,0,0,1,1,1,0,1,1,0,0,1,1,1,0,0,0,1,0,0,\
				0,1,0,1,1,1,1,0,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,1,0,0,1,1,1,1,1,1,0,1,0,1,1,1,0,\
				0,0,0,0,0,0,1,1,1,1,0,1,0,0,1,1,0,1,1,0,0,0,1,1,0,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,\
				1,0,1,0,0,0,1,0,1,0,0,1,0,1,1,1,1,1,0,0,1,0,1,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,0,1,1,1,1,1,1,1,1,1,1,0,1,0,1,0,0,1,1,1,0,1,1,0,1,1,0,1,0,0,0,1,1,1,1,1,1,1,\
				0,1,0,0,0,0,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,0,1,0,1,1,0,0,0,1,0,0,0,1,1,1,0,0,1,0,\
				1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,1,0,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,0,1,0,1,0,1,0";
	tx_bits= "\
				1,0,0,0,0,1,1,1,1,0,1,1,0,0,0,0,1,1,0,0,1,0,0,1,1,1,1,0,0,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,1,1,0,0,0,1,0,1,1,1,0,1,1,0,0,1,0,0,0,1,0,0, \
				0,0,1,1,0,0,0,1,0,1,0,1,1,0,1,0,1,1,0,0,1,1,0,0,1,0,1,1,0,1,1,1,0,0,1,1,1,1,0,1,\
				1,1,1,0,1,0,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,1,0,1,1,0,0,1,0,0,0,1,1,0,\
				0,1,0,1,0,0,0,0,0,0,1,0,1,1,1,1,0,0,1,1,1,0,0,1,0,1,1,1,1,0,0,0,0,1,1,0,0,1,0,0,\
				1,0,1,0,0,1,1,1,1,0,0,1,0,1,1,0,1,0,1,1,0,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,1,0,1,\
				0,1,0,1,1,1,0,0,1,1,0,1,1,0,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,1,\
				1,1,1,1,1,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,0,0,1,0,0,\
				0,1,0,1,1,0,0,0,1,1,0,0,1,1,1,1,0,1,1,0,1,1,0,0,0,1,0,0,1,0,0,1,1,0,1,0,0,1,0,0,\
				1,1,1,0,0,0,1,0,0,1,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,0,0,0,0,0,0,1,0,0,1,1,0,0,0,\
				0,1,0,1,1,1,1,1,1,1,0,0,0,1,0,1,1,1,1,1,0,0,1,0,0,0,1,1,1,0,1,1,0,1,0,1,1,0,0,1,\
				0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,1,\
				1,0,1,0,0,1,1,0,0,1,1,0,0,0,0,0,0,1,0,0,1,1,0,0,1,0,1,1,1,0,0,1,1,0,1,0,1,1,1,0,\
				1,0,1,0,0,1,0,1,1,1,0,0,0,0,1,0,1,1,0,1,1,1,1,0,0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,\
				1,0,1,0,1,0,0,1,0,1,1,0,0,0,1,0,1,1,1,1,0,0,1,1,0,0,1,0,1,0,0,1,1,1,0,1,0,1,1,1,\
				0,1,1,1,0,0,1,0,0,1,1,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,1,1,0,0,1,0,0,0,0,1,0,1,0,0,\
				1,0,0,1,0,0,1,1,1,0,0,0,0,1,1,0,1,0,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,0,0,1,1,0,1,0,\
				1,0,1,0,0,0,1,0,0,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,0,1,0,0,1,1,0,\
				1,1,0,1,1,1,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1,1,0,1,1,0,0,1,1,0,0,1,1,1,0,1,1,\
				1,0,0,0,1,1,0,1,1,1,0,0,1,1,0,0,1,0,1,1,0,0,0,1,1,1,0,1,1,0,0,1,1,1,0,0,0,1,0,0,\
				0,1,0,1,1,1,1,0,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,1,0,0,1,1,1,1,1,1,0,1,0,1,1,1,0,\
				0,0,0,0,0,0,1,1,1,1,0,1,0,0,1,1,0,1,1,0,0,0,1,1,0,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,\
				1,0,1,0,0,0,1,0,1,0,0,1,0,1,1,1,1,1,0,0,1,0,1,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,0,1,1,1,1,1,1,1,1,1,1,0,1,0,1,0,0,1,1,1,0,1,1,0,1,1,0,1,0,0,0,1,1,1,1,1,1,1,\
				0,1,0,0,0,0,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,0,1,0,1,1,0,0,0,1,0,0,0,1,1,1,0,0,1,0,\
				1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,1,0,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,0,1,0,1,0,1,0";
		
	//Declarations of classes:
	QAM qam(4);                    //The QAM modulator class
	AWGN_Channel awgn_channel;     //The AWGN channel class
	it_file ff;                    //For saving the results to file
	BERC berc;                     //Used to count the bit errors
	Real_Timer tt;                 //The timer used to measure the execution time
	Stat stat;
	
	double roll_off_factor = 0.5;
	int filter_length = 64;
	int upsampling_factor = 8;

 	Root_Raised_Cosine<std::complex<double> > rrc_tx(roll_off_factor, filter_length, upsampling_factor);
 	Root_Raised_Cosine<std::complex<double> > rrc_rx(roll_off_factor, filter_length, upsampling_factor);
 	
	//Reset and start the timer:
	tt.tic();

	//Init:
	Ec = 1.0;                      		//The transmitted energy per QAM symbol is 1.
	Eb = Ec / 2.0;                 		//The transmitted energy per bit is 0.5.
	//EbN0dB = linspace(0.0, 9.0, 10); 	//Simulate for 10 Eb/N0 values from 0 to 9 dB.
	EbN0dB = 20;
	EbN0 = inv_dB(EbN0dB);         		//Calculate Eb/N0 in a linear scale instead of dB.
	N0 = Eb * pow(EbN0, -1.0);     		//N0 is the variance of the (complex valued) noise.


	//Randomize the random number generators in it++:
	RNG_randomize();

	//Modulate the bits to QAM symbols:
	tx_symbols = qam.modulate_bits(tx_bits);
	tx_header_symbols = qam.modulate_bits(tx_header_bits);
	tx_samples = rrc_tx.shape_symbols(tx_symbols); //performs upsampling as well

	//		+---------------------------------------------------+
	//		|						Channel						|
	//		+---------------------------------------------------+
	/*
	const vec avg_power_dB="20";
	const ivec delay_prof="0";
	TDL_Channel tdlc(avg_power_dB, delay_prof);
	tdlc.set_norm_doppler(0.1);
	*/
	awgn_channel.set_noise(N0);
	rx = awgn_channel(tx_samples);
	//rx = tdlc(tx_samples);
	
	//		+---------------------------------------------------+
	//		|				Start of receiver					|
	//		+---------------------------------------------------+
	
	rx_samples = rrc_rx.shape_samples(rx);
	bvec access_list(rx_samples.length());
	//access_list.set_size(rx_samples.length());
	access_list.zeros();
	
	//		+---------------------------------------------------+
	//		|				find start of signal				|
	//		+---------------------------------------------------+

	int start_counter = 0;
	double max_corr_sum = 0.0;
	int max_index = 0;
	bool is_synced = false;
	cvec rx_header_symbols, corr;
	
	const int fr = 50e3; //Frequency_Range = 50e3;
	const int nf = 10; //Nr_Frequencies = 10;
	vec fcv; //Frequency_Correction_Vector; //Vector containging the frequencies to search.
	fcv = linspace(-fr,fr,nf); //Change order to optimize search...	
	
	//Array with frequency- corrected incomming signal correlated with training- symbols. 
	Array<cvec> fccm(nf); //frequency_corrected_correlation_matrix(nr_frequencies); 
	
	//Start_Counter: Which sample we are currently proccessing in the incomming vector.
	//is_synced: Set if to TRUE if we already have a good sync.
	//Nr_Samples_We_Can't_Process, amount of samples we can't process in the end of the vector. 
	//FIXME Where to handle them?
	int nswcp = 8*((tx_header_bits.length()/2)-1);
	int fcv_counter = 0;
	float fs = 8e6; //Sampling frequency.
	
	while( ( start_counter < (rx_samples.size() - nswcp) ) && !is_synced ){
		//Set freq_correction to vector contining frequency from fcv(fcv_counter)
		cvec freq_correction(rx_samples.size());
	
		//freq_correction.zeros(); //Needed?
		float corr_freq = fcv(fcv_counter);
		for(int i=0;i<frec_correction.length();i++){
			freq_correction(i) = std::complex(cos(2*pi*(corr_freq/fs)*i),sin(2*pi*(corr_freq/fs)*i)); //FIXME: Precalculate for speed...
		}
		frec_correction = freq_correction * rx_samples;
		
		corr.zeros();
		corr = xcorr(rx_header_symbols, tx_header_symbols,0);
		fccm(fcv_counter) = corr;
		
		fcv_counter++
		start_counter++;
	}
	is_synced = true;
	cout << "mi: " << max_index << "\tmc: " << max_corr_sum << endl;
	
	//Found max index, sample.
	//Set access- list for found sample- instant...
	access_list.zeros();
	for(int i =max_index;i<access_list.size();i=i+8){
		access_list(i) = 1;
	}

	//Extract the samples set in access_list.
	cout << "Access list for sampling created" << endl;
	rx_symbols = rx_samples.get(access_list);
	
	
	cout << "samples sampled to symbols" << endl;
	rx_bits = qam.demodulate_bits(rx_symbols);
	
	cout << "symbols demodulated to bits (" << rx_bits.length() << "/"<< tx_bits.length() <<"/"<< tx_data_bits.length() <<")" << endl;
	
	//Calculate the bit error rate:
	berc.clear();                            //Clear the bit error rate counter
	berc.count(tx_bits, rx_bits); 			 //Count the bit errors
	bit_error_rate = berc.get_errorrate();   //Save the estimated BER in the result vector
	
	//tt.toc();

	//Print the results:
	cout << endl;
	cout << "EbN0dB = " << EbN0dB << " [dB]" << endl;
	cout << "BER = " << bit_error_rate << endl;
	cout << "Saving results to ./qpsk_res.it" << endl;
	cout << endl;

	//Save the results to file:
	ff.open("qpsk_res.it");
	//ff << Name("EbN0dB") << EbN0dB;
	//ff << Name("ber") << bit_error_rate;

	ff << Name("tx_bits") << tx_bits;
	ff << Name("tx_symbols") << tx_symbols;
	ff << Name("tx_samples") << tx_samples;
	ff << Name("rx_samples") << rx_samples;
	ff << Name("rx_symbols") << rx_symbols;
	ff << Name("rx_bits") << rx_bits;
	ff << Name("rx_header_symbols") << rx_header_symbols;
	ff << Name("tx_header_symbols") << tx_header_symbols;
	ff << Name("rx") << rx;
	ff.close();
	cout << "Done\n";
	//Exit program:
	return 0;
}

