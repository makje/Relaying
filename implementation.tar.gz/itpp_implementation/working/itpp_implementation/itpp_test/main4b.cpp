/*
The code is kind of working, except that it never chooses a sampling- point and
offset- frequency.

The code was abandoned, because it is very slow. I'll rewrite it to find the
best sampling instant in time, and then try to correct the frequency- offset.

This way the plan to use some kind of fancy algorithm for calculating the
"next frequency- offset to try" will also be simplified...
*/

#include <iostream>
#include <itpp/itcomm.h>
#include <itpp/stat/misc_stat.h>
using namespace itpp;

/* Helper struct for finding largest number*/
struct max_pair{
	double value;
	int index;
	int foffset;
	
	max_pair(double mv, int i, int fof){
		value = mv;
		index = i;
		foffset = fof;
	}
	double get_value(){ return value; }
	int get_index(){ return index; }
	int get_fof(){ return foffset; }
};

//These lines are needed for use of cout and endl
using std::cout;
using std::endl;

int main()
{
	//Declarations of scalars and vectors:
	double Ec, Eb;
	double EbN0dB, EbN0, N0, bit_error_rate;
	//vec EbN0dB, EbN0, N0, bit_error_rate;
	bvec rx_bits, tx_header_bits, tx_data_bits, tx_bits;
	cvec tx_symbols, rx_symbols, rx, tx_samples, rx_samples, upsampled_symbols, tx_header_symbols;
	tx_header_bits = "\
				1,0,0,0,0,1,1,1,1,0,1,1,0,0,0,0,1,1,0,0,1,0,0,1,1,1,1,0,0,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,1,1,0,0,0,1,0,1,1,1,0,1,1,0,0,1,0,0,0,1,0,0";
	tx_data_bits="\
				0,0,1,1,0,0,0,1,0,1,0,1,1,0,1,0,1,1,0,0,1,1,0,0,1,0,1,1,0,1,1,1,0,0,1,1,1,1,0,1,\
				1,1,1,0,1,0,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,1,0,1,1,0,0,1,0,0,0,1,1,0,\
				0,1,0,1,0,0,0,0,0,0,1,0,1,1,1,1,0,0,1,1,1,0,0,1,0,1,1,1,1,0,0,0,0,1,1,0,0,1,0,0,\
				1,0,1,0,0,1,1,1,1,0,0,1,0,1,1,0,1,0,1,1,0,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,1,0,1,\
				0,1,0,1,1,1,0,0,1,1,0,1,1,0,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,1,\
				1,1,1,1,1,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,0,0,1,0,0,\
				0,1,0,1,1,0,0,0,1,1,0,0,1,1,1,1,0,1,1,0,1,1,0,0,0,1,0,0,1,0,0,1,1,0,1,0,0,1,0,0,\
				1,1,1,0,0,0,1,0,0,1,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,0,0,0,0,0,0,1,0,0,1,1,0,0,0,\
				0,1,0,1,1,1,1,1,1,1,0,0,0,1,0,1,1,1,1,1,0,0,1,0,0,0,1,1,1,0,1,1,0,1,0,1,1,0,0,1,\
				0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,1,\
				1,0,1,0,0,1,1,0,0,1,1,0,0,0,0,0,0,1,0,0,1,1,0,0,1,0,1,1,1,0,0,1,1,0,1,0,1,1,1,0,\
				1,0,1,0,0,1,0,1,1,1,0,0,0,0,1,0,1,1,0,1,1,1,1,0,0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,\
				1,0,1,0,1,0,0,1,0,1,1,0,0,0,1,0,1,1,1,1,0,0,1,1,0,0,1,0,1,0,0,1,1,1,0,1,0,1,1,1,\
				0,1,1,1,0,0,1,0,0,1,1,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,1,1,0,0,1,0,0,0,0,1,0,1,0,0,\
				1,0,0,1,0,0,1,1,1,0,0,0,0,1,1,0,1,0,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,0,0,1,1,0,1,0,\
				1,0,1,0,0,0,1,0,0,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,0,1,0,0,1,1,0,\
				1,1,0,1,1,1,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1,1,0,1,1,0,0,1,1,0,0,1,1,1,0,1,1,\
				1,0,0,0,1,1,0,1,1,1,0,0,1,1,0,0,1,0,1,1,0,0,0,1,1,1,0,1,1,0,0,1,1,1,0,0,0,1,0,0,\
				0,1,0,1,1,1,1,0,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,1,0,0,1,1,1,1,1,1,0,1,0,1,1,1,0,\
				0,0,0,0,0,0,1,1,1,1,0,1,0,0,1,1,0,1,1,0,0,0,1,1,0,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,\
				1,0,1,0,0,0,1,0,1,0,0,1,0,1,1,1,1,1,0,0,1,0,1,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,0,1,1,1,1,1,1,1,1,1,1,0,1,0,1,0,0,1,1,1,0,1,1,0,1,1,0,1,0,0,0,1,1,1,1,1,1,1,\
				0,1,0,0,0,0,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,0,1,0,1,1,0,0,0,1,0,0,0,1,1,1,0,0,1,0,\
				1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,1,0,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,0,1,0,1,0,1,0";
	tx_bits= "\
				1,0,0,0,0,1,1,1,1,0,1,1,0,0,0,0,1,1,0,0,1,0,0,1,1,1,1,0,0,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,1,1,0,0,0,1,0,1,1,1,0,1,1,0,0,1,0,0,0,1,0,0, \
				0,0,1,1,0,0,0,1,0,1,0,1,1,0,1,0,1,1,0,0,1,1,0,0,1,0,1,1,0,1,1,1,0,0,1,1,1,1,0,1,\
				1,1,1,0,1,0,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,1,0,1,1,0,0,1,0,0,0,1,1,0,\
				0,1,0,1,0,0,0,0,0,0,1,0,1,1,1,1,0,0,1,1,1,0,0,1,0,1,1,1,1,0,0,0,0,1,1,0,0,1,0,0,\
				1,0,1,0,0,1,1,1,1,0,0,1,0,1,1,0,1,0,1,1,0,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,1,0,1,\
				0,1,0,1,1,1,0,0,1,1,0,1,1,0,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,1,\
				1,1,1,1,1,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,0,0,1,0,0,\
				0,1,0,1,1,0,0,0,1,1,0,0,1,1,1,1,0,1,1,0,1,1,0,0,0,1,0,0,1,0,0,1,1,0,1,0,0,1,0,0,\
				1,1,1,0,0,0,1,0,0,1,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,0,0,0,0,0,0,1,0,0,1,1,0,0,0,\
				0,1,0,1,1,1,1,1,1,1,0,0,0,1,0,1,1,1,1,1,0,0,1,0,0,0,1,1,1,0,1,1,0,1,0,1,1,0,0,1,\
				0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,1,\
				1,0,1,0,0,1,1,0,0,1,1,0,0,0,0,0,0,1,0,0,1,1,0,0,1,0,1,1,1,0,0,1,1,0,1,0,1,1,1,0,\
				1,0,1,0,0,1,0,1,1,1,0,0,0,0,1,0,1,1,0,1,1,1,1,0,0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,\
				1,0,1,0,1,0,0,1,0,1,1,0,0,0,1,0,1,1,1,1,0,0,1,1,0,0,1,0,1,0,0,1,1,1,0,1,0,1,1,1,\
				0,1,1,1,0,0,1,0,0,1,1,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,1,1,0,0,1,0,0,0,0,1,0,1,0,0,\
				1,0,0,1,0,0,1,1,1,0,0,0,0,1,1,0,1,0,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,0,0,1,1,0,1,0,\
				1,0,1,0,0,0,1,0,0,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,0,1,0,0,1,1,0,\
				1,1,0,1,1,1,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1,1,0,1,1,0,0,1,1,0,0,1,1,1,0,1,1,\
				1,0,0,0,1,1,0,1,1,1,0,0,1,1,0,0,1,0,1,1,0,0,0,1,1,1,0,1,1,0,0,1,1,1,0,0,0,1,0,0,\
				0,1,0,1,1,1,1,0,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,1,0,0,1,1,1,1,1,1,0,1,0,1,1,1,0,\
				0,0,0,0,0,0,1,1,1,1,0,1,0,0,1,1,0,1,1,0,0,0,1,1,0,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,\
				1,0,1,0,0,0,1,0,1,0,0,1,0,1,1,1,1,1,0,0,1,0,1,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,0,1,1,1,1,1,1,1,1,1,1,0,1,0,1,0,0,1,1,1,0,1,1,0,1,1,0,1,0,0,0,1,1,1,1,1,1,1,\
				0,1,0,0,0,0,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,0,1,0,1,1,0,0,0,1,0,0,0,1,1,1,0,0,1,0,\
				1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,1,0,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,0,1,0,1,0,1,0";
		
	//Declarations of classes:
	QAM qam(4);                    //The QAM modulator class
	AWGN_Channel awgn_channel;     //The AWGN channel class
	it_file ff;                    //For saving the results to file
	BERC berc;                     //Used to count the bit errors
	Real_Timer tt;                 //The timer used to measure the execution time
	Stat stat;
	
	double roll_off_factor = 0.5;
	int filter_length = 64;
	int upsampling_factor = 8;

 	Root_Raised_Cosine<std::complex<double> > rrc_tx(roll_off_factor, filter_length, upsampling_factor);
 	Root_Raised_Cosine<std::complex<double> > rrc_rx(roll_off_factor, filter_length, upsampling_factor);
 	
	//Init:
	Ec = 1.0;                      		//The transmitted energy per QAM symbol is 1.
	Eb = Ec / 2.0;                 		//The transmitted energy per bit is 0.5.
	//EbN0dB = linspace(0.0, 9.0, 10); 	//Simulate for 10 Eb/N0 values from 0 to 9 dB.
	EbN0dB = 20;
	EbN0 = inv_dB(EbN0dB);         		//Calculate Eb/N0 in a linear scale instead of dB.
	N0 = Eb * pow(EbN0, -1.0);     		//N0 is the variance of the (complex valued) noise.


	//Randomize the random number generators in it++:
	RNG_randomize();

	//Modulate the bits to QAM symbols:
	tx_symbols = qam.modulate_bits(tx_bits);
	tx_header_symbols = qam.modulate_bits(tx_header_bits);
	tx_samples = rrc_tx.shape_symbols(tx_symbols); //performs upsampling as well

	//		+---------------------------------------------------+
	//		|						Channel						|
	//		+---------------------------------------------------+
	vec _frequency_offset_vector(linspace(10e3,10e3,tx_samples.length()));
	cout << "pi = " << pi << endl;
	vec _phase_vec(linspace(-2.0*pi,2.0*pi,tx_samples.length()));
	float _n_ampl = 10.0;
	cvec _f_offset_vec(tx_samples.length());
	for(int i=0;i<_f_offset_vec.length();i++){
		_f_offset_vec(i) = std::complex<double>(cos(2*pi*_frequency_offset_vector(i)*i+_phase_vec(i)),
												sin(2*pi*_frequency_offset_vector(i)*i+_phase_vec(i))
												);
	}
	_f_offset_vec = _n_ampl*_f_offset_vec;
	
	tx_samples = elem_mult(tx_samples,_f_offset_vec);
		
	awgn_channel.set_noise(N0);
	//rx = tdlc(tx_samples);
	rx = awgn_channel(tx_samples);
	
	//		+---------------------------------------------------+
	//		|				Start of receiver					|
	//		+---------------------------------------------------+

	//Reset and start the timer:
	tt.tic();
	
	rx_samples = rrc_rx.shape_samples(rx);
	bvec access_list(rx_samples.length());
	//access_list.set_size(rx_samples.length());
	access_list.zeros();
	
	//		+---------------------------------------------------+
	//		|				find start of signal				|
	//		+---------------------------------------------------+

	
	//Start_Counter: Which sample we are currently proccessing in the incomming vector.
	//is_synced: Set if to TRUE if we already have a good sync.
	//Nr_Samples_We_Can't_Process, amount of samples we can't process in the end of the vector. 
	//FIXME Where to handle them?
	int nswcp = 8*((tx_header_bits.length()/2)-1);
	cout << "nswcp = " << nswcp << endl;;
	float fs = 8e6; //Sampling frequency.

	int start_counter = 0;
	double max_corr_sum = 0.0;
	int max_index = 0;
	bool is_synced = false;
	cvec rx_header_symbols, corr;
	
	//Found max index, Correct frequency:
	
	const int fr = 50e3; //Frequency_Range = 50e3;
	const int nf = 1024; //Nr_Frequencies = 10;
	vec fcv(linspace(-fr,fr,nf));//Frequency_Correction_Vector; //Vector containging the frequencies to search.
	vec freq_corr_vec(nf); //correlated frequency- offsetted incomming signal.

	//Loop through to find suitable sampling- point... 
	//FIXME: Implement break if correlation is close enough...
	mat corr_mat(rx_samples.length()-nswcp,nf);
	vec max_vec(rx_samples.length()-nswcp);
	while( ( start_counter < (rx_samples.length() - nswcp) ) && !is_synced ){
		//generate access- list.
		access_list.zeros();
		for(int i=0;i<256;i=i+8){ //FIXME static length loop...
			access_list(i+start_counter) = 1;
		}

		cvec tmp_rx_symbols = rx_samples.get(access_list); //sample that
		corr.zeros(); //zero- set corr... Needed??
		
		corr = xcorr(tmp_rx_symbols, tx_header_symbols, 0); //Correlate with max- offset 0.
		corr_mat.set_row(start_counter, abs(corr(0)*fcv));
		max_vec(start_counter) = max(abs(corr(0)*fcv));
		//will probably need to save index as well...
		//or change start- counter to something in a prediction- fasion...

		if(max_vec(start_counter)>max_corr_sum){
			max_corr_sum = max_vec(start_counter);
			max_index = start_counter;
		}
		start_counter++; //Next sample to process.
	}
	cout << "mi: " << max_index << "\tmc: " << max_corr_sum << endl;

	access_list.zeros();
	for(int i=0;i<256;i=i+8){
		access_list(i+max_index) = 1;
	}
	rx_symbols = rx_samples.get(access_list);
	cout << "rx_symbols.length() = " << rx_symbols.length() << endl;


	//Vector containing the current frequency- correction tone.
	cvec freq_correction( rx_symbols);
	
	//for each nf
	for(int i=0;i<nf;i++){
		for(int j=0;j<freq_correction.length();j++){
			freq_correction(j) = std::complex<double>(cos(2*pi*(fcv(i)/fs)*j*8),sin(2*pi*(fcv(i)/fs)*j*8));
		}
		cvec tmp1 = elem_mult(freq_correction,rx_symbols);
		cvec tmp2 = xcorr(tmp1, tx_header_symbols,0);
		//cout << "tmp2 = " <<tmp2 << endl;
		freq_corr_vec(i) = abs(tmp2(0));
	}
	
	cout << "freq_corr_vec = " << freq_corr_vec << endl;
	int m_index = 0;
	max(freq_corr_vec,m_index);
	cout << "Frequency offset estimation: " << fcv(m_index) << " Hz" << endl;
	//==========================================================================
	/*
	 Found correct sampling time and offset- frequnecy...
	*/
	//Set access- list for found sample- instant...
	access_list.zeros();
	for(int i =max_index;i<access_list.size();i=i+8){ //FIXME 8...
		access_list(i) = 1;
	}
	
	float corr_freq = fcv(m_index);
	int nr_symbols = floor((rx_samples.length()-max_index)/8); //FIXME
	freq_correction.set_size(nr_symbols);

	for(int i=0;i<nr_symbols;i++){
		freq_correction(i) = std::complex<double>(cos(2*pi*(corr_freq/fs)*i*8),sin(2*pi*(corr_freq/fs)*i*8)); 
		//FIXME: Precalculate for speed... 
		//FIXME *8... use variable...
	}

	//Extract the samples set in access_list.
	cvec tmp_syms = rx_samples.get(access_list);
	rx_symbols = elem_mult(tmp_syms, freq_correction);
	
	rx_bits = qam.demodulate_bits(rx_symbols);
	cout << "# RX BITS / # TX BITS / # TX DATA BITS" << endl;
	cout << "symbols demodulated to bits (" << rx_bits.length() << "/"<< tx_bits.length() <<"/"<< tx_data_bits.length() <<")" << endl;
	
	//Calculate the bit error rate:
	berc.clear();                            //Clear the bit error rate counter
	berc.count(tx_bits, rx_bits); 			 //Count the bit errors
	bit_error_rate = berc.get_errorrate();   //Save the estimated BER in the result vector
	
	double tt_toc = tt.toc();
	cout << "Time elapsed: " << tt_toc << endl;
	cout << "-> " << 1.0/tt_toc << " Hz" << endl;
	cout << "-> " << (1.0/tt_toc)*tx_bits.length() << " bits synced / second " << endl;
	//Print the results:
	cout << endl;
	cout << "EbN0dB = " << EbN0dB << " [dB]" << endl;
	cout << "BER = " << bit_error_rate << endl;
	cout << "Saving results to ./qpsk_res.it" << endl;
	cout << endl;

	//Save the results to file:
	ff.open("qpsk_res.it");
	//ff << Name("EbN0dB") << EbN0dB;
	//ff << Name("ber") << bit_error_rate;

	ff << Name("tx_bits") << tx_bits;
	ff << Name("tx_symbols") << tx_symbols;
	ff << Name("tx_samples") << tx_samples;
	ff << Name("rx_samples") << rx_samples;
	ff << Name("rx_symbols") << rx_symbols;
	ff << Name("rx_bits") << rx_bits;
	ff << Name("rx_header_symbols") << rx_header_symbols;
	ff << Name("tx_header_symbols") << tx_header_symbols;
	ff << Name("rx") << rx;
	ff.close();
	cout << "Done\n";
	//Exit program:
	return 0;
}

