#include <itpp/itcomm.h>

using namespace itpp;

void find_start_of_signal(cvec rx_samples, vec &ret_vec, cmat ptm, mat cm, vec pilot_tones_vector, cvec tx_header_symbols, double N0);
double multiply_sum(cvec v1, cvec v2);

//These lines are needed for use of cout and endl
using std::cout;
using std::endl;


int main()
{
  int Number_of_bits;
  double Ec, Eb;
  //vec EbN0dB, EbN0, N0, noise_variance, bit_error_rate;
  double EbN0dB, EbN0, N0, noise_variance, bit_error_rate;
  bvec transmitted_bits, received_bits;                 //vector containing bits
  cvec transmitted_symbols, received_symbols;           //vector containing symbols
  cvec transmitted_samples, received_samples;			//vector containing sampes.

  transmitted_bits = "\
				1,0,0,0,0,1,1,1,1,0,1,1,0,0,0,0,1,1,0,0,1,0,0,1,1,1,1,0,0,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,1,1,0,0,0,1,0,1,1,1,0,1,1,0,0,1,0,0,0,1,0,0, \
				0,0,1,1,0,0,0,1,0,1,0,1,1,0,1,0,1,1,0,0,1,1,0,0,1,0,1,1,0,1,1,1,0,0,1,1,1,1,0,1,\
				1,1,1,0,1,0,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,1,0,1,1,0,0,1,0,0,0,1,1,0,\
				0,1,0,1,0,0,0,0,0,0,1,0,1,1,1,1,0,0,1,1,1,0,0,1,0,1,1,1,1,0,0,0,0,1,1,0,0,1,0,0,\
				1,0,1,0,0,1,1,1,1,0,0,1,0,1,1,0,1,0,1,1,0,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,1,0,1,\
				0,1,0,1,1,1,0,0,1,1,0,1,1,0,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,1,\
				1,1,1,1,1,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,0,0,1,0,0,\
				0,1,0,1,1,0,0,0,1,1,0,0,1,1,1,1,0,1,1,0,1,1,0,0,0,1,0,0,1,0,0,1,1,0,1,0,0,1,0,0,\
				1,1,1,0,0,0,1,0,0,1,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,0,0,0,0,0,0,1,0,0,1,1,0,0,0,\
				0,1,0,1,1,1,1,1,1,1,0,0,0,1,0,1,1,1,1,1,0,0,1,0,0,0,1,1,1,0,1,1,0,1,0,1,1,0,0,1,\
				0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,1,\
				1,0,1,0,0,1,1,0,0,1,1,0,0,0,0,0,0,1,0,0,1,1,0,0,1,0,1,1,1,0,0,1,1,0,1,0,1,1,1,0,\
				1,0,1,0,0,1,0,1,1,1,0,0,0,0,1,0,1,1,0,1,1,1,1,0,0,1,0,0,1,1,1,1,0,1,1,1,1,0,1,1,\
				1,0,1,0,1,0,0,1,0,1,1,0,0,0,1,0,1,1,1,1,0,0,1,1,0,0,1,0,1,0,0,1,1,1,0,1,0,1,1,1,\
				0,1,1,1,0,0,1,0,0,1,1,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,1,1,0,0,1,0,0,0,0,1,0,1,0,0,\
				1,0,0,1,0,0,1,1,1,0,0,0,0,1,1,0,1,0,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,0,0,1,1,0,1,0,\
				1,0,1,0,0,0,1,0,0,1,1,0,0,1,1,0,1,0,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,0,1,0,0,1,1,0,\
				1,1,0,1,1,1,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1,1,0,1,1,0,0,1,1,0,0,1,1,1,0,1,1,\
				1,0,0,0,1,1,0,1,1,1,0,0,1,1,0,0,1,0,1,1,0,0,0,1,1,1,0,1,1,0,0,1,1,1,0,0,0,1,0,0,\
				0,1,0,1,1,1,1,0,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,1,0,0,1,1,1,1,1,1,0,1,0,1,1,1,0,\
				0,0,0,0,0,0,1,1,1,1,0,1,0,0,1,1,0,1,1,0,0,0,1,1,0,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,\
				1,0,1,0,0,0,1,0,1,0,0,1,0,1,1,1,1,1,0,0,1,0,1,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,1,0,\
				1,0,0,1,1,1,1,1,1,1,1,1,1,0,1,0,1,0,0,1,1,1,0,1,1,0,1,1,0,1,0,0,0,1,1,1,1,1,1,1,\
				0,1,0,0,0,0,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1,0,1,0,1,1,0,0,0,1,0,0,0,1,1,1,0,0,1,0,\
				1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,1,0,1,1,1,0,0,1,1,1,1,1,1,1,0,1,0,0,1,0,1,0,1,0";

	//Declarations of classes:
	QAM qam(4);                     //The QPSK modulator class
	AWGN_Channel awgn_channel;     //The AWGN channel class
	it_file ff;                    //For saving the results to file
	BERC berc;                     //Used to count the bit errors

	//Init:
	Ec = 1.0;                      //The transmitted energy per QAM symbol is 1.
	Eb = Ec / 2.0;                 //The transmitted energy per bit is 0.5.
	EbN0dB = 20; //Simulate for 10 Eb/N0 values from 0 to 9 dB.
	EbN0 = inv_dB(EbN0dB);         //Calculate Eb/N0 in a linear scale instead of dB.
	N0 = Eb * pow(EbN0, -1.0);     //N0 is the variance of the noise.
	Number_of_bits = transmitted_bits.length();

	//Allocate space for frequency- correction- matrix.
	int N = 4096;
	int nf = 32; //Nr of frequency- steps
	float fs = 8e6;
	float frequency_range = 50e3/fs;
	vec pilot_tones_vector(linspace(-frequency_range,frequency_range,nf));
	cmat ptm(N+1,nf+1); //matrix with pilot- tones.
	mat cm(N,nf); //matrix with correlations
	ptm.zeros();
	cm.zeros();
	cout << "\t\tFill pilot- tone matrix... ";
	for(int i=0;i<nf;i++){
		cvec tmp_vec(N);
		for(int j=0;j<N;j++){
			tmp_vec(j) = std::complex<double>(cos(2*pi*pilot_tones_vector(i)*j),
											  sin(2*pi*pilot_tones_vector(i)*j));
		}
		ptm.set_col(i,tmp_vec);
	}
	cout << "Done" << endl;


	//Allocate storage space for the result vector.
	//The "false" argument means "Do not copy the old content of the vector to the new storage area."
	//bit_error_rate.set_size(EbN0dB.length(), false);
	bit_error_rate = 0.0;

	//Randomize the random number generators in it++:
	RNG_randomize();
	double roll_off_factor = 0.5;
	int filter_length = 32;
	int upsampling_factor = 8;
 	Root_Raised_Cosine<std::complex<double> > rrc_tx(roll_off_factor, filter_length, upsampling_factor);
 	Root_Raised_Cosine<std::complex<double> > rrc_rx(roll_off_factor, filter_length, upsampling_factor);
 	cvec tx_header_symbols = qam.modulate_bits(transmitted_bits.left(32));

	//Transmitter
	transmitted_symbols = qam.modulate_bits(transmitted_bits);
	transmitted_samples = rrc_tx.shape_symbols(transmitted_symbols);

	//Channel::
	cout << "\tCHANNEL::" << endl;
	float fo = 20e3;
	cvec _f_offset_vec(transmitted_samples);
	cout << "\t\tCreate frequency offset " << fo << "[Hz]... ";
	for(int j=0;j<_f_offset_vec.length();j++){
		_f_offset_vec(j) = std::complex<double>(cos(2*pi*(fo/fs)*j),
												sin(2*pi*(fo/fs)*j));	
	}
	cout << "Done" << endl;

	//Multiply tx- samples with frequency offset.
	cout << "\t\tMultiply tx_samples and frequency offset vector" << endl;
	//transmitted_samples = elem_mult(transmitted_samples,_f_offset_vec);

	cout << "\t\tSet channel noise to " << N0 << " (SNR = " << EbN0dB <<" dB)" << endl;
	awgn_channel.set_noise(N0);
	received_samples = awgn_channel(transmitted_samples);

	//Receiver
	cout << "\tRECEIVER::" << endl;
	received_samples = rrc_rx.shape_samples(received_samples);
	//Find start of signal.
	
	cout << "\t\tReset correlation matrix" << endl;
	cm.zeros();
	cout << "\t\tFind sample- point in time and frequency" << endl;
	vec ret_vector(3);
	ret_vector.zeros();
	find_start_of_signal(received_samples, ret_vector, ptm, cm, pilot_tones_vector, tx_header_symbols, N0);
	//return vec(max_corr_sum, max_index, pilot_tones_vector(max_freq_offset)*fs);
	int sample_index = int(ret_vector(1));
	float frequency_offset = float(ret_vector(2));
	cout << "\t\tCorrelation at sample- point: " << ret_vector(0) << 
								"\tSample index: " << sample_index << 
								"\tFrequency offset: " << frequency_offset << endl;

	bvec access_list(length(received_samples));
	cout << "\t\tGenerate access- list corresponding to sample index and upsampling- factor" << endl;
	for(int k=sample_index;k<received_samples.length();k=k+upsampling_factor){
		access_list(k) = 1;
	}

	cout << "\t\tGenerate correction frequency- vector" << endl;
	cvec correction_freq_vec(received_samples.length());
	for(int k=0;k<correction_freq_vec.length();k++){
		correction_freq_vec(k) = std::complex<double>(cos(2*pi*(frequency_offset/fs)*k),
													  sin(2*pi*(frequency_offset/fs)*k));
	}
	cout << "\t\tMultiply incomming downsampled signal with downsampled frequency correction, and demodulate int bits" << endl;
	received_bits = qam.demodulate_bits(elem_mult(received_samples.get(access_list),correction_freq_vec.get(access_list)));
	cout << "\t\tLength received bits: " << received_bits.length() << "\tLength transmitted bits: " << transmitted_bits.length() << endl;
	//Calculate the bit error rate:
	berc.clear();                               //Clear the bit error rate counter
	berc.count(transmitted_bits, received_bits); //Count the bit errors
	bit_error_rate = berc.get_errorrate();   //Save the estimated BER in the result vector
	cout << "\t\tBER: " << bit_error_rate << endl;

	//Print the results:
	cout << endl;
	cout << "EbN0dB = " << EbN0dB << " [dB]" << endl;
	cout << "BER = " << bit_error_rate << endl;
	cout << "Saving results to ./qpsk_result_file.it" << endl;
	cout << endl;

	//Save the results to file:
	ff.open("qpsk_result_file.it");
	ff << Name("EbN0dB") << EbN0dB;
	ff << Name("ber") << bit_error_rate;
	ff << Name("tx") << transmitted_samples;
	ff << Name("rx") << received_samples;
	ff.close();

	//Exit program:
	return 0;
}

void find_start_of_signal(cvec rx_samples, vec &ret_vec, cmat ptm, mat cm, vec pilot_tones_vector, cvec tx_header_symbols, double N0){
	ret_vec = "32.0,256.0,0.0";
}

double multiply_sum(cvec v1, cvec v2){
	cvec product = elem_mult(v1,v2);
	double d = 0.0;
	
	for(int i=0;i<product.length();i++){
		d += product(i).real()*product(i).real()+product(i).imag()*product(i).imag();
	}
	return d;
}
