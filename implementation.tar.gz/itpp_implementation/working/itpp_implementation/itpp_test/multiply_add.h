#include <itpp/itcomm.h>
using namespace itpp;

double multiply_add(cvec v1,cvec v2);
