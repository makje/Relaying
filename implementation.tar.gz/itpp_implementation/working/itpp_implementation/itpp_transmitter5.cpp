/*
	Lost awgn- performance when doing rrc... will try to utilize the whole- upsampled
	, rrc:ed training- sequence instead of using only the training symbols...
*/
#include <itpp/itbase.h>
#include <itpp/itcomm.h>
#include <itpp/itstat.h>

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <usb.h>
#include <getopt.h>
#include <assert.h>
#include <math.h>
#include <stdexcept>
#include <usrp/usrp_standard.h>
#include <vector>
#include <complex>

#include <itpp/itcomm.h>
#include <itpp/base/random.h>
#include <itpp/comm/pulse_shape.h>

#include <sstream>
using namespace itpp;
using std::cout;
using std::endl;

int main(){

	//Declarations of scalars and vectors:
	int i;
	double Ec, Eb;
	vec EbN0dB, EbN0, N0, noise_variance, bit_error_rate; //vec is a vector containing double
	bvec transmitted_bits, received_bits;                 //bvec is a vector containing bits
	cvec transmitted_symbols, received_symbols;           //cvec is a vector containing double_complex
	cvec transmitted_samples, received_samples;
	cvec channel_freq_offset;
	cvec phase_noise;
	cvec from_channel;
	cvec head_symbols;
	cvec rxfc;
	cvec rxfcp;
	cvec f_o_f;
	#ifdef _DEBUG_
		mat cm(11,1125);
	#endif

	//Declarations of classes:
	QAM qam(4);
	AWGN_Channel awgn_channel;     //The AWGN channel class
	it_file ff;                    //For saving the results to file
	BERC berc;                     //Used to count the bit errors
	Real_Timer tt;                 //The timer used to measure the execution time
	Uniform_RNG phase_generator(-pi, pi);

	//Init:
	Ec = 1.0;                      //The transmitted energy per QPSK symbol is 1.
	Eb = Ec / 2.0;                 //The transmitted energy per bit is 0.5.
	//EbN0dB = linspace(0.0, 9.0, 10); //Simulate for 10 Eb/N0 values from 0 to 9 dB.
	//EbN0dB = linspace(0,10,11);
	EbN0dB = "20";
	EbN0 = inv_dB(EbN0dB);         //Calculate Eb/N0 in a linear scale instead of dB.
	N0 = Eb * pow(EbN0, -1.0);     //N0 is the variance of the (complex valued) noise.
	const int symbols_per_packet = 126;

	bit_error_rate.set_size(EbN0dB.length(), false);

	//Randomize the random number generators in it++:
	RNG_randomize();

	/*bvec head_bits = "0,0,0,0,0,0,1,1,1,0,0,0,1,1,0,1,\
					  0,0,1,0,1,1,1,1,0,0,0,1,0,0,1,1,\
					  0,0,0,0,0,0,1,1,1,0,0,0,1,1,0,1,\
					  0,0,1,0,1,1,1,1,0,0,0,1,0,0,1,1";*/
	bvec head_bits = "1,1,0,1,0,0,0,1,0,0,0,0,1,1,0,0,\
					  1,1,1,1,0,1,0,0,0,0,0,0,0,1,0,0,\
					  1,1,1,1,1,1,1,0,0,0,0,1,0,0,1,0,\
					  1,1,1,1,0,0,1,1,1,1,1,1,0,0,0,1";
					  
	bvec pilot_bits= "1,0,1,0"; //0, 1, 2.
	bvec data_bits = "1,1,0,1, 1,1,0,0, 0,0,1,0, 0,0,0,1, 1,1,0,0,\
					  1,0,1,1, 0,0,0,0, 0,1,1,1, 1,0,0,1, 1,1,0,1,\
					  0,1,0,0, 0,1,0,0, 0,0,0,1, 0,1,1,0, 1,1,0,1,\
					  0,1,0,0, 1,0,1,0, 0,0,1,0, 0,0,0,0, 1,1,1,0,\
					  0,1,1,0, 0,0,0,0, 1,0,1,0, 0,0,1,1";

	int upsampling_factor = 8;
	int filter_length = 4; //FIR- filter is upsampling_factor*filter_length + 1...
	double roll_off_factor = 0.5;
	Root_Raised_Cosine<std::complex<double> > rrc_tx(roll_off_factor,filter_length,upsampling_factor);
	Root_Raised_Cosine<std::complex<double> > rrc_rx(roll_off_factor,filter_length,upsampling_factor);

	//String- manipulators for expressions like "1:8:100" when manupulating vectors...
	std::string vector_str;
	std::stringstream ss_vector_out;

	for (i = 0; i < EbN0dB.length(); i++) {
		#ifdef _DEBUG_
			cout << "Now simulating Eb/N0 value number " << i + 1 << " of " << EbN0dB.length() << endl;
		#endif

		//TRANSMITTER
		//Generate a vector of random bits to transmit:
		//Did this with a for- loop, but this feels safer =;O
		transmitted_bits = concat(head_bits, data_bits(0,3), pilot_bits);
		transmitted_bits = concat(transmitted_bits, data_bits(4 ,7 ), pilot_bits, data_bits(8 ,11), pilot_bits);
		transmitted_bits = concat(transmitted_bits, data_bits(12,15), pilot_bits, data_bits(16,19), pilot_bits);
		transmitted_bits = concat(transmitted_bits, data_bits(20,23), pilot_bits, data_bits(24,27), pilot_bits);
		transmitted_bits = concat(transmitted_bits, data_bits(28,31), pilot_bits, data_bits(32,35), pilot_bits);
		transmitted_bits = concat(transmitted_bits, data_bits(36,39), pilot_bits, data_bits(40,43), pilot_bits);
		transmitted_bits = concat(transmitted_bits, data_bits(44,47), pilot_bits, data_bits(48,51), pilot_bits);
		transmitted_bits = concat(transmitted_bits, data_bits(52,55), pilot_bits, data_bits(56,59), pilot_bits);
		transmitted_bits = concat(transmitted_bits, data_bits(60,63), pilot_bits, data_bits(64,67), pilot_bits);
		transmitted_bits = concat(transmitted_bits, data_bits(68,71), pilot_bits, data_bits(72,75), pilot_bits);
		transmitted_bits = concat(transmitted_bits, data_bits(76,79), pilot_bits, data_bits(80,83), pilot_bits);
		transmitted_bits = concat(transmitted_bits, data_bits(84,87), pilot_bits, data_bits(88,91), pilot_bits);
		transmitted_bits = concat(transmitted_bits, data_bits(92,95));

		transmitted_symbols = qam.modulate_bits(transmitted_bits);
		head_symbols = qam.modulate_bits(head_bits);
		
		double usrp_f_offset = 23456.0;
		//double gamma = 1/max(rrc_tx.get_pulse_shape()); //normalization factor...
		transmitted_samples = rrc_tx.shape_symbols(transmitted_symbols);
		cvec rrc_head_symbols = rrc_tx.shape_symbols(head_symbols);
		cvec pad_vec((1024-length(transmitted_samples))/2);
		pad_vec.zeros();
		#ifdef _DEBUG_
			cout << "12x: ";
			cout << "pad_vec.length(): " << pad_vec.length() << endl;
		#endif
		transmitted_samples = concat(pad_vec, transmitted_samples, pad_vec);		
		
		//CHANNEL
		{
			awgn_channel.set_noise(N0(i)); //Set awgn power
			cvec channel_delay(100); //Create a delay... 100 symbols/samples
			
			channel_delay.zeros(); //channel- delay = 0
			from_channel = concat(channel_delay,transmitted_samples); //concat delay and signal
			
			channel_freq_offset.set_size(length(from_channel),false); //create empty usrp- offset- tone
			int N = channel_freq_offset.length(); //length of transmitted sequence
			
			channel_freq_offset = exp(std::complex<double>( 0.0, (2*pi*(double(double(usrp_f_offset)/1.0e6))) )*linspace(0,N-1,N) );
			phase_noise = exp(std::complex<double>(0.0,1.0)*phase_generator())*ones(N); //phase- noise

			#ifdef _DEBUG_
				cout << "14x: ";
				cout << length(from_channel) << " " << length(channel_freq_offset) << " " << length(phase_noise) << endl;
				cout << "15x: ";
				cout << "N0(i): " << N0(i) << "\tEbN0dB(i): " << EbN0dB(i) << endl;
			#endif

			from_channel = elem_mult(from_channel,channel_freq_offset); //Multiply tx, f_offset and phase
			from_channel = awgn_channel(from_channel); //add awgn
		}
		
		//RECEIVER
		
		/***/
		//Receiver
		//rx = awgn_channel(from_channel); 
		//received_samples = rrc_rx.shape_samples(from_channel); 
		received_samples = from_channel;
		
		//Generate tone- matrix:
		int nfrequencies = 11; 
		int Nrx = length(received_samples);
		vec tones_vector = linspace(-50e3,50e3,nfrequencies);
		cmat tone_matrix(nfrequencies,Nrx);
		{
			for(int r=0;r<nfrequencies;r++){
					tone_matrix.set_row(r,exp( (std::complex<double>(0.0,1.0)*2*pi*(tones_vector(r)/1.0e6))*linspace(0,Nrx-1,Nrx)));
			}
		}
		#ifdef _TIMING_
			tt.tic();
		#endif
		
		int sync_index = 0;
		int freq_index = 0;
		{ //scope sync.
			int n = 0; bool is_synced = false;
			while(!is_synced && n<Nrx/2){ //16 = nr header symbols, 8 = samples per symbol
				ss_vector_out.str("");
				ss_vector_out << n << ":" << n+(32)*upsampling_factor;

				#ifdef _DEBUG_
					cout << "18x: n: " << n << ", ss_vector_out.str(): " << ss_vector_out.str() << endl;
				#endif
				
				ivec access_list(ss_vector_out.str());
				cvec possible_rx_header = received_samples(access_list); //possible_rx_header = received_samples(n:D:n+31*D)
				#ifdef _DEBUG_
					cout << "length(possible_rx_header) = " << length(possible_rx_header) << endl;
				#endif
				{
					//Multiply the sampled symbols with all the tones from the matrix, and look at the correlation...
					for(int p=0;p<tones_vector.length();p++){
						#ifdef _DEBUG_
							cout << "19x: p: " << p << "\t->\t" << tones_vector(p) << "Hz" << endl;
						#endif
						
						cvec freq_compensation = tone_matrix.get_row(p); //get tone
						cvec freq_compensated_rx = elem_mult(freq_compensation(access_list),possible_rx_header); //multiply tone with rx
						
						double c = abs(elem_mult_sum(freq_compensated_rx,conj(rrc_head_symbols)));
						
						#ifdef _DEBUG_
							cm.set(p,n,c);
						#endif
						
						//double channel_gain = 0.9910;
						//double tolerance = sum(abs(N0(i)*conj(head_symbols))); //FIXME Estimate N0(i)...
						double channel_gain = 1.0;
						double tolerance = 0.4;
						if(c>14.0){
						//if(within_tolerance(c,length(head_symbols)*channel_gain,tolerance) ){
							is_synced = true;
							sync_index = n;
							freq_index = p;
						}
					} 
				} 
				n++;
			}	//end while

			//Check if we didn't find a sync:
			is_synced = true;
			if(!is_synced){
				//Fetch new data
				cout << "Fetch new data!!" << endl;
				return -1;
			}
		} //end scope sync.
			
		#ifdef _DEBUG_
			double mf = tones_vector(freq_index); //get frequency to compensate with
			cout << "21x: ";
			cout << "mf: " << mf << "\tsync_index: " << sync_index << "\tfrequency estimation error: " << usrp_f_offset+mf << endl;
		#endif

		cvec best_rx_freq_comp = tone_matrix.get_row(freq_index);
		//END OF COARSE SYNC
		
		//reset string- manipulators...
		ss_vector_out.str("");
		
		ss_vector_out << sync_index << ":" << upsampling_factor << ":" << sync_index+(symbols_per_packet-1)*upsampling_factor;
		
		#ifdef _DEBUG_
			cout << "22x: ";
			cout << "ss_vector_out.str() = " << ss_vector_out.str() << endl;
		#endif

		ivec index_list(ss_vector_out.str());
		received_symbols = elem_mult(received_samples(index_list),best_rx_freq_comp(index_list));
		
		#ifdef _DEBUG_
			//cout << "received_symbols = " << received_symbols << endl;
			cout << "int rN = recived_symbols.length() = " << received_symbols.length() << endl;
		#endif

		//received_symbols = from_channel.get(sync_index,sync_index+symbols_per_packet-1); //pick out sequence
		int rN = length(received_symbols); //length of received symbols
		cvec received_header = received_symbols.get(0,31); //these are (hopefully) our header
		#ifdef _DEBUG_
			cout << "received_header = " << received_header << endl;
		#endif

		f_o_f = elem_mult(received_header,conj(head_symbols)); //f_o_f = c*|s|*exp(j*2*pi*(f_offset/fs)*i)
		int fft_len = 2048;
		cvec F_O_F = fft(f_o_f,fft_len);
		int mi = max_index(abs(F_O_F)); //get index of max- point in fft.
		
		double f_hat = (double(mi)/double(fft_len))*(1.0/8.0)*1e6; //max_index -> f_offset mapping.
		#ifdef _DEBUG_
			cout << "27x: max_index from fft: " << mi << "(" << fft_len << ") -> " << double( ( double(mi)- double(fft_len/2) )/double(fft_len) )*1e6 << endl;
			cout << "27x: ";
			cout << "f_hat from fft: " << f_hat << "\tTotal offset: " << (abs(abs(mf+f_hat)-abs(usrp_f_offset))) << endl;
		#endif

		cvec f_est = exp(std::complex<double>(0.0,(2*pi*(-f_hat) ) )*linspace(sync_index,sync_index+rN,rN));
		rxfc = elem_mult(received_symbols,f_est); //multiply received- symbols with estimated frequency- offset.

		//compensate for phase and 
		rxfcp = rxfc/mean(elem_mult(rxfc(0,31),conj(head_symbols)));

		received_bits = qam.demodulate_bits(rxfcp); //Demodulate.

		#ifdef _TIMING_
			cout << "26x: ";
			tt.toc_print();
		#endif

		//Calculate the bit error rate:
		berc.clear();                               //Clear the bit error rate counter
		berc.count(transmitted_bits, received_bits); //Count the bit errors
		bit_error_rate(i) = berc.get_errorrate();   //Save the estimated BER in the result vector
	}
	//Print the results:
	
	#ifdef _DEBUG_
		cout << endl;
		cout << "EbN0dB = " << EbN0dB << " [dB]" << endl;
		cout << "BER = " << bit_error_rate << endl;
		cout << "Saving results to ./qpsk_result_file5.it" << endl;
		cout << endl;

		//Save the results to file:
		ff.open("qpsk_result_file5.it");
		ff << Name("EbN0dB") << EbN0dB;
		ff << Name("ber") << bit_error_rate;

		ff << Name("tx_bits") << transmitted_bits;
		ff << Name("tx_symbols") << transmitted_symbols;

		ff << Name("from_channel") << from_channel;
		ff << Name("channel_freq_offset") << channel_freq_offset;
		ff << Name("phase_noise") << phase_noise;
		ff << Name("rx_symbols") << received_symbols;
		ff << Name("f_o_f") << f_o_f;
		ff << Name("rxfc") << rxfc;
		ff << Name("rxfcp") << rxfcp;
		ff << Name("tx_samples") << transmitted_samples;
		ff << Name("rx_samples") << received_samples;
		ff << Name("rrc_tx") << rrc_tx.get_pulse_shape();
		ff << Name("rrc_rx") << rrc_rx.get_pulse_shape();
		ff << Name("received_bits") << received_bits;
		ff << Name("transmitted_bits") << transmitted_bits;
	
		ff << Name("cm") << cm;
	#endif
	ff.close();

	//Exit program:
	return 0;

}


