#include <gr_top_block.h>
#include <gr_vector_source_b.h>

#include <gr_unpacked_to_packed_bb.h>
#include <gr_endianness.h>

#include <gr_stream_mux.h>

#include <gr_chunks_to_symbols_bc.h>

#include <gr_interp_fir_filter_ccf.h>
#include <gr_firdes.h>

#include <usrp_sink_c.h>
#include <usrp_subdev_spec.h>

#include <gr_file_source.h>
#include <gr_file_sink.h>
class top_block;

typedef boost::shared_ptr<top_block> top_block_sptr;

top_block_sptr make_top_block();

class top_block:public gr_top_block{
	private:
		//VARIABLES
		int d_sps;
		float d_rrc_bw;
		float d_rrc_ampl;
		double d_rf_freq;
		int d_interp;
		double d_gain;

		//BLOCKS
		gr_vector_source_b_sptr						d_bits_data;
		//gr_file_source_sptr						d_bits_data;
		gr_vector_source_b_sptr						d_bits_train;
		gr_vector_source_b_sptr						d_bits_header;

		gr_unpacked_to_packed_bb_sptr			d_data_packer;
		gr_unpacked_to_packed_bb_sptr			d_train_packer;

		gr_stream_mux_sptr 								d_stream_muxer;
		gr_stream_mux_sptr 								d_header_muxer;

		gr_chunks_to_symbols_bc_sptr			d_mapper;

		gr_interp_fir_filter_ccf_sptr			d_rrc_tx;
		gr_interp_fir_filter_ccf_sptr			d_rrc_rx;
		
		usrp_sink_c_sptr									d_tx;
		db_base_sptr											d_db;
		//HELPER FUNCTION
		void configure_usrp();
	public:
		top_block();
		friend top_block_sptr make_top_block();
		~top_block();
};
