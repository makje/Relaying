#include "top_block.h"
#include <signal.h>

static volatile bool signaled = false;
static volatile bool alarm_signaled = false;

static void sig_handler(int sig){
  signaled = true;
}
static void alarm_handler(int sig){
  alarm_signaled = true;
}

int main(int argc, char **argv){
	printf("Setting up signal- handlers\n");
	struct sigaction action;
	memset(&action, 0, sizeof(action));
	action.sa_handler = sig_handler;
	action.sa_flags = 0;
	if(sigaction(SIGINT, &action,0)<0){
	  printf("Unable to install signal- handler for SIGINT\n");
	  return -1;
	}

	struct sigaction alarm_action;
	memset(&alarm_action, 0, sizeof(alarm_action));
	alarm_action.sa_handler = alarm_handler;
	alarm_action.sa_flags = 0;
	if(sigaction(SIGALRM, &alarm_action,0)<0){
	  printf("Unable to install signal- handler for SIGALRM\n");
	  return -1;
	}


	printf("Making top- block\n");
	top_block_sptr top_block = make_top_block();
	top_block->start();
	while(!signaled){
		/*std::cout << "Start" << std::endl;
		top_block->start();
		sleep(2);
		std::cout << "STOP" << std::endl;
		top_block->stop();
		top_block->wait();
		sleep(5);*/
	}
	top_block->stop(); //just to safe...
	top_block->wait();
/*
	for(int i = 0;i<100;i++){
		top_block->start();
		printf(".");
		top_block->wait();
		sleep(1);
	}*/
	return 0;
}
