% File to check whats going on in pilot- insertion test code...
clear all
%dump_symbols = gr_make_file_sink(sizeof(gr_complex), "muxed_symbols.dat");
%dump_muxed = gr_make_file_sink(sizeof(unsigned char), "muxed_bits.dat");

fid1 = fopen('muxed_symbols.dat','r');
fid2 = fopen('muxed_bits.dat','r');
tmp = fread(fid1,'float');
muxed_symbols = tmp(1:2:end)+j*tmp(2:2:end);
muxed_bits = fread(fid2,'char');
clear tmp;
fclose(fid1);
fclose(fid2);