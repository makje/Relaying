%% Generate the data 'bits' that are going to be transmitted...
path(path,'~/gnuradio/gnuradio-core/src/utils');
filename = 'tx_data.dat';
N = 3000;

rand('twister',4657)
r = ceil(4.*rand(N,1))-1;

f = fopen (filename, 'wb');
v = fwrite(f, r, 'char');
fclose (f);
