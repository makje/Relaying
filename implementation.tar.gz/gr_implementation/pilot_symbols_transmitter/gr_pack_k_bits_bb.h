#ifndef INCLUDED_GR_PACK_K_BITS_BB_H
#define	INCLUDED_GR_PACK_K_BITS_BB_H

#include <gr_sync_decimator.h>

class gr_pack_k_bits_bb;

typedef boost::shared_ptr<gr_pack_k_bits_bb> gr_pack_k_bits_bb_sptr;

gr_pack_k_bits_bb_sptr gr_make_pack_k_bits_bb(unsigned k);

class gr_pack_k_bits_bb : public gr_sync_decimator{
 private:
  friend gr_pack_k_bits_bb_sptr gr_make_pack_k_bits_bb(unsigned k);
  gr_pack_k_bits_bb(unsigned k);
  unsigned int d_k;

 public:
  ~gr_pack_k_bits_bb ();
  int work(int noutput_items,
	    gr_vector_const_void_star &input_items,
	    gr_vector_void_star &output_items);
};
#endif
