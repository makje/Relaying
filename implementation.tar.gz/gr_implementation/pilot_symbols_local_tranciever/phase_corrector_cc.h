#ifndef INCLUDED_PHASE_CORRECTOR_CC_H
#define INCLUDED_PHASE_CORRECTOR_CC_H

#include <gr_block.h>

class phase_corrector_cc;
typedef boost::shared_ptr<phase_corrector_cc> phase_corrector_cc_sptr;

phase_corrector_cc_sptr make_phase_corrector_cc();

class phase_corrector_cc: public gr_block{
	private:
		int d_symbol_counter;
		int d_header_length;
		int d_data_counter;
		std::vector<gr_complex>	d_modulated_header;
		std::vector<gr_complex> data_vec;
		gr_complex d_pilot;
		int d_packet_length;
		phase_corrector_cc();
		friend phase_corrector_cc_sptr make_phase_corrector_cc();
		int sign(float f);
	public:
  int general_work (int noutput_items,
		    gr_vector_int &ninput_items,
		    gr_vector_const_void_star &input_items,
		    gr_vector_void_star &output_items);
};

#endif