#include <gr_top_block.h>
#include <gr_file_sink.h>
#include <gr_delay.h>
#include <gr_channel_model.h>

//Transmitting blocks
#include <gr_glfsr_source_b.h>
#include <gr_vector_source_b.h>

#include "gr_pack_k_bits_bb.h"

#include <gr_stream_mux.h>
#include <gr_chunks_to_symbols_bc.h>

#include <gr_interp_fir_filter_ccf.h>
#include <gr_firdes.h>

//Receiving blocks
#include <gr_fir_filter_ccf.h> //Rx rrc
#include <gr_firdes.h>
#include <gr_pwr_squelch_cc.h>
#include "header_correlator_cc.h"
#include "symbol_extractor_cc.h"
#include "phase_corrector_cc.h"
#include <gr_constellation_decoder_cb.h>
#include <gr_unpack_k_bits_bb.h>

class top_block;

typedef boost::shared_ptr<top_block> top_block_sptr;

top_block_sptr make_top_block();

class top_block:public gr_top_block{
	private:
		//VARIABLES Transmitting
		int d_sps;
		float d_rrc_bw;
		float d_rrc_ampl;
		double d_rf_freq;
		int d_interp;

		//Variables, receiving

		//BLOCKS
		//Transmitting blocks.
		gr_vector_source_b_sptr						d_bits_data;
		gr_glfsr_source_b_sptr 						d_glfsr;
		gr_vector_source_b_sptr						d_bits_train;
		gr_vector_source_b_sptr						d_bits_header;

		gr_pack_k_bits_bb_sptr						d_data_packer;
		gr_pack_k_bits_bb_sptr						d_train_packer;

		gr_stream_mux_sptr 								d_stream_muxer;
		gr_stream_mux_sptr 								d_header_muxer;

		gr_chunks_to_symbols_bc_sptr			d_mapper;

		gr_interp_fir_filter_ccf_sptr			d_rrc_tx;

		//Channel blocks
		gr_delay_sptr 										d_delay;
		gr_channel_model_sptr 						d_channel;

		//Rx- blocks
		gr_fir_filter_ccf_sptr						d_rrc_rx;
		gr_pwr_squelch_cc_sptr 						d_squelch;
		header_correlator_cc_sptr					d_header_correlator;
		symbol_extractor_cc_sptr					d_symbol_extractor;
		phase_corrector_cc_sptr 					d_phase_corrector;
		gr_constellation_decoder_cb_sptr 	d_demapper;
		gr_unpack_k_bits_bb_sptr 					d_unpacker;
		//usrp_sink_c_sptr									d_tx;
		//db_base_sptr											d_db;
		void configure_usrp();
	public:
		top_block();
		friend top_block_sptr make_top_block();
		~top_block();
};