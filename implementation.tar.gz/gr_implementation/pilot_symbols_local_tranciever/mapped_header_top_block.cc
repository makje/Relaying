#include "mapped_header_top_block.h"
#include <gr_file_sink.h>
#include <gruel/realtime.h>
#include <vector>

using namespace std;

mapped_header_top_block_sptr make_mapped_header_top_block(){
	return gnuradio::get_initial_sptr(new mapped_header_top_block());
}

mapped_header_top_block::mapped_header_top_block():gr_top_block("mapped_header_top_block"){

	//Create vector source
	printf("creating vectors\n");
	unsigned char header[] = {2,0,1,3,2,3,0,0,3,0,2,1,3,2,1,3,3,2,2,2,
														2,3,0,1,1,3,1,2,1,0,1,0,1,2,1,2,3,2,3,1,
														2,2,1,0,2,2,2,0,1,2,3,2,2,2,1,1,2,3,1,2,
														3,3,1,2,1,2,1,3,2,2,3,1,1,1,1,2,3,3,0,3,
														3,1,1,1,2,2,3,1,2,2,2,3,1,3,3,3,3,2,2,1};
	std::vector<unsigned char> packet_header_b(header,header+sizeof(header)/sizeof(unsigned char));
	d_bits_header= gr_make_vector_source_b(packet_header_b,false);
	
	printf("Creating constellation\n");
	float t = sqrt(2)/2;
	gr_complex c[] = {
		gr_complex(-t, t), gr_complex(t, t),
		gr_complex(-t,-t), gr_complex(t,-t)
	};

	std::vector<gr_complex> constellation(c, c+sizeof(c)/sizeof(gr_complex));
	d_mapper = gr_make_chunks_to_symbols_bc(constellation);

	gr_file_sink_sptr mapped = gr_make_file_sink(sizeof(gr_complex), "mapped_header.dat");
	printf("Connecting blocks\n");	
	connect(d_bits_header,	0, d_mapper,0); printf(".");
	connect(d_mapper,				0, mapped, 0); printf(".");
	printf("Done\n");
}

mapped_header_top_block::~mapped_header_top_block(){
}
