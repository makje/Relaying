//rx_main.cpp
#include "mapped_header_top_block.h"

int main(int argc, char **argv){
	mapped_header_top_block_sptr top_block = make_mapped_header_top_block();
	
	top_block->start();
	top_block->wait();
	top_block->stop();
	
	return 0;
}
