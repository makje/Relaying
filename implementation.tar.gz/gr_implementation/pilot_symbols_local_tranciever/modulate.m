function symbols = modulate(in_data)
assert(max(in_data)<=3);
assert(min(in_data)>=0);
%     |
%  0  |  1
%     |
%-----|----->
%     |
%  2  |  3
%     |
symbols = zeros(size(in_data));
t = sqrt(2)/2;
for k=1:length(in_data)
    switch in_data(k)
        case 0
        symbols(k) = -t+1j*t;
        case 1
        symbols(k) = t+1j*t;
        case 2
        symbols(k) = -t-1j*t;
        case 3
        symbols(k) = t-1j*t;
      otherwise
        disp('ERROR IN INPUT TO MODULATOR');
    end
end