//Only works for 2...
#include "gr_pack_k_bits_bb.h"
#include <gr_io_signature.h>
#include <stdexcept>
#include <iostream>

gr_pack_k_bits_bb_sptr gr_make_pack_k_bits_bb(unsigned k){
  return gr_pack_k_bits_bb_sptr (new gr_pack_k_bits_bb(k));
}

gr_pack_k_bits_bb::gr_pack_k_bits_bb(unsigned k)
  : gr_sync_decimator("pack_k_bits_bb",
			  gr_make_io_signature (1, 1, sizeof (unsigned char)),
			  gr_make_io_signature (1, 1, sizeof (unsigned char)),
			  k), d_k(k){
  if (d_k == 0)
    throw std::out_of_range("decimation must be > 0");
}

gr_pack_k_bits_bb::~gr_pack_k_bits_bb(){
}

int gr_pack_k_bits_bb::work(int noutput_items,
			   gr_vector_const_void_star &input_items,
			   gr_vector_void_star &output_items){
  const unsigned char *in = (const unsigned char *) input_items[0];
  unsigned char *out = (unsigned char *) output_items[0];
/*
  int n = 0;
  for (unsigned int i = 0; i < noutput_items/d_k; i++){
    unsigned int t = in[i];
    for (int j = d_k - 1; j >= 0; j--)
      out[n++] = (t >> j) & 0x01;
  }
*/
	int n = 0;
	for(unsigned int i=0;i<noutput_items * d_k ;i=i+d_k){
		char t1 = in[i];
		char t2 = in[i+1];
		//out[n] = ( (t2<<1) + t1 ) & 0x3;
		out[n] = ( (t1<<1) + t2 ) & 0x3;
		n++;
		
	}
	
  //assert(n == noutput_items);
  return noutput_items;
}
