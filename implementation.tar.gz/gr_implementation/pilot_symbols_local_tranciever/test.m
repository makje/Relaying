clear all

glfsr = read_char_binary('glfsr.dat');
glfsr_packed = read_char_binary('glfsr_packed.dat');
header_muxed = read_char_binary('header_muxed.dat');
mapped = read_complex_binary('mapped.dat');
train_muxed = read_char_binary('train_muxed.dat');
rx = read_complex_binary('rx.dat');
squelched = read_complex_binary('squelched.dat');
hdr_signal = read_complex_binary('hdr_corr_signal.dat');
hdr_corr_gate = read_complex_binary('hdr_corr_gate.dat');
hdr_corr_sum = read_complex_binary('hdr_corr_sum.dat');
demapped = read_char_binary('demodulated_symbols.dat'); %compare this with glfsr_packed...
received_bits = read_char_binary('received_bits.dat');

symbols = read_complex_binary('extracted_symbols.dat');
corrected_data_symbols = read_complex_binary('corrected_data_symbols.dat');

c = mapped(1:100);
matlab_hdr_correl = [];
for k=1:10000
    matlab_hdr_correl = [matlab_hdr_correl abs(hdr_signal(k:8:k+99*8)'*conj(c))];
end

plot(corrected_data_symbols,'.')

demap_len = length(demapped);
ser = 0;
for k=1:demap_len
    if(glfsr_packed(k) ~= demapped(k))
        sum = sum+1;
    end
end
figure();plot(glfsr_packed(1:demap_len)-demapped), title(['SER: ' num2str(ser/demap_len)]);
figure();plot(received_bits-glfsr(1:length(received_bits))), title(['ber']);