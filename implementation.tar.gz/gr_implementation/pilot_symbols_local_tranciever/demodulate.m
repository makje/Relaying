function output = demodulate(in_data)
    %     |
    %  0  |  1
    %     |
    %-----|----->
    %     |
    %  2  |  3
    %     |
    output = zeros(size(in_data));
    for k= 1:length(in_data)
        sym = in_data(k);
        if real(sym)>0
            if imag(sym)>0
                %++
                output(k) = 1;
            else
                %+-
                output(k) = 3;
            end
        else
            if imag(sym)>0
                %-+
                output(k) = 0;
            else
                %--
                output(k) = 2;
            end
        end
    end
end