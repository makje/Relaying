/* -*- c++ -*- */
/* Code is based on gpl:ed code from gnuRadio.
 */

#include "header_correlator_cc.h"
#include <gr_io_signature.h>
#include <vector>

using namespace std;
header_correlator_cc_sptr make_header_correlator_cc(){
  return header_correlator_cc_sptr (new header_correlator_cc());
}

header_correlator_cc::header_correlator_cc():gr_sync_decimator("header_correlator_cc",
																							gr_make_io_signature (1, 1, sizeof(gr_complex)),
																							gr_make_io_signature (2, 3, sizeof(gr_complex)),
																							1){
  d_len = 100; //FIXME
	gr_complex mod_hdr[] = {
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex(-0.7071, 0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex(-0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071, 0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071, 0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071)
	};
	std::vector<gr_complex> dmh(mod_hdr, mod_hdr+sizeof(mod_hdr)/sizeof(gr_complex));
	d_modulated_header = dmh;
  d_pn = d_modulated_header[0];
	d_bit_counter = 0;
	d_is_synced = false;
}

header_correlator_cc::~header_correlator_cc(){
	//Might need it later...
}

int
header_correlator_cc::work(int noutput_items,
			  gr_vector_const_void_star &input_items,
			  gr_vector_void_star &output_items)
{
	const gr_complex *in = (const gr_complex *) input_items[0];
	gr_complex *out = (gr_complex *) output_items[0];
	gr_complex *hs = (gr_complex *) output_items[1];
	gr_complex *sum_sig = (gr_complex *) output_items[2];

	float sum = 0.0;
	if(!d_is_synced){ //we are not synced... Find the sweet- spot.
		for(int k=0;k<noutput_items;k++){ //k = start sample
			sum = 0.0;
			for(int l=k;(l<k+800) && (l<noutput_items);l=l+8){ //FIXME: l<...
				sum+=abs(in[l]*conj(d_pn));
				d_pn = d_modulated_header[++d_bit_counter%100]; //FIXME %100
			}
			if(sum>=10000){ //FIXME: HARD LIMIT
				d_is_synced = true;
			}

			if(d_is_synced){
				out[k] = in[k];
				hs[k] = gr_complex(1.0,0.0);
				sum_sig[k] = gr_complex(sum/noutput_items,0.0);
			}
			else{
				out[k] = gr_complex(0.0,0.0);
				hs[k] = gr_complex(0.0,0.0);
				sum_sig[k] = gr_complex(sum/noutput_items);
			}
		}
	}
	else{ //We are already synced...
		for(int k=0;k<noutput_items;k++){
			out[k] = in[k];
			hs[k] = gr_complex(1.0,0.0);
			sum_sig[k] = gr_complex(0.0,0.0);
		}
	}
  return noutput_items;
}
