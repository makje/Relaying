#include <gr_top_block.h>
#include <gr_file_sink.h>

#include <gr_vector_source_b.h>
#include <gr_chunks_to_symbols_bc.h>

class mapped_header_top_block;

typedef boost::shared_ptr<mapped_header_top_block> mapped_header_top_block_sptr;

mapped_header_top_block_sptr make_mapped_header_top_block();

class mapped_header_top_block:public gr_top_block{
	private:
		gr_vector_source_b_sptr						d_bits_header;
		gr_chunks_to_symbols_bc_sptr			d_mapper;
	public:
		mapped_header_top_block();
		friend mapped_header_top_block_sptr make_mapped_header_top_block();
		~mapped_header_top_block();
};