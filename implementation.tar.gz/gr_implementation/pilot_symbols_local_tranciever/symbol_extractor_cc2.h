#ifndef INCLUDED_SYMBOL_EXTRACTOR_H
#define INCLUDED_SYMBOL_EXTRACTOR_H

#include <gr_block.h>

class symbol_extractor_cc;
typedef boost::shared_ptr<symbol_extractor_cc> symbol_extractor_cc_sptr;

symbol_extractor_cc_sptr make_symbol_extractor_cc(int sps);

class symbol_extractor_cc: public gr_block{
	private:
		int d_sps; //samples per symbol, effectivly the decimation- factor.
		int d_lsp; 
		int d_start_sample_at; //FIXME: REDUNDANT with d_lsp.
		bool d_first_buffer; //flag for first buffer with a signal.
		symbol_extractor_cc(int sps);
		friend symbol_extractor_cc_sptr make_symbol_extractor_cc(int sps);
	public:
  int general_work (int noutput_items,
		    gr_vector_int &ninput_items,
		    gr_vector_const_void_star &input_items,
		    gr_vector_void_star &output_items);
};

#endif