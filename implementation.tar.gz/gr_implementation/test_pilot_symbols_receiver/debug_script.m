%% Debug- script for qpsk- transmission with muxed pilots. RX- side
path(path,'/home/mattias/Projects/gnuradio/gnuradio-core/src/utils')

rx = read_complex_binary('tx.dat');
tx_bits = read_char_binary('tx_bits.dat');
tx_symbols = read_complex_binary('tx_symbols.dat');

header = [2,0,1,3,2,3,0,0,3,0,2,1,3,2,1,3,3,2,2,2, ...
		  2,3,0,1,1,3,1,2,1,0,1,0,1,2,1,2,3,2,3,1, ...
		  2,2,1,0,2,2,2,0,1,2,3,2,2,2,1,1,2,3,1,2, ...
		  3,3,1,2,1,2,1,3,2,2,3,1,1,1,1,2,3,3,0,3, ...
		  3,1,1,1,2,2,3,1,2,2,2,3,1,3,3,3,3,2,2,1];

sps = 8; %Samples per symbol.
fs = 8e6;
rrc_length = 11*sps;

[t_samp, sync_corr_vector] = sync(rx', header, sps, 100, length(rx)/2);
c = rx(t_samp:sps:end)/sqrt(norm(rx));
%c = rx(rrc_length/2:sps:end)/sqrt(norm(rx));
%c = rx(1:sps:end)/sqrt(norm(rx));
rx_header = c(1:100);
c = c(101:end);
%c = c(2:end); %för att synca med "3 0 2 1 0"- strukturen...
s = sqrt(2)/2*exp(j*pi*3/4); %% Tränings- symbol...

%% Correct phase
c_hat = c;
for k=5:5:length(c_hat)
    %if angle(c(k))>angle(s)
        %c_hat(k-4:k) = c(k-4:k)*(s-c(k));
    %else
        c_hat(k-4:k) = 2/sqrt(2)*c(k-4:k)*exp(angle(c(k))-angle(s));
    %end
end


plot(c,'x'), hold on, plot(c_hat,'ro'), axis equal, grid on

b_hat = zeros(size(c_hat));
for k=1:length(c_hat)
    sym = c_hat(k);
    if real(sym)>0
        if imag(sym)>0
            %++
            b_hat(k) = 1;
        else
            %+-
            b_hat(k) = 3;
        end
    else
        if imag(sym)>0
            %-+
            b_hat(k) = 0;
        else
            %--
            b_hat(k) = 2;
        end
    end
end

figure(); stem(b_hat)
