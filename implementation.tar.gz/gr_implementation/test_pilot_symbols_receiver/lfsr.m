function y = lfsr(x)
    d_shift_register = x.d_shift_register;
    d_mask = x.d_mask;
    input = x.input;
    output = d_shift_register(1);
    
    popCount = 0;
    for k=1:length(d_shift_register)
        tmp = and(d_shift_register(k),d_mask(k));
        if tmp == 1
            popCount = popCount+1;
        end
    end
    popCount = mod(popCount,2);
    
    newbit = xor(popCount,input);
    
    %shift register one step 
    tmp_shift_register = zeros(1,length(d_shift_register));
    for k=2:length(d_shift_register)
        tmp_shift_register(k-1) = d_shift_register(k);
    end
    tmp_shift_register(end) = newbit;
    d_shift_register = tmp_shift_register;

    y = struct('d_shift_register',d_shift_register, ...
               'd_mask',          d_mask, ...
               'input', input, ...
               'output',output);
    