//rx_main.cpp
#include "rx_top_block.h"

#include <signal.h>
#include <string.h>
#include <iostream>
#include <cstdio>
#include <stdio.h>
#include <stdlib.h>
#include <boost/thread.hpp>

rx_top_block_sptr rx_top_block;
static volatile bool signaled = false;

static void 
sig_handler(int sig){
  signaled = true;
}

void print_message_function(){
	//volatile int pkt_counter = 0;
	while(!signaled){
	/*		if(top_block->carrier_present()){
				printf("Freq. Offset: %f Hz  Timing Offset: %f ppm Estimated SNR: %f dB  BER: %f\n", top_block->frequency_offset(), top_block->timing_offset(), top_block->snr(), top_block->ber());
			}
			else{
				printf("Carrier not detected\n");
			}*/
			sleep(1);
	}
}

int main(int argc, char **argv){
	printf("Initilizing default values\n");
	//Default values.
	printf("Making top- block\n");
	rx_top_block = make_rx_top_block();
	
	printf("Install signal handler for SIGINT\n");
  struct sigaction action;
  memset(&action, 0, sizeof(action));
	
  action.sa_handler = sig_handler;
  sigemptyset(&action.sa_mask);
  action.sa_flags = 0;
	
  if(sigaction(SIGINT, &action, 0)<0){
		printf("Unable to install signal- handler!\n");
		return -1;
	}

	rx_top_block->start();

	boost::thread message_thread(&print_message_function);
	message_thread.join(); //wait for the message- thread to compleate, ie Ctrl+C.
	
	rx_top_block->stop();
	
	return 0;
}