#include <gr_squelch_base_cc.h>
#include <gr_io_signature.h>

gr_squelch_base_cc::gr_squelch_base_cc(const char *name, int ramp, bool gate) : 
	gr_block(name,
	         gr_make_io_signature(1, 1, sizeof(gr_complex)),
	         gr_make_io_signature(1, 1, sizeof(gr_complex)))
{

}

int gr_squelch_base_cc::general_work(int noutput_items,
				     gr_vector_int &ninput_items,
				     gr_vector_const_void_star &input_items,
				     gr_vector_void_star &output_items)
{
}
