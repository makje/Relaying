#ifndef INCLUDED_GR_SQUELCH_BASE_CC_H
#define INCLUDED_GR_SQUELCH_BASE_CC_H

#include <gr_block.h>

class gr_squelch_base_cc : public gr_block
{
private:
	double d_last_mean;
  enum { ST_HAVE_SIGNAL, ST_SEARCHING } d_state;

protected:
  //virtual void update_state(const gr_complex &sample) {};
  virtual bool mute() const { return false; };

public:
  gr_squelch_base_cc(const char *name, int ramp, bool gate);

  int ramp() const { return d_ramp; }
  void set_ramp(int ramp) { d_ramp = ramp; }
  bool gate() const { return d_gate; }
  void set_gate(bool gate) { d_gate = gate; }
  bool unmuted() const { return (d_state == ST_UNMUTED || d_state == ST_ATTACK); }

  virtual std::vector<float> squelch_range() const = 0;

  int general_work (int noutput_items,
		    gr_vector_int &ninput_items,
		    gr_vector_const_void_star &input_items,
		    gr_vector_void_star &output_items);
};

#endif /* INCLUDED_GR_SQUELCH_BASE_CC_H */
