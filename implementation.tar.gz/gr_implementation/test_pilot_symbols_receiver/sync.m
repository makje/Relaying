function [t_samp corr_vector] = sync(mf, b_train, Q, t_start, t_end)

%c = qpsk_modulate(b_train); %tafram tränings- symboler
c = zeros(size(b_train));
lc = length(b_train);
t = sqrt(2)/2;
for k=1:lc
    if b_train(k) == 0
        c(k) = -t+1j*t; 
    else
        if b_train(k) == 1
            c(k) = t+1j*t;
        else
            if b_train(k) == 2
                c(k) = -t-1j*t;
            else
                if b_train(k) == 3
                    c(k) = t-1j*t;
                end
            end
        end
    end
end

%% Tafram bästa sampel- punkt i intervallet [t_start, t_end].
tmp2 = zeros(t_end,1);
for t_s = t_start:t_end
    r = mf(t_s:Q:t_s+Q*(lc-1));
    tmp2(t_s) = abs( r*c' );
end
%figure();plot(tmp2);
%keayboard;
[dummy t_samp] = max(tmp2);
t_samp = t_samp-1;
corr_vector = tmp2;
