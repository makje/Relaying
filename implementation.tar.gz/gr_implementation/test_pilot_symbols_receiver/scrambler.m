function scrambled_bits = scrambler(x,N)
    scram_bits = zeros(1,N);
    %make first turn in the loop manualy...
    y = lfsr(x);
    scram_bits(1) = y.output;

    for k=2:N
        y = lfsr(y);
        scram_bits(k) = y.output;
    end
    scrambled_bits = scram_bits;
end