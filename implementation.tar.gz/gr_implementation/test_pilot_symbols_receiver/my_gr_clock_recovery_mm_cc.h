#include <gr_block.h>
#include <gr_complex.h>
#include <gr_math.h>
#include <gr_clock_recovery_mm_cc.h>

class my_gr_clock_recovery_mm_cc;
typedef boost::shared_ptr<my_gr_clock_recovery_mm_cc> my_gr_clock_recovery_mm_cc_sptr;

// public constructor
my_gr_clock_recovery_mm_cc_sptr 
gr_make_clock_recovery_mm_cc(float omega, float gain_omega, float mu, float gain_mu, float omega_relative_limit=0.001, int order = 4);

class my_gr_clock_recovery_mm_cc: private gr_clock_recovery_mm_cc{
public:
  ~my_gr_clock_recovery_mm_cc ();
	int general_work (int noutput_items,
		    gr_vector_int &ninput_items,
		    gr_vector_const_void_star &input_items,
		    gr_vector_void_star &output_items);
protected:
  my_gr_clock_recovery_mm_cc(float omega, float gain_omega, float mu, float gain_mu, float omega_relative_limit, int order);

 private:
  //gr_complex slicer_45deg (gr_complex sample);
  friend my_gr_clock_recovery_mm_cc_sptr
  my_gr_make_clock_recovery_mm_cc(float omega, float gain_omega, float mu, float gain_mu, float omega_relative_limit, int order);

	gr_complex (gr_clock_recovery_mm_cc::*d_slicer)(gr_complex sample) const;
};
