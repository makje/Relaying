path(path,'~/gnuradio/gnuradio-core/src/utils');
filename = 'tx_data.dat';
ampl = 16000;
N = 8e6;
fs= 8e6;
f = 1e6;

signal = ampl*exp(j*2*pi*(f/fs).*(1:N));


data = zeros(N*2,1);
counter = 1;
for k=1:N
    data(counter) = real(signal(k));
    data(counter+1)=imag(signal(k));
    counter = counter+2;
end

%plot(data(1:2:end)), hold on, plot(data(2:2:end),'r')

f = fopen (filename, 'wb');
v = fwrite(f, data, 'float');
fclose (f);
