#include "top_block.h"
#include <gruel/realtime.h>

using namespace std;

top_block_sptr make_top_block(){
	return gnuradio::get_initial_sptr(new top_block());
}

top_block::top_block():gr_top_block("pack_top_block"){
	d_tx = usrp_make_sink_c();

	d_rf_freq = 3e6;
	d_interp = 16;
	d_gain = 1;
  	int rt_ans = gruel::enable_realtime_scheduling();
	printf("Enabling realtime scheduling... ");
  	switch(rt_ans){
    		case gruel::RT_OK:
      			printf("OK\n");
      		break;
		case gruel::RT_NOT_IMPLEMENTED:
		      printf("Realtime scheduling not implemented\n");
	      	break;
    		case gruel::RT_NO_PRIVS:
      			printf("Insufficent Privlegies to implement realtime scheduling\n");
      		break;
    		case gruel::RT_OTHER_ERROR:
		      printf("Undetermined error returend from gruel::enable_realtime_scheduling()\n");
      		break;
  	}
	d_fs = gr_make_file_source(sizeof(gr_complex),"tx_data.dat",true);
	configure_usrp();
	connect(d_fs,0,d_tx,0);
}
void top_block::configure_usrp(){
	bool ok = false;
	printf("Setting interpolation rate to %d... ", d_interp);
	ok = d_tx->set_interp_rate(d_interp);
	ok?printf("ok\n"):printf("FAILED\n");

	usrp_subdev_spec usds = d_tx->pick_tx_subdevice();
	
	printf("Setting mux to 0x%0x... ", d_tx->determine_tx_mux_value(usds));
	ok = d_tx->set_mux(d_tx->determine_tx_mux_value(usds));
	ok?printf("ok\n"):printf("FAILED\n");

	d_db = d_tx->selected_subdev(usds);
	
	printf("Set enable true... ");	
	ok = d_db->set_enable(true);
	ok?printf("ok\n"):printf("FAILED\n");

	printf("Setting gain to %lf... ",int(d_gain));
	ok = d_db->set_gain(int(d_gain));
	ok?printf("ok\n"):printf("FAILED\n");

	printf("Setting nchannels to 1...");
	ok = d_tx->set_nchannels(1);
	ok?printf("ok\n"):printf("FAILED\n");
	
	usrp_tune_result tr;
	ok = d_tx->tune(d_db->which(), d_db, d_rf_freq, &tr);
	printf("Tune result:\n");
	printf("Baseband freq:\t\t%lf M\n",tr.baseband_freq/1e6);
	printf("DXC freq:\t\t%lf M\n",tr.dxc_freq/1e6);
	printf("Residual freq\t\t%lf M\n",tr.residual_freq/1e6);
	ok?printf("Tune ok\n"):printf("Tune failed\n");
}

top_block::~top_block(){
  printf("top_block destructor...\n");
}
