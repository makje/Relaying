#include <gr_top_block.h>

#include <usrp_sink_c.h>
#include <usrp_subdev_spec.h>

#include <gr_file_source.h>
class top_block;

typedef boost::shared_ptr<top_block> top_block_sptr;

top_block_sptr make_top_block();

class top_block:public gr_top_block{
	private:
		//VARIABLES
		int d_sps;
		float d_rrc_bw;
		float d_rrc_ampl;
		double d_rf_freq;
		int d_interp;
		double d_gain;
	
		gr_file_source_sptr	d_fs;		
		usrp_sink_c_sptr	d_tx;
		db_base_sptr		d_db;
		//HELPER FUNCTION
		void configure_usrp();
	public:
		top_block();
		friend top_block_sptr make_top_block();
		~top_block();
};
