//USRP TX COMPLEX FLOAT FILE

#include "top_block.h"
#include <signal.h>

static volatile bool signaled = false;

static void sig_handler(int sig){
  signaled = true;
}

int main(int argc, char **argv){
	printf("Setting up signal- handler\n");
	struct sigaction action;
	memset(&action, 0, sizeof(action));
	action.sa_handler = sig_handler;
	action.sa_flags = 0;
	if(sigaction(SIGINT, &action,0)<0){
	  printf("Unable to install signal- handler\n");
	  return -1;
	}

	printf("Making top- block\n");
	top_block_sptr top_block = make_top_block();
	top_block->start();
	while(!signaled){
		usleep(10);
	}
	top_block->stop();
	return 0;
}
