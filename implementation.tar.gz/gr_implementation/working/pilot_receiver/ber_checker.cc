#include "ber_checker.h"
#include <gr_io_signature.h>
#include <iostream>

using std::cout;
using std::endl;

ber_checker_sptr make_ber_checker(int degree, int mask, int seed){
  return ber_checker_sptr (new ber_checker(degree, mask, seed));
}

ber_checker::ber_checker(int degree, int mask, int seed)
  : gr_sync_block("ber_checker",
		   gr_make_io_signature(1, 1, sizeof(unsigned char)),
		   gr_make_io_signature(0, 0, 0)), d_ber(0.0){
  d_glfsr = new gri_glfsr(mask, seed);
	d_glfsr->glfsr_mask(degree);

}

ber_checker::~ber_checker(){
	delete d_glfsr;
}

int ber_checker::work(int noutput_items,
											gr_vector_const_void_star &input_items,
											gr_vector_void_star &output_items){
	char *inbuf = (char *) input_items[0];
	int  nwritten = 0;
	int sum = 0;
	while (nwritten < noutput_items){
		if(inbuf[nwritten]!=d_glfsr->next_bit()){
			sum++;
		}
		nwritten++;
	}
	d_ber = (d_ber + sum/noutput_items)/2;

	return nwritten;
}
