#include <gr_top_block.h>

//Receiving blocks
#include <usrp_source_c.h>

#include <gr_fir_filter_ccf.h>
#include <gr_firdes.h>
#include <gr_pwr_squelch_cc.h>
#include "header_correlator_cc.h"
#include "symbol_extractor_cc2.h"
#include "phase_corrector_cc.h"
#include <gr_constellation_decoder_cb.h>
#include <gr_unpack_k_bits_bb.h>
#include "ber_checker.h"

class pilot_receiver_top_block;

typedef boost::shared_ptr<pilot_receiver_top_block> pilot_receiver_top_block_sptr;

pilot_receiver_top_block_sptr make_pilot_receiver_top_block();

class pilot_receiver_top_block:public gr_top_block{
	private:
		//Misc parameters
		double d_rf_freq;
		int d_gain;
		long d_rate;
		float d_sps;
		long d_if_rate;
		
		//Parameters for usrp
		int d_rx_board;
		int d_rx_decimation_rate;
		int d_rx_channel;
		int d_rx_mux;

		//RRC- parameters
		float d_rrc_gain;
		float d_rrc_sps;
		float d_rrc_symbol_rate;
		float d_rrc_excess_bw;
		int d_rrc_ntaps;
		int d_rrc_decimation;

		usrp_source_c_sptr								d_rx;
		db_base_sptr 											d_db;
		
		gr_fir_filter_ccf_sptr						d_rrc_rx;
		gr_pwr_squelch_cc_sptr 						d_squelch;
		header_correlator_cc_sptr					d_header_correlator;
		symbol_extractor_cc_sptr					d_symbol_extractor;
		phase_corrector_cc_sptr 					d_phase_corrector;
		gr_constellation_decoder_cb_sptr 	d_demapper;
		gr_unpack_k_bits_bb_sptr 					d_unpacker;
		ber_checker_sptr 									d_ber;
		
		
		void configure_usrp();
	public:
		float ber(){ return d_ber->ber(); };
		pilot_receiver_top_block();
		friend pilot_receiver_top_block_sptr make_pilot_receiver_top_block();
		~pilot_receiver_top_block();
};