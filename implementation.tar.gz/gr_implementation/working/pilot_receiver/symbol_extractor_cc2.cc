/**
* This file is extended from symbol_extractor_cc
* It implements a form of early- late gate sampling
* to compensate for clock- drifts. As opposed to
* symbol_extractor_cc witch does not.
*/
#include "symbol_extractor_cc2.h"
#include <vector>
#include <gr_io_signature.h>

#include <iostream>
using std::cout;
using std::endl;

symbol_extractor_cc_sptr make_symbol_extractor_cc(int sps){
	return symbol_extractor_cc_sptr(new symbol_extractor_cc(sps));
}

symbol_extractor_cc::symbol_extractor_cc(int sps):gr_block("symbol_extractor_cc",
																							gr_make_io_signature (2, 2, sizeof(gr_complex)),
																							gr_make_io_signature (1, 1, sizeof(gr_complex))),
																							d_sps(sps), d_lsp(0),d_start_sample_at(-1),d_first_buffer(true){
}

int symbol_extractor_cc::general_work (int noutput_items,
																			gr_vector_int &ninput_items,
																			gr_vector_const_void_star &input_items,
																			gr_vector_void_star &output_items)
{
	const gr_complex *in = (const gr_complex *) input_items[0]; //signal from header_correlator_cc
	const gr_complex *hs = (const gr_complex *) input_items[1]; //"have signal" from header_correlator_cc
	gr_complex *out = (gr_complex *) output_items[0];

	
	/* Think this isn't needed... */
	if(d_lsp<0){ //make sure d_lsp is at least 1.
		d_lsp = 0;
	}
	/**/
	
	int counter = d_lsp;
	gr_complex early(0.0,0.0);
	gr_complex ontime(0.0,0.0);
	gr_complex late(0.0,0.0);

	float early_mean(0.0);
	float ontime_mean(0.0);
	float late_mean(0.0);

	float threashold = 15.0; //FIXME: Make dynamic...

	int out_counter = 0;
	int ni = ninput_items[0];
	bool state_change = false;
	
	while(counter < ni){
		if(real(hs[counter])>0.0){ //if header_sync has found a signal.
			if(d_first_buffer == true && d_start_sample_at == -1){ //get initial starting sample...
				d_start_sample_at = counter;
				d_first_buffer = false;
				state_change = true; //flag for later... initialized to false, so it will almost always be that. Except for the
														 //first buffer with a signal.
			}
			
			//sample
			if(counter>0){
				early = in[counter-1];
			}
			else{
				early = gr_complex(0.0,0.0);
			}
			
			ontime =	in[counter];
			
			if(counter<ni-1){
				late = in[counter+1];
			}
			else{
				late = gr_complex(0.0,0.0);
			}
			
			out[out_counter++] = ontime;
			counter +=d_sps;

			early_mean += abs(early);
			ontime_mean += abs(ontime);
			late_mean += abs(late);
			
		}
		else{ //if header_sync has not found a signal.
			counter++;
		}
	}

	if(out_counter>0){ //make shure we have something to count on... ie no division by zero...
		early_mean = early_mean / out_counter;
		ontime_mean = ontime_mean / out_counter;
		late_mean = late_mean / out_counter;
	}

	/**
	* Calculate where to start sample next buffer. It is dependent on the flags d_first_buffer
	* which is true until we see a signal on input[1], and bool state_change which is set if
	* d_first_buffer is set to true, which only occurs once.
	* The logic is "inverted", since we know that state_change will almost always be false, and
	* we don't need to jump in the code as often.
	*/
	if(!state_change){
		d_lsp = d_sps-(ni-(d_lsp+(out_counter-1)*d_sps));

		//Early- late- gate... 
		if(fabs(early_mean-late_mean)>threashold){ //If we have a deviation larger than threshold...
			if( (early_mean-late_mean) < 0 ){
				d_lsp++; //early-late < 0, move sample- point forward in time.
			}
			else{
				d_lsp--; //early-late > 0, move sample- point back in time
			}
		}// else, we don't whant to correct if we are under threshold.
	}
	else{
		d_lsp = d_sps-(ni-(d_start_sample_at+(out_counter-1)*d_sps));
	}
	consume_each(ni); //consume all inputs, that is, free the in- buffer of them.
	return out_counter; //report that we have created out_counter elements.
}