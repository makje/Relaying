#include "phase_corrector_cc.h"
#include <vector>
#include <gr_io_signature.h>
#include <iostream>
using std::cout;
using std::endl;

phase_corrector_cc_sptr make_phase_corrector_cc(){
	return phase_corrector_cc_sptr(new phase_corrector_cc());
}

phase_corrector_cc::phase_corrector_cc():gr_block("phase_corrector_cc",
																							gr_make_io_signature (1, 1, sizeof(gr_complex)),
																							gr_make_io_signature (1, 1, sizeof(gr_complex))),d_symbol_counter(0),
																							d_data_counter(0){
	d_header_length = 100; //FIXME
	gr_complex mod_hdr[] = {
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex(-0.7071, 0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex(-0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071, 0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071, 0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071)
	};
	std::vector<gr_complex> dmh(mod_hdr, mod_hdr+sizeof(mod_hdr)/sizeof(gr_complex));
	d_modulated_header = dmh;
	d_packet_length = 4100;
	d_pilot = gr_complex(-0.7071,0.7071);
	data_vec = std::vector<gr_complex>(4,gr_complex(0.0,0.0)); //FIXME:: STATIC 4
}

int phase_corrector_cc::sign(float f){
	int ret = 0;
	f>0?ret=1: ret= -1;
	return ret;
}

int phase_corrector_cc::general_work (int noutput_items,
																			gr_vector_int &ninput_items,
																			gr_vector_const_void_star &input_items,
																			gr_vector_void_star &output_items)
{
	const gr_complex *in = (const gr_complex *) input_items[0]; //signal from header_correlator_cc
	gr_complex *out = (gr_complex *) output_items[0];

	int ni = ninput_items[0];
	//int no = noutput_items;
	int in_counter = 0;
	int oo = 0;
	gr_complex h_hat(0.0,0.0);
	
	for(int i=0;i<ni;i++){
		if(d_symbol_counter<100){
			//header
		}
		else{
			//data
			if(d_symbol_counter>100 && (d_symbol_counter+1)%5==0){
				//pilot
				h_hat = in[i]/gr_complex(-0.7071,0.7071);
				//cout << "Pilot from: in[" << i << "] symbol_counter: " << d_symbol_counter << endl;
				out[oo]=data_vec[0]/h_hat;
				out[oo+1]=data_vec[1]/h_hat;
				out[oo+2]=data_vec[2]/h_hat;
				out[oo+3]=data_vec[3]/h_hat;
				oo+=4;
			}
			else{
				//regular data.
				data_vec[d_data_counter] = in[i];
				//cout << "Data from in[" << i << "] placed in data_vec[" << d_data_counter << "]" << endl;
				d_data_counter = (d_data_counter+1)%4; //bound it to [0:3].
			}
		}
		d_symbol_counter = (d_symbol_counter+1)%d_packet_length;
	}
	consume_each(ni); //consume all inputs, that is, free the in- buffer of them.
	return oo; //report that we have created out_counter elements.
}