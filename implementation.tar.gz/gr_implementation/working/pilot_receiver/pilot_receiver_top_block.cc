#include "pilot_receiver_top_block.h"
#include <gr_file_sink.h>
#include <gruel/realtime.h>
#include <vector>

using namespace std;

pilot_receiver_top_block_sptr make_pilot_receiver_top_block(){
	return gnuradio::get_initial_sptr(new pilot_receiver_top_block());
}

pilot_receiver_top_block::pilot_receiver_top_block():gr_top_block("pilot_receiver_top_block"){
	if(gruel::RT_OK == gruel::enable_realtime_scheduling()){
		printf("Enabled realtime scheduling\n");
	}
	else{
		printf("Failed to enable realtime scheduling\n");
	}

	d_rf_freq = 3e6;
	d_gain = 10;
	
	d_rate = 0.5e6;
	d_rx_decimation_rate = 16;
	d_rrc_excess_bw = 0.5;

	d_rx_channel = 1;
	d_rrc_gain = 1.0;
	d_rrc_symbol_rate = 1.0;
	d_rrc_decimation = 1;

	printf("Create usrp source\n");
	d_rx = usrp_make_source_c();

	d_if_rate = d_rx->adc_rate()/d_rx_decimation_rate;
	d_sps = d_if_rate/d_rate;
	printf("if_rate: %ld\n",d_if_rate);
	printf("Decimation: %d\n",d_rx_decimation_rate);
	printf("d_sps: %lf\n",d_sps);
	d_rx_decimation_rate = d_rx->adc_rate()/d_if_rate;

	printf("Creating receiver\n");
	float d_rrc_gain = 1.0;
	float d_rrc_symbol_rate = 1.0;
	float d_rrc_decimation = 1;
	printf("Creating MF\n");
	printf("Matched- filter gain:\t\t%f\n",d_rrc_gain);
	printf("Matched- filter sps:\t\t%f\n",d_sps);
	printf("Matched- filter symbol rate:\t%f\n",d_rrc_symbol_rate);
	printf("Matched- filter excess bw:\t%f\n",d_rrc_excess_bw);
	printf("Matched- filter nr taps:\t%d\n",int(11*d_sps));

	std::vector<float> rrc_taps = gr_firdes::root_raised_cosine(d_rrc_gain,
								d_sps,
								d_rrc_symbol_rate,
								d_rrc_excess_bw,
								int(11*d_sps));

	d_rrc_rx = gr_make_fir_filter_ccf(d_rrc_decimation,rrc_taps);
		
	printf("Configure USRP\n");
	configure_usrp();

	d_rrc_rx = gr_make_fir_filter_ccf(d_rrc_decimation,rrc_taps);

	printf("Creating powersquelch\n");
	d_squelch = gr_make_pwr_squelch_cc (10.0, 1, 0, 0); //second parameter??

	printf("Creating header correlator\n");
	d_header_correlator = make_header_correlator_cc();

	printf("Creating symbol- sampler\n");
	d_symbol_extractor = make_symbol_extractor_cc(d_sps);

	printf("Creating phase- corrector and pilot/header stripper\n");
	d_phase_corrector = make_phase_corrector_cc();
	
	printf("Creating constellation decoder\n");
	printf("Creating constellation\n");
	float t2 = sqrt(2)/2;
	gr_complex c2[] = {
		gr_complex(-t2, t2), gr_complex(t2, t2),
		gr_complex(-t2,-t2), gr_complex(t2,-t2)
	};
	std::vector<gr_complex> constellation2(c2, c2+sizeof(c2)/sizeof(gr_complex));
	unsigned char b2[] = {
		0x00, 0x01,
		0x02, 0x03
	};
	std::vector<unsigned char> sym_values(b2, b2+sizeof(b2)/sizeof(unsigned char));
	d_demapper = gr_make_constellation_decoder_cb(constellation2, sym_values);

	printf("Make bit unpacker, 2bits per byte, to 2 bytes with 1 bit per byte\n");
	d_unpacker = gr_make_unpack_k_bits_bb(2);

	printf("Make BER- messurer\n");
	d_ber = make_ber_checker(15, 0x0a32, 0xFFFFFF);
	//d_glfsr = gr_make_glfsr_source_b (15, false, 0x0a32, 0xFFFF);

	printf("Connecting receiver:");
	connect(d_rx,	0, d_rrc_rx, 0); printf(".");
	connect(d_rrc_rx, 0, d_squelch, 0); printf(".");
	connect(d_squelch,0, d_header_correlator,0); printf(".");
	connect(d_header_correlator, 0, d_symbol_extractor, 0); printf(".");
	connect(d_header_correlator, 1, d_symbol_extractor, 1); printf(".");
	connect(d_symbol_extractor, 0, d_phase_corrector, 0); printf(".");
	connect(d_phase_corrector, 0, d_demapper, 0); printf(".");
	connect(d_demapper,0 ,d_unpacker, 0);
	connect(d_unpacker,0 , d_ber, 0);
	printf("Done\n");

}

void pilot_receiver_top_block::configure_usrp(){
	d_rx->set_decim_rate(d_rx_decimation_rate);
	usrp_subdev_spec usds = d_rx->pick_rx_subdevice();
	d_rx->set_mux(d_rx->determine_rx_mux_value(usds));
	d_db = d_rx->selected_subdev(usds);
	d_db->set_enable(true);
	d_db->set_gain(10);
	d_rx->set_nchannels(1);
	
	usrp_tune_result result;
	d_rx->tune(d_db->which(), d_db, d_rf_freq, &result);
	printf("Tune result:\n");
	printf("Baseband freq:\t\t%lf\n",result.baseband_freq);
	printf("DXC freq:\t\t%lf\n",result.dxc_freq);
	printf("Resudal freq:\t\t%lf\n",result.residual_freq);
	printf("Spectrum inverted:\t");
	result.inverted?printf("Yes\n"):printf("No\n");
	return;
}

pilot_receiver_top_block::~pilot_receiver_top_block(){
  printf("top_block destructor\n");
}
