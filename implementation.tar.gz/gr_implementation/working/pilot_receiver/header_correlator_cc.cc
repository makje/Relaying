/* -*- c++ -*- */
/* Code is based on gpl:ed code from gnuRadio.
 */

#include "header_correlator_cc.h"
#include <gr_io_signature.h>
#include <vector>

#include <iostream>
using std::cout;
using std::endl;

using namespace std;
header_correlator_cc_sptr make_header_correlator_cc(){
  return header_correlator_cc_sptr (new header_correlator_cc());
}

header_correlator_cc::header_correlator_cc():gr_sync_block("header_correlator_cc",
																							gr_make_io_signature (1, 1, sizeof(gr_complex)),
																							gr_make_io_signature (2, 2, sizeof(gr_complex))){
  d_len = 100; //FIXME
	gr_complex mod_hdr[] = {
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex(-0.7071, 0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex(-0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071, 0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071, 0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex(-0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex(-0.7071, 0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071, 0.7071),
		gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex( 0.7071, 0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071,-0.7071), gr_complex( 0.7071,-0.7071),
		gr_complex( 0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex(-0.7071,-0.7071), gr_complex( 0.7071, 0.7071)
	}; //FIXME
	std::vector<gr_complex> dmh(mod_hdr, mod_hdr+sizeof(mod_hdr)/sizeof(gr_complex)); //FIXME
	d_modulated_header = dmh; //FIXME
  d_pn = d_modulated_header[0];
	d_bit_counter = 0;
	d_is_synced = false;
}

header_correlator_cc::~header_correlator_cc(){
	//Might need it later...
}

int
header_correlator_cc::work(int noutput_items,
			  gr_vector_const_void_star &input_items,
			  gr_vector_void_star &output_items)
{
	const gr_complex *in = (const gr_complex *) input_items[0];
	gr_complex *out = (gr_complex *) output_items[0]; //output signal.
	gr_complex *hs = (gr_complex *) output_items[1]; //gate, have or have no signal

	double sum = 0.0;
	int k=0;
	while(!d_is_synced && k<noutput_items){
		for(int l=k;( l< (k+800) ) && ( l<noutput_items ); l++){
			sum+=abs(in[l]*conj(d_pn));
			d_pn = d_modulated_header[++d_bit_counter%d_len];
		}
		if(sum>=10000.0){
			d_is_synced = true;
			out[k] = in[k];
			hs[k] = gr_complex(1.0,0.0);
		}else{
			out[k] = in[k];
			hs[k] = gr_complex(0.0,0.0);
		}
		k++;
	}
	while(d_is_synced && k<noutput_items){
		out[k] = in[k];
		hs[k] = gr_complex(1.0,0.0);
		k++;
	}
  return noutput_items;
}
