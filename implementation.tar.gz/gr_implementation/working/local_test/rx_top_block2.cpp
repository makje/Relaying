#include "rx_top_block2.h"
#include <gr_file_sink.h>
#include <gruel/realtime.h>
#include <vector>

using namespace std;

top_block_sptr make_top_block(){
	return gnuradio::get_initial_sptr(new top_block());
}

top_block::top_block():gr_top_block("pack_top_block"){
	//d_tx = usrp_make_sink_c();
	
	long rate = 1e6;
	d_sps = 8;
	d_rrc_bw = 0.5;
	d_rrc_ampl = .1e3;
	d_rf_freq = 3e6;
	d_interp = 128e6/(rate*d_sps);
	//d_interp = d_tx->dac_rate()/(rate*d_sps); // rate*sps = if- rate.
	printf("IF- rate: %ld\n",(rate*d_sps));
  int rt_ans = gruel::enable_realtime_scheduling();
  printf("Enabling realtime scheduling... ");
  switch(rt_ans){
    case gruel::RT_OK:
      printf("OK\n");
      break;
    case gruel::RT_NOT_IMPLEMENTED:
      printf("Realtime scheduling not implemented\n");
      break;
    case gruel::RT_NO_PRIVS:
      printf("Insufficent Privlegies to implement realtime scheduling\n");
      break;
    case gruel::RT_OTHER_ERROR:
      printf("Undetermined error returend from gruel::enable_realtime_scheduling()\n");
      break;
  }
  
	//Create vector source
	printf("creating vectors\n");
	unsigned char header[] = {2,0,1,3,2,3,0,0,3,0,2,1,3,2,1,3,3,2,2,2,
														2,3,0,1,1,3,1,2,1,0,1,0,1,2,1,2,3,2,3,1,
														2,2,1,0,2,2,2,0,1,2,3,2,2,2,1,1,2,3,1,2,
														3,3,1,2,1,2,1,3,2,2,3,1,1,1,1,2,3,3,0,3,
														3,1,1,1,2,2,3,1,2,2,2,3,1,3,3,3,3,2,2,1};
	std::vector<unsigned char> source_train_b(2);
	std::vector<unsigned char> packet_header_b(header,header+sizeof(header)/sizeof(unsigned char));
	source_train_b[0]= 0;
	source_train_b[1]= 0;

	printf("creating bit- sources\n");
	d_bits_train = gr_make_vector_source_b(source_train_b, true);
	d_bits_header= gr_make_vector_source_b(packet_header_b,true);
	
	printf("Creating glfsr\n");
	d_glfsr = gr_make_glfsr_source_b (15, false, 0x0a32, 0xFFFF);
	
	//Pack 1 bit for every byte into 2 bits for every byte.
	printf("Creating packers\n");
	d_data_packer = gr_make_pack_k_bits_bb(2); //pack 'data'
	d_train_packer = gr_make_pack_k_bits_bb(2); //pack pilots

	printf("Creating stream- muxers\n");
	std::vector<int> ml1(2); printf(".");
	ml1[0] = 4; printf(".");
	ml1[1] = 1; printf(".");
	d_stream_muxer = gr_make_stream_mux(sizeof(unsigned char), ml1); printf(".");
	std::vector<int> ml2(2); printf(",");
	ml2[0] = 100; printf(",");
	ml2[1] = 4000; printf(",");
	d_header_muxer = gr_make_stream_mux(sizeof(unsigned char), ml2); printf(",\n");

	printf("Creating constellation\n");
	float t = sqrt(2)/2;
	gr_complex c[] = {
		gr_complex(-t, t), gr_complex(t, t),
		gr_complex(-t,-t), gr_complex(t,-t)
	};

	std::vector<gr_complex> constellation(c, c+sizeof(c)/sizeof(gr_complex));
	d_mapper = gr_make_chunks_to_symbols_bc(constellation);

	printf("Creating rrc\n");
	std::vector<float> tx_taps = gr_firdes::root_raised_cosine(d_rrc_ampl*d_sps,d_sps,1.0,d_rrc_bw,11*d_sps);
	d_rrc_tx = gr_make_interp_fir_filter_ccf(d_sps,tx_taps);
	
	//configure_usrp();
	printf("Creating file sinks\n");
	gr_file_sink_sptr header_muxed = gr_make_file_sink(sizeof(char), "header_muxed.dat");
	gr_file_sink_sptr train_muxed = gr_make_file_sink(sizeof(char),"train_muxed.dat");
	gr_file_sink_sptr glfsr = gr_make_file_sink(sizeof(char),"glfsr.dat");
	gr_file_sink_sptr glfsr_packed = gr_make_file_sink(sizeof(char),"glfsr_packed.dat");
	gr_file_sink_sptr mapped = gr_make_file_sink(sizeof(gr_complex), "mapped.dat");
	gr_file_sink_sptr rx = gr_make_file_sink(sizeof(gr_complex), "rx.dat");
	printf("Connecting blocks\n");

	printf("Connecting transmitter:");
//Transmitter
	connect(d_glfsr,				0, d_data_packer,0); printf(".");
	connect(d_data_packer,	0, d_stream_muxer, 0); printf(".");
	
	connect(d_bits_train,		0, d_train_packer, 0); printf(".");
	connect(d_train_packer,	0, d_stream_muxer, 1); printf(".");
	
	connect(d_bits_header,	0, d_header_muxer,0); printf(".");
	connect(d_stream_muxer,	0, d_header_muxer,1); printf(".");
	
	connect(d_header_muxer,	0, d_mapper, 0); printf(".");
	connect(d_mapper,				0, d_rrc_tx, 0); printf(".");
	printf("Done\n");
// channel

	int delay = rand() % 500 + 1000;
	std::cout << "Channel delay: " << delay << std::endl;
	d_delay = gr_make_delay (sizeof(gr_complex), delay);
	
	double	noise_voltage = 10e-6;
	double  frequency_offset = 4e-3;
	double  epsilon = .001;
	gr_complex tps[] = {gr_complex(0.5,0.5), gr_complex(1.0, 1.0), gr_complex(0.5,0.5)};
	std::vector< gr_complex > taps(tps,tps+sizeof(tps)/sizeof(gr_complex));
	double  noise_seed = 3131.0;
	d_channel = gr_make_channel_model(noise_voltage,
									  frequency_offset,
									  epsilon,
									  taps,
									  noise_seed
									);

	if(0){
		connect(d_rrc_tx, 0, d_channel, 0);
		connect(d_channel, 0, d_delay, 0);
	}
	else{
		connect(d_rrc_tx,0,d_delay,0);
	}



// Receiver
	printf("Creating receiver\n");
	float d_rrc_gain = 1.0;
	float d_rrc_symbol_rate = 1.0;
	float d_rrc_decimation = 1;
	printf("Creating MF\n");
	printf("Matched- filter gain:\t\t%f\n",d_rrc_gain);
	printf("Matched- filter sps:\t\t%d\n",d_sps);
	printf("Matched- filter symbol rate:\t%f\n",d_rrc_symbol_rate);
	printf("Matched- filter excess bw:\t%f\n",d_rrc_bw);
	printf("Matched- filter nr taps:\t%d\n",int(11*d_sps));

	std::vector<float> rrc_taps = gr_firdes::root_raised_cosine(d_rrc_gain,
								d_sps,
								d_rrc_symbol_rate,
								d_rrc_bw,
								int(11*d_sps));

	d_rrc_rx = gr_make_fir_filter_ccf(d_rrc_decimation,rrc_taps);

	printf("Creating powersquelch\n");
	d_squelch = gr_make_pwr_squelch_cc (10.0, 1, 0, 0); //second parameter??

	printf("Creating header correlator\n");
	d_header_correlator = make_header_correlator_cc();

	printf("Creating symbol- sampler\n");
	d_symbol_extractor = make_symbol_extractor_cc(d_sps);

	printf("Creating phase- corrector and pilot/header stripper\n");
	d_phase_corrector = make_phase_corrector_cc();
	
	printf("Creating constellation decoder\n");
	printf("Creating constellation\n");
	float t2 = sqrt(2)/2;
	gr_complex c2[] = {
		gr_complex(-t2, t2), gr_complex(t2, t2),
		gr_complex(-t2,-t2), gr_complex(t2,-t2)
	};
	std::vector<gr_complex> constellation2(c2, c2+sizeof(c2)/sizeof(gr_complex));
	unsigned char b2[] = {
		0x00, 0x01,
		0x02, 0x03
	};
	std::vector<unsigned char> sym_values(b2, b2+sizeof(b2)/sizeof(unsigned char));
	d_demapper = gr_make_constellation_decoder_cb(constellation2, sym_values);

	printf("Make bit unpacker, 2bits per byte, to 2 bytes with 1 bit per byte\n");
	d_unpacker = gr_make_unpack_k_bits_bb(2);

	printf("Make BER- messurer\n");
	d_ber = make_ber_checker(15, 0x0a32, 0xFFFFFF);
	//d_glfsr = gr_make_glfsr_source_b (15, false, 0x0a32, 0xFFFF);

	printf("Connecting receiver:");
	connect(d_delay,	0, d_rrc_rx, 0); printf(".");
	connect(d_rrc_rx, 0, d_squelch, 0); printf(".");
	connect(d_squelch,0, d_header_correlator,0); printf(".");
	connect(d_header_correlator, 0, d_symbol_extractor, 0); printf(".");
	connect(d_header_correlator, 1, d_symbol_extractor, 1); printf(".");
	connect(d_symbol_extractor, 0, d_phase_corrector, 0); printf(".");
	connect(d_phase_corrector, 0, d_demapper, 0); printf(".");
	connect(d_demapper,0 ,d_unpacker, 0);
	connect(d_unpacker,0 , d_ber, 0);
	printf("Done\n");

	gr_file_sink_sptr squelch_sink = gr_make_file_sink(sizeof(gr_complex), "squelched.dat");
	gr_file_sink_sptr hdr_corr_signal_output = gr_make_file_sink(sizeof(gr_complex), "hdr_corr_signal.dat");
	gr_file_sink_sptr hdr_corr_sum_output = gr_make_file_sink(sizeof(gr_complex), "hdr_corr_gate.dat");
	gr_file_sink_sptr hdr_cor_sum_signal = gr_make_file_sink(sizeof(gr_complex), "hdr_corr_sum.dat");
	gr_file_sink_sptr symbol_sink = gr_make_file_sink(sizeof(gr_complex),"extracted_symbols.dat");
	gr_file_sink_sptr corrected_data_symbols = gr_make_file_sink(sizeof(gr_complex), "corrected_data_symbols.dat");
	gr_file_sink_sptr demodulated_symbols_sink = gr_make_file_sink(sizeof(unsigned char), "demodulated_symbols.dat");
	gr_file_sink_sptr received_bits = gr_make_file_sink(sizeof(unsigned char), "received_bits.dat");

	printf("Connecting file sinks:");
	
	connect(d_header_muxer,	0, header_muxed,0); printf(".");
	connect(d_stream_muxer,	0, train_muxed,0); printf(".");
	connect(d_glfsr,				0, glfsr,0); printf(".");
	connect(d_data_packer,	0, glfsr_packed,0); printf(".");
	connect(d_mapper,				0, mapped,0); printf(".");
	connect(d_rrc_rx,				0, rx,0); printf(".");
	connect(d_squelch,			0, squelch_sink,0); printf(".");
 	connect(d_header_correlator, 0, hdr_corr_signal_output,0); printf(".");
	connect(d_header_correlator, 1, hdr_corr_sum_output,0); printf(".");
	connect(d_header_correlator, 2, hdr_cor_sum_signal, 0); printf(".");
	connect(d_symbol_extractor, 0, symbol_sink, 0); printf(".");
	connect(d_phase_corrector, 0, corrected_data_symbols,0); printf(".");
	connect(d_demapper,0 , demodulated_symbols_sink, 0); printf(".");
	connect(d_unpacker,0 , received_bits, 0); printf(".");
	
	printf("Done\n");
		
//rrc_taps;
//tx_taps; 
	printf("rx_taps = [");
	for(int i=0;i<rrc_taps.size();i++)
		printf(", %f", rrc_taps[i]);
	printf("]");
	
	printf("\ntx_taps = [");
	for(int i=0;i<rrc_taps.size();i++)
		printf(", %f", tx_taps[i]);
	printf("]");
}
void top_block::configure_usrp(){
	/*
	bool ok = false;
	printf("Setting interpolation rate to %d... ", d_interp);
	ok = d_tx->set_interp_rate(d_interp);
	ok?printf("ok\n"):printf("FAILED\n");

	usrp_subdev_spec usds = d_tx->pick_tx_subdevice();
	
	printf("Setting mux to 0x%0x... ", d_tx->determine_tx_mux_value(usds));
	ok = d_tx->set_mux(d_tx->determine_tx_mux_value(usds));
	ok?printf("ok\n"):printf("FAILED\n");

	d_db = d_tx->selected_subdev(usds);
	
	printf("Set enable true... ");	
	ok = d_db->set_enable(true);
	ok?printf("ok\n"):printf("FAILED\n");

	printf("Setting gain to 40... ");
	ok = d_db->set_gain(40);
	ok?printf("ok\n"):printf("FAILED\n");

	printf("Setting nchannels to 1...");
	ok = d_tx->set_nchannels(1);
	ok?printf("ok\n"):printf("FAILED\n");
	
	usrp_tune_result tr;
	ok = d_tx->tune(d_db->which(), d_db, d_rf_freq, &tr);
	printf("Tune result:\n");
	printf("Baseband freq:\t\t%lf M\n",tr.baseband_freq/1e6);
	printf("DXC freq:\t\t%lf M\n",tr.dxc_freq/1e6);
	printf("Residual freq\t\t%lf M\n",tr.residual_freq/1e6);
	ok?printf("Tune ok\n"):printf("Tune failed\n");*/
}

top_block::~top_block(){
  printf("top_block destructor\n");
}
