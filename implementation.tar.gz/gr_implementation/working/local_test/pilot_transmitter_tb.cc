#include "pilot_transmitter_tb.h"
#include <gr_file_sink.h>
#include <gruel/realtime.h>
#include <vector>

using namespace std;

pilot_transmitter_tb_sptr make_pilot_transmitter_tb(){
	return gnuradio::get_initial_sptr(new pilot_transmitter_tb());
}

pilot_transmitter_tb::pilot_transmitter_tb():gr_top_block("pilot_transmitter_tb"){
	d_tx = usrp_make_sink_c();
	
	long rate = 1e6;
	d_sps = 8;
	d_rrc_bw = 0.5;
	d_rrc_ampl = 10e3;
	d_rf_freq = 3e6;
	//d_interp = 128e6/(rate*d_sps);
	d_interp = d_tx->dac_rate()/(rate*d_sps); // rate*sps = if- rate.
	printf("IF- rate: %ld\n",(rate*d_sps));
  int rt_ans = gruel::enable_realtime_scheduling();
  printf("Enabling realtime scheduling... ");
  switch(rt_ans){
    case gruel::RT_OK:
      printf("OK\n");
      break;
    case gruel::RT_NOT_IMPLEMENTED:
      printf("Realtime scheduling not implemented\n");
      break;
    case gruel::RT_NO_PRIVS:
      printf("Insufficent Privlegies to implement realtime scheduling\n");
      break;
    case gruel::RT_OTHER_ERROR:
      printf("Undetermined error returend from gruel::enable_realtime_scheduling()\n");
      break;
  }
  
	//Create vector source
	printf("creating vectors\n");
	unsigned char header[] = {2,0,1,3,2,3,0,0,3,0,2,1,3,2,1,3,3,2,2,2,
														2,3,0,1,1,3,1,2,1,0,1,0,1,2,1,2,3,2,3,1,
														2,2,1,0,2,2,2,0,1,2,3,2,2,2,1,1,2,3,1,2,
														3,3,1,2,1,2,1,3,2,2,3,1,1,1,1,2,3,3,0,3,
														3,1,1,1,2,2,3,1,2,2,2,3,1,3,3,3,3,2,2,1};
	std::vector<unsigned char> source_train_b(2);
	std::vector<unsigned char> packet_header_b(header,header+sizeof(header)/sizeof(unsigned char));
	source_train_b[0]= 0;
	source_train_b[1]= 0;

	printf("creating bit- sources\n");
	d_bits_train = gr_make_vector_source_b(source_train_b, true);
	d_bits_header= gr_make_vector_source_b(packet_header_b,true);
	
	printf("Creating glfsr\n");
	d_glfsr = gr_make_glfsr_source_b (15, true, 0x0a32, 0xFFFF);
	
	//Pack 1 bit for every byte into 2 bits for every byte.
	printf("Creating packers\n");
	d_data_packer = gr_make_pack_k_bits_bb(2); //pack 'data'
	d_train_packer = gr_make_pack_k_bits_bb(2); //pack pilots

	printf("Creating stream- muxers\n");
	std::vector<int> ml1(2); printf(".");
	ml1[0] = 4; printf(".");
	ml1[1] = 1; printf(".");
	d_stream_muxer = gr_make_stream_mux(sizeof(unsigned char), ml1); printf(".");
	std::vector<int> ml2(2); printf(",");
	ml2[0] = 100; printf(",");
	ml2[1] = 4000; printf(",");
	d_header_muxer = gr_make_stream_mux(sizeof(unsigned char), ml2); printf(",\n");

	printf("Creating constellation\n");
	float t = sqrt(2)/2;
	gr_complex c[] = {
		gr_complex(-t, t), gr_complex(t, t),
		gr_complex(-t,-t), gr_complex(t,-t)
	};

	std::vector<gr_complex> constellation(c, c+sizeof(c)/sizeof(gr_complex));
	d_mapper = gr_make_chunks_to_symbols_bc(constellation);

	printf("Creating rrc\n");
	std::vector<float> tx_taps = gr_firdes::root_raised_cosine(d_rrc_ampl*d_sps,d_sps,1.0,d_rrc_bw,11*d_sps);
	d_rrc_tx = gr_make_interp_fir_filter_ccf(d_sps,tx_taps);
	
	configure_usrp();
	printf("Connecting transmitter:");
	connect(d_glfsr,				0, d_data_packer,0); printf(".");
	connect(d_data_packer,	0, d_stream_muxer, 0); printf(".");

	connect(d_bits_train,		0, d_train_packer, 0); printf(".");
	connect(d_train_packer,	0, d_stream_muxer, 1); printf(".");
	
	connect(d_bits_header,	0, d_header_muxer,0); printf(".");
	connect(d_stream_muxer,	0, d_header_muxer,1); printf(".");
	
	connect(d_header_muxer,	0, d_mapper, 0); printf(".");
	connect(d_mapper,				0, d_rrc_tx, 0); printf(".");
	connect(d_rrc_tx,				0, d_tx, 0); printf(".");
	printf("Done\n");
}
void pilot_transmitter_tb::configure_usrp(){
	bool ok = false;
	printf("Setting interpolation rate to %d... ", d_interp);
	ok = d_tx->set_interp_rate(d_interp);
	ok?printf("ok\n"):printf("FAILED\n");

	usrp_subdev_spec usds = d_tx->pick_tx_subdevice();
	
	printf("Setting mux to 0x%0x... ", d_tx->determine_tx_mux_value(usds));
	ok = d_tx->set_mux(d_tx->determine_tx_mux_value(usds));
	ok?printf("ok\n"):printf("FAILED\n");

	d_db = d_tx->selected_subdev(usds);
	
	printf("Set enable true... ");	
	ok = d_db->set_enable(true);
	ok?printf("ok\n"):printf("FAILED\n");

	printf("Setting gain to 10... ");
	ok = d_db->set_gain(10);
	ok?printf("ok\n"):printf("FAILED\n");

	printf("Setting nchannels to 1...");
	ok = d_tx->set_nchannels(1);
	ok?printf("ok\n"):printf("FAILED\n");
	
	usrp_tune_result tr;
	ok = d_tx->tune(d_db->which(), d_db, d_rf_freq, &tr);
	printf("Tune result:\n");
	printf("Baseband freq:\t\t%lf M\n",tr.baseband_freq/1e6);
	printf("DXC freq:\t\t%lf M\n",tr.dxc_freq/1e6);
	printf("Residual freq\t\t%lf M\n",tr.residual_freq/1e6);
	ok?printf("Tune ok\n"):printf("Tune failed\n");
}

pilot_transmitter_tb::~pilot_transmitter_tb(){
  printf("pilot_transmitter_tb destructor\n");
}
