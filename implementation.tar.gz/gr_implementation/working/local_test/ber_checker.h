#ifndef INCLUDED_BER_CHECKER_H
#define	INCLUDED_BER_CHECKER_H

#include <gr_sync_block.h>
#include <gri_glfsr.h>
class ber_checker;

typedef boost::shared_ptr<ber_checker> ber_checker_sptr;

ber_checker_sptr make_ber_checker(int degree, int mask, int seed);

class ber_checker : public gr_sync_block{
 private:
  friend ber_checker_sptr make_ber_checker(int degree, int mask, int seed);
  ber_checker(int degree, int mask, int seed);
	float d_ber;
	gri_glfsr *d_glfsr;

 public:
	float ber(){ return d_ber; };
  ~ber_checker();
  int work(int noutput_items,
	   gr_vector_const_void_star &input_items,
	   gr_vector_void_star &output_items);
};
#endif
