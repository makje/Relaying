function Berrors=CalculateBER(information_hat,information,Nbits)


temp=information(:)';
temp_hat=information_hat(:)';



Berrors=zeros(length(temp),Nbits);

for bit_i=(Nbits-1):-1:0
   weigth=2^bit_i;
   bit=(temp>=weigth);
   bit_hat=(temp_hat>=weigth);
   Berrors(:,bit_i+1)=(~(bit==bit_hat))';
   temp=temp-bit*weigth;
   temp_hat=temp_hat-bit_hat*weigth;
end;
