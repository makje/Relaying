%% Make shure that all files and varables needed exist.
variables_to_check ={'frameDef','gain','pause_def','RF_freq', ...
                     'number_of_samples'};
variables_to_get = {};
files_to_check = {'nodeInit', 'transmit_single_antenna', ...
                  'receive_single_antenna', 'NodeProcess', ...
                  'single_antenna', 'ofdm_param'};
files_to_get = {};
for i1=1:length(variables_to_check)
    if(exist(cell2mat(variables_to_check(i1)),'var')==0)
        disp(['Variable ' cell2mat(variables_to_check(i1)) ' does not exist!'])
        variables_to_get = {variables_to_get, variables_to_check(i1)}; %#ok<AGROW>
    end
end

for i1=1:length(files_to_check)
    if(exist(cell2mat(files_to_check(i1)),'file')==0)
        disp(['File ' cell2mat(files_to_check(i1)) ' does not exist!']);
        files_to_get = {files_to_get, files_to_check(i1)}; %#ok<AGROW>
    end
end
respond = 0;
if(isempty(files_to_get) == 1)
   disp('All files needed to run client relay exist.');
   respond = 1;
else
    disp('All files needed to run client relay does NOT exist');
    respond = 3;
end
if(isempty(variables_to_get) == 1)
    disp('All variables needed to run client relay exist');
    respond = respond + 5;
else
    disp('All variables needed to run client relay does NOT exist');
    respond = respond + 9;
end
mssend(sock, respond); 
if(respond ~=6)
    disp('Quit client_relay.m');
    return;
end
%Respond == 6: All okay 
%Respond == 8: Files missing
%Respond == 10: Variables missing
%Respond == 12: Files and varaibles missing.
s = nodeInit();
%% Client
while(1)
    disp('Waiting for command in client_relay');
    client_relay_command = msrecv(sock);
    
    switch client_relay_command
        case 1
            disp '1~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+';
            disp '| Master toled me to START TX |';
            disp '+~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+';
            slot_ix = msrecv(sock);
            disp(['slot_ix=' num2str(slot_ix) ]);
            %check to see if X is defined. If it is not, define.
            if(exist('X','var') == 0)
                X = [];
            end
            [x_t s] = NodeProcess(node_ix,slot_ix,frameDef,s,X);
            transmit_single_antenna(RF_freq, gain, x_t);
            pause(pause_def);
            disp 'Send ACK of START TX';
            mssend(sock,1);
            disp 'start TX ACK sent';
        case 2
            disp '2~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+';
            disp '|  Master toled me to STOP TX |';
            disp '+~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+';
            disp 'EXECUTE killall single_antenna';
            ret = unix('sudo killall single_antenna');
            
            if(ret~=0)
                disp('>>>  ERROR executing killall single_antenna  <<<');

            end
            disp 'Send ACK of STOP TX';
            mssend(sock, 2);
            disp 'stop TX ACK sent';
            
        case 3
            disp '3~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+';
            disp '| Master told me to START RX  |';
            disp '+~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+';
            slot_ix=msrecv(sock);
            disp(['slot_ix=' num2str(slot_ix) ]);
            disp(['EXECUTE X=receive_single_antenna(' num2str(number_of_samples) ', ' num2str(RF_freq) ', ' num2str(gain) ')']);
            X=receive_single_antenna(number_of_samples,RF_freq,gain);
            disp 'Run NodeProcess';
            %[x_t s] = NodeProcess(NODE,slot_ix,frameDef,s,X);
            [x_t s] = NodeProcess(node_ix,slot_ix,frameDef,s,X);

            disp 'Send PROCESS DATA DONE';
            mssend(sock, 4);
            disp 'PROCESS DATA DONE sent';
            
        case 99
            disp '99~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+';
            disp '| Master toled me that the transmission is over |';
            disp '+~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+';
            break;
    end
end
