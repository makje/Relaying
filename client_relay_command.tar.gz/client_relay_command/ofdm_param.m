Nc = 32; %%Number of subcarriers.
Np=6; %% Length of cyclic-prefix
Ns=7; %% Number of symbols on burst
M=4; %% Constellation size
B=20; %% Number of bursts
L=512; %% Spacing between bursts

Fs=8e6;

A0=16000; %% Amplitude training sequence


if (M==4) 
  A1=16000*4; %% Amplitude data
elseif (M==16)
    %A1 = 8000; % BER: 7-8% GAIN= 20
    %A1 = 16000; % BER: ~1% GAIN= 20
    A1 = 16000*2; %BER: <1% GAIN= 20
elseif(M==64)
    %A1 = 4000; %BER: ~22%, GAIN= 20
    %A1 = 8000; %BER: 6-7%, GAIN= 20
    A1 = 16000; %BER: 4-5%, GAIN= 20
else
    A1 = 8000;
end;
train2=[1,1,-1,1,1,1,1,-1,1,1,1,-1,1,1,1,-1,-1,-1,1,1,1,1,...
    -1,-1,-1,-1,-1,1,-1,-1,1,-1,1,1,-1,1,1,1,-1,1,1,1,1,-1,-1,-1,...
    -1,1,1,1,1,1,1,-1,-1,-1,1,1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,1,...
    1,1,1,-1,1,-1,-1,-1,-1,1,1,-1,1,-1,-1,-1,1,1,-1,1,-1,-1,-1,...
    -1,1,1,-1,-1,1,-1,1,-1,1,1,1,1,1,-1,1,1,1,-1,1,-1,-1,1,-1,-1,...
    1,1,-1,1,1,1,1,1,1,-1,1,-1,-1,-1,1,-1,-1,1,-1,1];

train=[train2,train2];

%%Filter the training sequence
Fpass = 2.3e6;    % Passband Frequency
Fstop = 2.4e6;  % Stopband Frequency
Apass = 1;      % Passband Ripple (dB)
Astop = 80;     % Stopband Attenuation (dB)
h = fdesign.lowpass('fp,fst,ap,ast', Fpass, Fstop, Apass, Astop, Fs);
Hd = design(h, 'equiripple', 'MinOrder', 'any', 'StopbandShape', 'flat');
%disp(['length of train before filtering: ' num2str(length(train))]); %276
train = filter(Hd,train);
%disp(['length of train after filtering: ' num2str(length(train))]); %276

Freq=(0:(Nc-1))/Nc*Fs;
Freq=Freq-(Freq>(Fs/2))*Fs;

%null_subcarriers=(abs(Freq)<(Fs/4))'; %%WORKING!!!
null_subcarriers=(abs(Freq)<(Fs/4))';
used_subcarrier=find(null_subcarriers);

Constellation=qammod(0:(M-1),M); %Will be obsolete...
Constellation=Constellation(bin2gray(0:(M-1),'QAM',M)+1);

% Randomize the information to be transmitted
rand('twister',9876);
Information=ceil(rand(Nc,Ns,B)*length(Constellation));

