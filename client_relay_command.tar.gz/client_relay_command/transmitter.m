function x_t = transmitter(Information2)
    
    if (Information2==0)
       ofdm_param;
    else
        ofdm_param;
        Information = Information2;
    end;

    x_t=zeros(1,L*B); %% Base-band signal to be transmitted.

    %% Data bursts
    n00=1;
    for b=1:B
%         if (rem(b,10)==0)
%             b
%         end;
        % Insert training sequence
        n0=n00+(b-1)*L;
        ix0=(1:length(train))+n0;

        if (b==1)
            x_t(ix0)=A0*train;
        end;


        symbols_c=Constellation(Information(:,:,b));

        n1=n0+length(train)+4;


        for symbol_i=1:size(symbols_c,2)
            temp1=symbols_c(:,symbol_i);
            temp=A1*ifft(temp1.*null_subcarriers,Nc);
            ix1=n1+(symbol_i-1)*(Nc+Np)+(1:Np);
            ix2=ix1(end)+(1:Nc);
            x_t(ix1)=temp(end-(Np:-1:1)+1);
            x_t(ix2)=temp;
        end;
    end;
    
    x_t=max(real(x_t),-32760)+1j*max(imag(x_t),-32760);
    x_t=min(real(x_t),32760)+1j*min(imag(x_t),32760);
end