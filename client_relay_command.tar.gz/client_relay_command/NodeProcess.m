function [x_t s]=NodeProcess(node_ix, slot_ix, frameDef,strX, X)
    disp('in NodeProcess_relay');
    ofdm_param;
    
    if(node_ix == frameDef(slot_ix)) 
        disp([num2str(node_ix) '== frameDef(' num2str(slot_ix) ') -> TRANSMIT']);
        if (strX.has_relay_information)    
            disp('Transmit OLD information');
            x_t = transmitter(strX.Information);
            strX.has_relay_information = 0; % The information has been sent
        else
            disp('Transmit NEW information');
            x_t = transmitter(Information);
        end;
        s=strX;
    else
        disp([ num2str(node_ix) ' ~= framedef(' num2str(slot_ix) ') -> RECEIVE']);
        x_t=[];
        disp('run receiver');
        receiver;
        disp('returend from receiver');
        save(['X' num2str(slot_ix)],'X');
        s = struct('Information', Information_hat, 'has_relay_information', 1);
    end;
    
end