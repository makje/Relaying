function transmit_single_antenna(RF_freq, gain,X)
    MAX_NUMBER_OF_BUFFERS=4000; 
    NUMBYTES=4096*2*2;
    filename='data_to_usrp.dat';
    unix(['sudo rm ',filename]);
    X=X(:);
    number_of_samples_per_buffer=NUMBYTES/4;
    number_of_buffers=ceil(length(X)/number_of_samples_per_buffer);
    number_of_buffers=max(number_of_buffers,2);
    Xin=zeros(number_of_buffers*number_of_samples_per_buffer*2,1);
    for i1=1:length(X)
        Xin(2*i1-1)=real(X(i1));
        Xin(2*i1-0)=imag(X(i1));
    end;
    
    fid=fopen(filename,'w');
    fwrite(fid,Xin,'int16');
    fclose(fid);
    args=[num2str(number_of_buffers),' '];
    args=[args,num2str(RF_freq),' ',num2str(gain)];
    args=[args,' ','transmit &'];
    cmd=['sudo ./single_antenna ',args]; %% Edit to get the correct path
	unix(cmd);
	disp(['Executed: ' cmd]);
end
