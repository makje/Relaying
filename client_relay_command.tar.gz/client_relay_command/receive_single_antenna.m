function X=receive_single_antenna(number_of_samples,RF_freq,gain)
    receiver = 'single_antenna';
    file_name='data_from_usrp.dat';  %% Edit to get the data where it lands.

    %% "defines" that should be the same as in receive_usrp1.cpp
    MAX_NUMBER_OF_BUFFERS=4000; 
    NUMBYTES=4096*2*2;
    MAX_NUMBER_OF_SAMPLES=MAX_NUMBER_OF_BUFFERS*NUMBYTES/2;
    try
        unix(['sudo rm ',file_name]);
    catch
        disp(['couldnt remove ' file_name ', probably because it didnt exist']);
    end
    %% Setup parameters to execute binary receiver.
    
    if (number_of_samples>MAX_NUMBER_OF_SAMPLES)
        number_of_samples=MAX_NUMBER_OF_SAMPLES;
    end;

    number_of_buffers=ceil((number_of_samples*2)/NUMBYTES);

    args=[num2str(number_of_buffers),' ', num2str(RF_freq),' ',num2str(gain),' receive'];
%    args=[args,num2str(RF_freq),' ',num2str(gain)];
%    args=[args,' ','receive'];
%    cmd=['sudo ./' receiver ' ' args]; %% Edit to get the correct path
%    system(cmd);
    disp('execute receiver')
    system(['sudo ./' receiver ' ' args]);
    disp('receiver executed');
    %% Save the received data to file
    rehash;
    %try
        fid=fopen(file_name,'r');
        temp=fread(fid,number_of_samples,'int16');
        fclose(fid);
        X=temp(1:2:end)'-1i*temp(2:2:end)';
    %catch ME
    %    disp(ME)
    %end
end