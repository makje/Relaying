%function receive_files()
%Receive files from master and return a cellarray containing the new files
%also rehash, so that the newly received files may be used...
%
function TransferFiles = receive_files(sock)
    disp 'Receive list of files';
    TransferFiles = msrecv(sock);
    for i1=1:length(TransferFiles)
        disp(['Receive ' cell2mat(TransferFiles(i1))]);
        fid = fopen(cell2mat(TransferFiles(i1)),'w');
        file_content = msrecv(sock);
        fwrite(fid, file_content);
        fclose(fid);
    end
    rehash;
end