% receiver10.m

%i=sqrt(-1);
known_subcarrier=1;
x_r=(X);


Information_hat=zeros(size(Information));

N_search=L*30;
Lt=6;

Nt=length(train)-Lt+1;
Xt=zeros(Lt,Nt);
for i1=1:Lt
    Xt(i1,:)=train(Lt-i1+(1:Nt));
end;
%Noffset=8;
%Noffset=3;
Noffset=5;

    if 1
        Rxx=Xt*Xt';
        iRxx=inv(Rxx);
        SNR_estimate=zeros(1,round(L*B*1.5));
        f_estimate=zeros(1,round(L*B*1.5));
        Ftest=-30000:10000:30000;
        
        SNR_local=zeros(1,length(Ftest));
        
        
        for i1=1:length(SNR_estimate)
            for f_i=1:length(Ftest)
                ft=Ftest(f_i);
                xt=x_r((i1-1)+(1:Nt)).*exp(-j*2*pi*ft*inv(Fs)*(1:Nt));
                %Rxy=Xt*x_r((i1-1)+(1:Nt))';
                Rxy=Xt*xt';
                h=Rxy'*iRxx;
                %Ryy=x_r((i1-1)+(1:Nt))*x_r((i1-1)+(1:Nt))';
                Ryy=xt*xt';
                Q=Ryy-Rxy'*iRxx*Rxy;
                Q=Q/Nt;
                %SNR_estimate(i1)=abs(h*inv(Q)*h');
                f_estimate(i1)=ft;
                SNR_local(f_i)=abs(h*inv(Q)*h');
            end;
            [max_SNR,max_f]=max(SNR_local);
            SNR_estimate(i1)=max_SNR;
            f_estimate(i1)=Ftest(max_f);
        end;
        [max_SNR,index_max]=max(SNR_estimate);
        f0=f_estimate(index_max);
    end;




disp(f0);

x_r=x_r.*exp(-1j*2*pi*f0*inv(Fs)*(1:length(x_r)));

output_data=zeros(B*length(used_subcarrier),1);
ixd=0;

for b=1:B
    
    % Use first symbol for channel estimation

    symbols_c=Constellation(Information(:,:,b));
    ix3=(b-1)*L+index_max+length(train)+Noffset+(1:Nc);
    symbol_hat=fft(x_r(ix3));
    symbol_hat=conj(symbol_hat');
    h=symbol_hat./symbols_c(:,1);

   %hold off

   for i1=2:Ns

      ix3=(b-1)*L+index_max+length(train)+Noffset+(1:Nc)+(Nc+Np)*(i1-1);

      %ix3=index_max+Noffset+(1:Nc)+(i1-1)*(Nc+Np);
      symbol_hat=fft(x_r(ix3));
      symbol_hat=conj(symbol_hat');
      symbol_hat=symbol_hat./h;
      if (known_subcarrier)
            correction_factor=symbols_c(known_subcarrier,i1)/...
            symbol_hat(known_subcarrier);
            symbol_hat=symbol_hat*exp(j*angle(correction_factor));
      end;
      output_data(ixd+(1:length(used_subcarrier)))=symbol_hat(used_subcarrier);
      ixd=ixd+length(used_subcarrier);

      plot(symbol_hat(used_subcarrier),'x');
      hold on
      [symbol_hat,symbols_c(:,i1)];

      temp=abs(repmat(symbol_hat,1,length(Constellation))-...
           repmat(Constellation,length(symbol_hat),1));
      [dummy,temp]=min(temp,[],2);
      for i2=1:length(temp)
        Information_hat(i2,i1,b)=temp(i2);
      end;
   end

   Berrors=CalculateBER(squeeze(Information_hat(used_subcarrier,2:end,b))-1,...
              Information(used_subcarrier,2:end,b)-1,...
            round(log2(length(Constellation))));
   BER(b)=mean(Berrors(:));
end;


for i1=1:size(Information,3)
    Information_hat(:,1,i1) = Information(:,1,i1);
end;

disp([mean(BER),std(BER)]);