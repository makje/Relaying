%%Client script.
%Run to start client.
port = 1200;
node_ix = 1;
srv_ip = '130.237.50.250';

disp('Press any key when master is started');
pause();

sock = connect_to_master(node_ix, srv_ip, port);

disp('waiting for command');
command = '';
while (strcmp(command, 'quit') ~=1)
    command = msrecv(sock);
    %check if first character is a dot.
    if(strfind(command(1),'.')==1)
        try
            eval(command(2:end));
        catch
            disp(['Exception cought trying to eval(' command ')']);
        end
        command = '';
    end
    
end
disp('Received QUIT from master! Shuting down');
msclose(sock);
clear sock;
clear command