%Connect to master
%function socket = connect_to_master(node_ix, srv_ip, port)
function socket = connect_to_master(node_ix, srv_ip, port)
    %assert(nargin==3,'Must call function with 3 arguments, This nodes number, server ip, and port to connect to');
    %assert(port>1000,'Try use a non reserved port (port > 1000)');
    socket = msconnect(srv_ip, port);
    if(socket<1)
        disp('Connection with master refused!');
        socket = 0;
        return;
    end
    mssend(socket, node_ix);
end