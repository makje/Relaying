function s = nodeInit()
    s = struct('Information', 0, 'has_relay_information', 0);
end